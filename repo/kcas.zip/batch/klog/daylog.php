<?php
$_GET_LOG_PATH = '/data/log/LOGD/testlog/'.date('Ymd');				//GET �α�
$_PUT_LOG_PATH = '/data/log/kcas';									//PUT �α�

function logJob( $get_log_path, $_put_log_path, $day, $hour )
{
	$fpG = @fopen( $get_log_path . '/' . $hour, 'r' );
	$fpP = @fopen( $get_log_path . '/uway_'.$day.'.txt', 'a+' );

	if( ! $fpG ) return false;
	if( ! $fpP ) return false;

	while( feof( $fpG ) == FALSE && $line = fgets( $fpG ) )
	{
		$_logseq++;

		$lines = explode( ' ', $line, 3 );

		if( is_array( $lines ) == false ) continue;

		fwrite($fpP, $lines[2]['KLOG']);
	}
	@fclose( $fpG );
	@fclose( $fpP );
} // end of method insert

logJob( '.','',20150616, 17);
?>
