<?

error_reporting(E_ALL&~E_NOTICE); //����������
//error_reporting(false);
//ini_set('error_reporting', 0);

$_REQUEST_KEY = rand(5, 15)."_".round(microtime(true) * 1000);

$_SERVER['SERVER_NAME'] = "EAI";
$_SERVER['REQUEST_URI'] = "EAI";
$_SERVER['REMOTE_ADDR'] = "";

require_once(dirname(__FILE__)."/conf/config.inc");

class IF_USER_ENT001_RCV_COLS{
	public $INTEG_ID;
	//public $SEQ;
	public $WOK_DATE;
	public $PWD;
	public $NAME;
	public $BRDY_YYMMDD;
	public $SEX_GUBN;
	public $CRAL_TEL;
	public $CRAL_TEL_DEC;
	public $CRAL_TEL_HASH;
	public $EMAIL;
	public $SMS_JINHAK_YN;
	public $EMAIL_JINHAK_YN;
	public $SMS_UWAY_YN;
	public $EMAIL_UWAY_YN;
	public $INTEG_ID_HASH;
	public $INTEG_ID_YN;
	public $COMPANY_GUBN;
	public $REG_DATE;
	public $PARENT_AGREE_YN;
	public $INTEG_GUBN;
	public $WORK_GUBN;
	public $CUD_GUBN;
	//public $IF_ID;
	public $IF_STATUS;
	//public $IF_TIME;
	public $IF_MESSG;

}

class IF_USER_ENT001_RCV extends ORM{
	var $oci = null;
	function IF_USER_ENT001_RCV(& $oci){
		parent::ORM($oci);
	}
}







$kcasOci = connectKcasidsDB($isDev = false);
$ka = new KcasUser($kcasOci);

$oci = connectOrmDB($isDev = false);
$oci->db->error_check = 0;

$if_rcv = new IF_USER_ENT001_RCV($oci);
$if_rcv->setLimit(5);

$table_name =  $if_rcv->table();

$lsn = new LSN($oci,$table_name);




//$rows = $if_rcv->pull($where);
$i = 100;
while($i > 0){
	
	$seq = $lsn->read();
	
	
	$where = array('SEQ'=>array('>', $seq), 'IF_STATUS' => 'R');
	$rows = $if_rcv->pull($where);
	
	
	$sh = array();
	$sh['INTEG_ID'] = 'test10003';
	$data = $ka->pull($sh);
	
	
	
	//$ka->push($rows[0]);
	
	print_r($rows);
	print_r($data);
	
	sleep(5);
	$i--;
	
}


