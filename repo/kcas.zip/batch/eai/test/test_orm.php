
<?
error_reporting(E_ALL&~E_NOTICE); //에러리포팅

//phpinfo();



//$_SITE_ROOT_ = dirname(dirname(__FILE__))."/../..";
$_SITE_ROOT_ = dirname(dirname(__FILE__));

require_once($_SITE_ROOT_.'/common/class.UwayPDO.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/lib/class.KcasApply.php');
//require_once($_SITE_ROOT_.'/lib/class.ORM.php');
require_once($_SITE_ROOT_.'/test/class.ORM.php');
require_once($_SITE_ROOT_.'/test/test_include.php');



class IF_COMMON_ENT002_SND_COLS{
	var $INTEG_ID;
	var $NM;
	var $IF_STATUS;
}

class IF_COMMON_ENT002_SND extends ORM{
	var $oci = null;
	var $pk = 'SEQ';
	function IF_COMMON_ENT002_SND(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}

	function insert($row){
		$filtered_column_row = $this->filter_by_columns($row);
		return parent::insert($filtered_column_row);
	}

}



function init(){
	global $ka;
	$data = array('INTEG_ID' => 'test2', 'NM'=> "dfdfdfdf",'IF_STATUS' => 'R', 'xxx'=> "dfdf");
	$ka->insert($data);	

}

$oci = connection_database($mode = "devlcl");
$oci->db->error_check = 0;
$ka = new IF_COMMON_ENT002_SND($oci);


function tst_pull(){
	global $ka;

	$rows = $ka->pull(array('INTEG_ID' => 'test2'), "INTEG_ID, IF_STATUS, NM");
	DEBUG($rows);
}

function tst_log(){
	global $ka;
	$ka->setOptions(array("debug_level" => "-1"));


	//$rows = $ka->pull(array('INTEG_ID' => 'test2'), "INTEG_ID, IF_STATUS, NM");
	$rows = $ka->push(array('SE' => '2','IF_STATUS' => 'S'));
	DEBUG($rows);
}


// init();
tst_log();
//tst_pull();
// 1. insert
 // $data = array('INTEG_ID' => 'test2', 'NM'=> "dfdfdfdf",'IF_STATUS' => 'R', 'xxx'=> "dfdf");
 // $ka->insert($data);
 // echo $ka->error;

?>