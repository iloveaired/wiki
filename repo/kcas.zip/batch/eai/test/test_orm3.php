<?

error_reporting(E_ALL&~E_NOTICE); //에러리포팅


//$_SITE_ROOT_ = dirname(dirname(__FILE__))."/../..";
$_SITE_ROOT_ = dirname(dirname(__FILE__));

require_once($_SITE_ROOT_.'/common/class.UwayPDO.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
//require_once($_SITE_ROOT_.'/lib/class.ORM.php');
require_once($_SITE_ROOT_.'/test/class.ORM.php');


function & connection_database($mode){
	$oci = new MySQL_OCI();
	
	if($mode == "real"){		
		$oci->connect('kcas','kcas12$','kcas_1a'); 
		//kcas_1
	}else if($mode== "devlcl") {
		//$oci->connect('dkcas','dkcas12$','kcas');
		$oci->connect('root','apmsetup','megaware'); //우선 리플리케이션을 무시해서 사용
	}

	return $oci;
}



$oci = connection_database($mode = "devlcl");
$oci->db->error_check = 0;

echo "<xmp>";


class IF_USER_ENT001_COLS{
	var $INTEG_ID;
	var $NM;
	var $IF_STATUS;



}

class IF_USER_ENT001_RCV extends ORM{
	var $oci = null;
	function IF_USER_ENT001_RCV(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}



}

$if_rcv = new IF_USER_ENT001_RCV($oci);

$if_rcv->setLimit(5);
$seq = 1;
$where = array('SEQ'=>array('>', $seq), 'IF_STATUS' => 'R');
		
//$rows = $if_rcv->pull($where, "*", "order by ");
$rows = $if_rcv->pull($where, "INTEG_ID, SEQ, REG_DATE", "order by seq asc");

print_r($rows);



?>