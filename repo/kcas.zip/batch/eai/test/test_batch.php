<?

error_reporting(E_ALL&~E_NOTICE); //에러리포팅


//$_SITE_ROOT_ = dirname(dirname(__FILE__))."/../..";
$_SITE_ROOT_ = dirname(dirname(__FILE__));

require_once($_SITE_ROOT_.'/common/class.UwayPDO.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/lib/class.KcasApply.php');

//require_once($_SITE_ROOT_.'/lib/class.LSN.php');
//require_once($_SITE_ROOT_.'/lib/class.ORM.php');
require_once($_SITE_ROOT_.'/test/class.ORM.php');
require_once($_SITE_ROOT_.'/lib/class.LSN.php');

function & connection_database($mode){
	$oci = new MySQL_OCI();
	
	if($mode == "real"){
		//$oci->connect('kcas','kcas12$','kcas');
		$oci->connect('kcas','kcas12$','kcas_1a'); //우선 리플리케이션을 무시해서 사용
		//kcas_1
	}else if($mode== "devlcl") {
		//$oci->connect('dkcas','dkcas12$','kcas');
		$oci->connect('root','apmsetup','megaware'); //우선 리플리케이션을 무시해서 사용
	}

	return $oci;
}

class IF_COMMON_ENT002_RCV_COLS{
	var $INTEG_ID;
	var $NM;
	var $IF_STATUS;

}

class IF_COMMON_ENT002_RCV extends ORM{
	var $oci = null;
	function IF_COMMON_ENT002_RCV(& $oci){		
		parent::ORM($oci);
	}
}

function DEBUG($msg, $prefix= ""){
	echo "<xmp>";
	if(is_array($msg)){
		print_r($msg);				
	} else {
		echo $msg."\n";
	}
	echo "</xmp>";
}

function batch_process($rows,$lsn,$if_rcv){
	foreach($rows as $row){

		if(empty($row['INTEG_ID'])){
			$if_rcv->push(array('SEQ'=>$row['SEQ'], 'IF_STATUS'=>'F'));
			continue;
		}
		DEBUG($row);
		//DummyApply::push($row);
		$lsn->write($last_seq);
	}	
}
function main_loop($oci){

	$if_rcv = new IF_COMMON_ENT002_RCV($oci);
	$if_rcv->setLimit(5);

	$table_name =  $if_rcv->table();

	$lsn = new LSN($oci,$table_name);

	// test 초기화 
	$lsn->write('30');

	$max_per_process = 3;
	$i= 0;

	while($i++ < $max_per_process) {
		$seq = $lsn->read();
		DEBUG($seq);

		$where = array('SEQ'=>array('>', $seq), 'IF_STATUS' => 'R');
		
		$rows = $if_rcv->pull($where);

		if(empty($rows)){			
			sleep(1);
			continue;
		} 
		$last_seq = batch_process($rows,$lsn,$if_rcv);
		
	}
}

$oci = connection_database($mode = "devlcl");
$oci->db->error_check = 0;

main_loop($oci);

?>