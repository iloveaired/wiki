<?

error_reporting(E_ALL&~E_NOTICE); //에러리포팅

//$_SITE_ROOT_ = dirname(dirname(__FILE__))."/../..";
$_SITE_ROOT_ = dirname(dirname(__FILE__));

require_once($_SITE_ROOT_.'/common/class.UwayPDO.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/lib/class.KcasApply.php');
require_once($_SITE_ROOT_.'/lib/class.ORM.php');
require_once($_SITE_ROOT_.'/lib/class.LSN.php');
//require_once($_SITE_ROOT_.'/test/class.ORM.php');


function & connection_database($mode){
	$oci = new MySQL_OCI();
	
	if($mode == "real"){
		//$oci->connect('kcas','kcas12$','kcas');
		$oci->connect('kcas','kcas12$','kcas_1a'); //우선 리플리케이션을 무시해서 사용
		//kcas_1
	}else if($mode== "devlcl") {
		//$oci->connect('dkcas','dkcas12$','kcas');
		$oci->connect('root','apmsetup','megaware'); //우선 리플리케이션을 무시해서 사용
	}

	return $oci;
}



$oci = connection_database($mode = "devlcl");
$oci->db->error_check = 0;

function test_lsn($oci){
	$ka = new LSN($oci, "IF_COMMON_ENT002_RCV");
	$seq = $ka->read();
	
	$ka->write("3");
	
	$seq = $ka->read();
	assert($seq == "3");	

}

test_lsn($oci);


?>