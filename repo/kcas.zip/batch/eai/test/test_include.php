<?

function & connection_database($mode){
	$oci = new MySQL_OCI();
	
	if($mode == "real"){
		//$oci->connect('kcas','kcas12$','kcas');
		$oci->connect('kcas','kcas12$','kcas_1a'); //우선 리플리케이션을 무시해서 사용
		//kcas_1
	}else if($mode== "devlcl") {
		//$oci->connect('dkcas','dkcas12$','kcas');
		$oci->connect('root','apmsetup','megaware'); //우선 리플리케이션을 무시해서 사용
	}

	return $oci;
}



function DEBUG($msg, $prefix= ""){
	echo "<xmp>";
	if(is_array($msg)){
		print_r($msg);				
	} else {
		echo $msg."\n";
	}
	echo "</xmp>";
}


?>