<?

error_reporting(E_ALL&~E_NOTICE); //에러리포팅

//phpinfo();



//$_SITE_ROOT_ = dirname(dirname(__FILE__))."/../..";
$_SITE_ROOT_ = dirname(dirname(__FILE__));

require_once($_SITE_ROOT_.'/common/class.UwayPDO.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/lib/class.KcasApply.php');
//require_once($_SITE_ROOT_.'/lib/class.ORM.php');
require_once($_SITE_ROOT_.'/test/class.ORM.php');


function & connection_database($mode){
	$oci = new MySQL_OCI();
	
	if($mode == "real"){
		//$oci->connect('kcas','kcas12$','kcas');
		$oci->connect('kcas','kcas12$','kcas_1a'); //우선 리플리케이션을 무시해서 사용
		//kcas_1
	}else if($mode== "devlcl") {
		//$oci->connect('dkcas','dkcas12$','kcas');
		$oci->connect('root','apmsetup','megaware'); //우선 리플리케이션을 무시해서 사용
	}

	return $oci;
}



$oci = connection_database($mode = "devlcl");
$oci->db->error_check = 0;

echo "<xmp>";


class IF_COMMON_ENT002_SND_COLS{
	var $INTEG_ID;
	var $NM;
	var $IF_STATUS;



}

class IF_COMMON_ENT002_SND extends ORM{
	var $oci = null;
	function IF_COMMON_ENT002_SND(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}

	function insert($row){
		$filtered_row = $this->filter_by_columns($row); //filter_by_columns($row)
		return parent::insert($filtered_row);
	}

}

$ka = new IF_COMMON_ENT002_SND($oci);


// 1. insert
// $data = array('INTEG_ID' => 'test2', 'NM'=> "dfdfdfdf",'IF_STATUS' => 'R', 'xxx'=> "dfdf");
// $ka->insert($data);
// echo $ka->error;



// 2. pull ex1
// $sh = array('INTEG_ID'=>'test2',);
// $rows = $ka->pull($sh, "INTEG_ID, NM");
// print_r($rows);


// 2. pull ex2
// $sh = array('SEQ'=>array('>', '1'));//, 'IF_STATUS' => 'R');
// $ka->setLimit(1);
// $rows = $ka->pull($sh, "INTEG_ID, SEQ, NM, IF_STATUS");
// print_r($rows);


// 3. push
// $row = array('SEQ' => 1, "IF_STATUS" => "S");
// $r = $ka->push($row); // affected rows
// var_dump($r);
//echo $r;
// if($r!=1){
// 	echo $ka->error;
// }

?>