<?


class IF_OCI{

	function IF_OCI($table){
	}
	function select($seq, $limit =10){
		$rows = array();
		$rows[] = array('id'=>'test1','seq'=>1);
		$rows[] = array('id'=>'test2','seq'=>2);
		return $rows;
	}

}

class MLog{
	function log($r){

	}
}
class DummyApply{
	function push($h){
		$result = array("error", "msg"=>$h);
		print_r($h);
		MLog::log($result);
		return true;
	}
}

class LSN {
	var $location = "/data/log/eai.uwayapply.com/batch/seq/";

	function LSN($table){
		$seq_file = $location . $table.".seq";		
	}

	function write($seq){

		return true;
	}
	function read(){
		return 100;
	}
}
function batch_process($rows){
	foreach($rows as $row){
		DummyApply::push($row);
	}
	return $row['SEQ'];
}
function main_loop($table){


	$oci = new IF_OCI($table);


	$lsn = new LSN($table);


	$n = 100;
	$i= 0;

	while($i++ < $n) {
		$seq = $lsn->read();
		$rows = $oci->select($seq, $limit = 10);
		if(empty($rows)){
			sleep(5);
			continue;					
		} 
		$last_seq = batch_process($rows);
		$lsn->write($last_seq);
	}
}

main_loop($table = "IF_COMMON");



?>
