<?

ini_set("memory_limit", '500M');

error_reporting(E_ALL&~E_NOTICE); //����������
//error_reporting(false);
//ini_set('error_reporting', 0);

if(strpos(basename(__FILE__), "dev.php") === false){
	$_IS_DEV = false;
} else {
	$_IS_DEV = true;
}

$_SERVER_IP = $argv[1];



$_REQUEST_KEY = rand(5, 15)."_".round(microtime(true) * 1000);

if(php_sapi_name()=="cli"){
	if(!$_IS_DEV){
		$_SERVER['SERVER_NAME'] = "EAI";
		$_SERVER['REQUEST_URI'] = "EAI";
	} else {
		$_SERVER['SERVER_NAME'] = "EAI_DEV";
		$_SERVER['REQUEST_URI'] = "EAI_DEV";
	}
	$_SERVER['REMOTE_ADDR'] = $_SERVER_IP;
	$_SERVER['SERVER_ADDR'] = $_SERVER_IP;
} else {
	die();
}

require_once(dirname(__FILE__)."/../conf/config.inc");

require_once(dirname(dirname(__FILE__))."/../../eai/common/class.EAIApi.php");


//$_SITE_ROOT_ = dirname(dirname(__FILE__))."/../..";

function DEBUG($msg, $prefix= ""){
	echo "<xmp>";
	if(is_array($msg)){
		print_r($msg);				
	} else {
		echo $msg."\n";
	}
	echo "</xmp>";
}


function & connectLogDB(){
	
	$oci = new MySQL_OCI();

	$oci->connect('log','log','log@192.168.3.59');

	return $oci;
}



//function batch_process($lsn,$if_rcv,$ka){
function batch_process(&$log_oci,&$eai_oci,&$eai){
	
	$sql = "
				INSERT INTO log_repair 
				SELECT *
				FROM log09
				WHERE TITLE = 'ȸ�����Խ���:������з����ѻ���'
				  AND _LOGDATE BETWEEN DATE_FORMAT(NOW()-INTERVAL 60*24 MINUTE,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(NOW()-INTERVAL 1 MINUTE,'%Y-%m-%d %H:%i:%s')
				  AND _SERVER_NAME = 'kcasids.uwayapply.com'
				  AND _SCRIPT_NAME = '/join.process.php'
				ORDER BY _LOGSEQ ASC
				ON DUPLICATE KEY
				UPDATE
				  TITLE = VALUES(TITLE)
			";
	
	$result = $log_oci->parseExec($sql);
	
	
	$sql = "
			SELECT * FROM 
			log.log_repair 
			WHERE
			(IDX5 != 'SUCCESS' OR IDX5 IS NULL)
			";
	
	
	$data = $log_oci->getRowsName($sql);
	
	
	foreach($data as $k=>$v){
		$data[$k]['ETC'] = unserialize($v['ETC']); 
		
		$logseq = $data[$k]['_LOGSEQ'];
		$integ_id = $data[$k]['IDX1'];

		$sql = "
			SELECT
				COUNT(*) AS CNT
			FROM
				IF_USER_ENT001_SND
			WHERE
				INTEG_ID='{$integ_id}'
				AND INTEG_GUBN='MJ'
				AND REG_DATE BETWEEN DATE_FORMAT(NOW()-INTERVAL 60*24 MINUTE,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(NOW()-INTERVAL 1 MINUTE,'%Y-%m-%d %H:%i:%s')
		";
		$data_cnt = $eai_oci->getRowsName($sql);
		$data_cnt = $data_cnt[0]['CNT'];
		
		
		if($data_cnt <= 0){
			$result = $eai->eaiApi($method = "if_user_ent001_snd",$params = array("INTEG_ID"=>$integ_id,"INTEG_GUBN"=>"MJ"));
			
			$sql = "
				SELECT
					COUNT(*) AS CNT
				FROM
					IF_USER_ENT001_SND
				WHERE
					INTEG_ID='{$integ_id}'
					AND INTEG_GUBN='MJ'
					AND REG_DATE BETWEEN DATE_FORMAT(NOW()-INTERVAL 60*24 MINUTE,'%Y-%m-%d %H:%i:%s') AND DATE_FORMAT(NOW()-INTERVAL 1 MINUTE,'%Y-%m-%d %H:%i:%s')
			";
			$data_cnt = $eai_oci->getRowsName($sql);
			$data_cnt = $data_cnt[0]['CNT'];
			
			if($result['rsltYn'] == "Y" && $data_cnt > 0){
				$sql = "
						UPDATE
							log_repair
						SET
							IDX5 = 'SUCCESS'
							,IDX4 = DATE_FORMAT(NOW(),'%Y-%m-%d %H:%i:%s')
						WHERE
							_LOGSEQ = '{$logseq}'
				";
				
				$log_oci->parseExec($sql);
			}
		} else {
			$sql = "
				UPDATE
					log_repair
				SET
					IDX5 = 'SUCCESS'
					,IDX4 = DATE_FORMAT(NOW(),'%Y-%m-%d %H:%i:%s')
				WHERE
					_LOGSEQ = '{$logseq}'
			";
			
			$log_oci->parseExec($sql);
		}
		
	}
	
}
function main_loop(){
	
	global $_REQUEST_KEY;
	global $_INIT_CONFIG;
	global $_IS_DEV;
	global $_SERVER_IP;
	
	
	log_message( 'info', array(
		'title' => 'ȸ�����Կ������_�α�',
		'msg' => 'ȸ������ ������� ȸ������ ���� ����',
		'idx2' => $_REQUEST_KEY
	) );
	
	
	
	$eai = new EAIApi();
	$eai->actionURL = "http://kcas.uwayapply.com/eai/api/json_server.php";
	
	
	$max_per_process = 1;
	$i= 0;

	//while($i++ < $max_per_process) {
	while(true) {
		
		$log_oci = connectLogDB();
		$log_oci->db->error_check = 0;
		
		$eai_oci = connectOrmDB($_IS_DEV);
		$eai_oci->db->error_check = 0;
		
		
		batch_process($log_oci,$eai_oci,$eai);
		
		
		$eai_oci->disconnect();
		$log_oci->disconnect();
		
		unset($eai_oci);
		unset($log_oci);
		
		
		sleep(5);
	}
	
	log_message( 'info', array(
		'title' => 'ȸ�����Կ������_�α�',
		'msg' => 'ȸ������ ������� ȸ������ ���� ����',
		'idx2' => $_REQUEST_KEY
	) );
}



main_loop();

?>