<?
//require_once(dirname(__FILE__).'/class.ORM.php');
require_once "class.ORM.php";

class LSN extends ORM{
	var $oci = null;
	var $rcv_table = null;
	var $pk = "NM";
	function LSN(& $oci,$rcv_table){		
		$this->rcv_table = $rcv_table;
		parent::ORM($oci);
	}

	function write($seq){
		return $this->push(array("NM" => $this->rcv_table, "SEQ" => $seq));	
	}
	function read(){
		
		$rows = $this->pull(array("NM" => $this->rcv_table));
		

		return $rows[0]['SEQ'];
	}

}

?>