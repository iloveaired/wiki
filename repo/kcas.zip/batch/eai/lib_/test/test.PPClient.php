<?
/**
* Pull/Push Ŭ���̾�Ʈ
* ���� : PHP 5.0 �̻� �ʼ�! cURL ���� �ʼ�!
*/
require(dirname(__FILE__).'/../class.MProxy.php'); //<- �ʼ�
require(dirname(__FILE__).'/../class.PPClient.php');


$actionURL = 'http://bridgedevlcl.uwayapply.com/kcas/jsonrpc/sample2/server.php'; //����


$mproxy = new MProxy();
$ppclient = new PPClient($actionURL,$mproxy);
$sh = array();
$sh['ID'] = 'testPPClient';


$r = $ppclient->pull($sh);

echo "<xmp>";
var_dump($r);

if($r === false){
	echo "���� :";
	var_dump($ppclient->error);
	var_dump($ppclient->lastResult);
}else{
	echo "��� :";
	echo "\n==============================\n";
	print_r($r);

	echo "lastResponseMode : ".$ppclient->lastResponseMode,"\n";
	echo "error : ".$ppclient->error,"\n";
}




?>