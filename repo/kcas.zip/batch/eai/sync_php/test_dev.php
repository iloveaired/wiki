<?php
require_once(dirname(__FILE__)."/../conf/config.inc");

$path = __FILE__;

if(strpos(basename(__FILE__), "dev.php") === false){
		$_IS_DEV = false;
	} else {
		$_IS_DEV = true;
	}
	
	
	echo "test".$_IS_DEV;
	
	echo __FILE__;