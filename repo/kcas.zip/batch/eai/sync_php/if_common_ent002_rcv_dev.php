<?

ini_set("memory_limit", '500M');

error_reporting(E_ALL&~E_NOTICE); //����������
//error_reporting(false);
//ini_set('error_reporting', 0);

if(strpos(basename(__FILE__), "dev.php") === false){
	$_IS_DEV = false;
} else {
	$_IS_DEV = true;
}

$_SERVER_IP = $argv[1];



$_REQUEST_KEY = rand(5, 15)."_".round(microtime(true) * 1000);

if(php_sapi_name()=="cli"){
	if(!$_IS_DEV){
		$_SERVER['SERVER_NAME'] = "EAI";
		$_SERVER['REQUEST_URI'] = "EAI";
	} else {
		$_SERVER['SERVER_NAME'] = "EAI_DEV";
		$_SERVER['REQUEST_URI'] = "EAI_DEV";
	}
	$_SERVER['REMOTE_ADDR'] = $_SERVER_IP;
	$_SERVER['SERVER_ADDR'] = $_SERVER_IP;
} else {
	die();
}

require_once(dirname(__FILE__)."/../conf/config.inc");

//$_SITE_ROOT_ = dirname(dirname(__FILE__))."/../..";




class IF_COMMON_ENT002_RCV_COLS{
	public $INTEG_ID;
	public $CMF_UID;
	//public $SEQ;
	public $WORK_DATE;
	public $PERS_US_AGRM_YN;
	public $UNIQ_US_AGRM_YN;
	public $PERS_CONS_AGRM_YN;
	public $PERS_THREE_AGRM_YN;
	public $VLTN_GDNC_AGRM_YN;
	public $ONSL_QLFC_DT_AGRM_YN;
	public $FLSH_QLFC_PVNT_AGRM_YN;
	public $ONLN_OFR_SYS_IST;
	public $NM;
	public $LNM;
	public $FNM;
	public $MMBR_CD;
	public $RRNO;
	public $GNDR;
	public $BRDY;
	public $PERS_ID;
	public $PERS_ID1;
	public $CNTY_CD;
	public $NAT;
	public $BSIS_ZONE;
	public $ADD_SEQ;
	public $PSNO;
	public $DTL_ADD;
	public $ROAD_ADD_BLDG_NO;
	public $ROAD_DTL_ADD;
	public $DONGCODE;
	public $SIDO;
	public $SIGUNGU;
	public $DONG;
	public $RI;
	public $ISMOUNTAIN;
	public $JIBUN1;
	public $JIBUN2;
	public $STREETCODE;
	public $STREET;
	public $ISUNDER;
	public $BUILDINGNUM1;
	public $BUILDINGNUM2;
	public $BUILDING;
	public $BUILDINGDETAIL;
	public $BUILDINGCODE;
	public $DONGSEQ;
	public $HANGDONGCODE;
	public $HANGDONG;
	public $ZIPSEQ;
	public $MASSDESTINATION;
	public $MODEREASONCODE;
	public $CHANGEDATE;
	public $OLDSTREET;
	public $SIGUNGUBUILDING;
	public $ISAPARTMENT;
	public $CRAL_TEL;
	public $TEL_ANO;
	public $TEL1;
	public $TEL2;
	public $EMAIL;
	public $ADIT1_TEL_ANO;
	public $ADIT1_TEL1;
	public $ADIT1_TEL2;
	public $ADIT2_TEL_ANO;
	public $ADIT2_TEL1;
	public $ADIT2_TEL2;
	public $ADIT3_TEL_ANO;
	public $ADIT3_TEL1;
	public $ADIT3_TEL2;
	public $ADIT4_TEL_ANO;
	public $ADIT4_TEL1;
	public $ADIT4_TEL2;
	public $ADIT5_TEL_ANO;
	public $ADIT5_TEL1;
	public $ADIT5_TEL2;
	public $FRGN_TEL;
	public $FRGN_ADIT1_TEL;
	public $FRGN_ADIT2_TEL;
	public $FRGN_ADIT3_TEL;
	public $FRGN_ADIT4_TEL;
	public $FRGN_ADIT5_TEL;
	public $LAST_ACAR_CD;
	public $LAST_ACAR_NM;
	public $HGSC_CD;
	public $HGSC_NM;
	public $HGSC_CS_CD;
	public $HGSC_CS_NM;
	public $HGSC_LCTP_CD;
	public $HGSC_LCTP_NM;
	public $HGSC_TEL_ANO;
	public $HGSC_TEL1;
	public $HGSC_TEL2;
	public $HGSC_FAX_ANO;
	public $HGSC_FAX1;
	public $HGSC_FAX2;
	public $HGSC_PSNO;
	public $HGSC_ADD;
	public $HGSC_TP_CD;
	public $HGSC_TP_NM;
	public $GRDT_PRNG_YY;
	public $GRDT_PRNG_MCNT;
	public $GED_PSXA_AREA_CD;
	public $GED_PSXA_AREA_NM;
	public $GED_PSXA_YY;
	public $GED_PSXA_MCNT;
	public $GED_PSXA_DD;
	public $GED_ONLN_OFR_AGRM_YN;
	public $GED_OFR_AGRM_CFRM_NO;
	public $PRPORT_RFND_MTHD;
	public $BNK_CD;
	public $BNK_NM;
	public $ACHL;
	public $ACNO;
	public $FRGN_NO_YN;
	public $RGST_TIME;
	public $WORK_GUBN;
	public $CUD_GUBN;
	//public $IF_ID;
	public $IF_STATUS;
	//public $IF_TIME;
	public $IF_MESSG;
	
	public $RRNO_UPDATE_YN;
	public $PREV_PSNO;
	public $ACNO_CRTF_STTS; //string
    public $HGSC_PREV_PSNO; //string
    public $CNTY_ENG_CD; //string
    
    
}

class IF_COMMON_ENT002_RCV extends ORM{
	var $oci = null;
	function IF_COMMON_ENT002_RCV(& $oci){		
		parent::ORM($oci);
	}
}

function DEBUG($msg, $prefix= ""){
	echo "<xmp>";
	if(is_array($msg)){
		print_r($msg);				
	} else {
		echo $msg."\n";
	}
	echo "</xmp>";
}


//function batch_process($lsn,$if_rcv,$ka){
function batch_process($if_rcv,$ka){
	
	global $_REQUEST_KEY;
	
	$seq = '0';
	
	
	$where = array('SEQ'=>array('>', $seq), 'IF_STATUS' => 'R');
	$rows = $if_rcv->pull($where,$exp='*',$orderby=" ORDER BY SEQ ASC ");
	
	//foreach($rows as $row){
	//	$if_rcv->push(array('SEQ'=>$row['SEQ'], 'IF_STATUS'=>'P'));
	//}

	if(count($rows) > 0) { foreach($rows as $row){
		
		$_REQUEST_KEY = rand(5, 15)."_".round(microtime(true) * 1000);
		
		log_message( 'info', array(
			'title' => 'ȸ������-IF_COMMON_ENT002_RCV',
			'msg' => 'ȸ������ ������ - �����غ�',
			'idx2' => $_REQUEST_KEY,
			'idx1' => $row['INTEG_ID'],
			'idx3' => $row['SEQ'],
			'data' => serialize($row)
		) );

		if(empty($row['INTEG_ID'])){
			$if_rcv->push(array('SEQ'=>$row['SEQ'], 'IF_STATUS'=>'F','IF_MESSG'=>'ȸ������ ������-�������(INTEG_ID�� ����)'));
			//$lsn->write($row['SEQ']);
			
			log_message( 'error', array(
				'title' => 'ȸ������-IF_COMMON_ENT002_RCV',
				'msg' => 'ȸ������ ������ - �������(���̵� ����)',
				'idx2' => $_REQUEST_KEY,
				'idx1' => $row['INTEG_ID'],
				'idx3' => $row['SEQ'],
				'data' => serialize($row)
			) );
			
			continue;
		}
		
		
		if(empty($row['RGST_TIME'])){
			$if_rcv->push(array('SEQ'=>$row['SEQ'], 'IF_STATUS'=>'F','IF_MESSG'=>'ȸ������ ������ - �������(RGST_TIME ����)'));
			//$lsn->write($row['SEQ']);
		
			log_message( 'error', array(
			'title' => 'ȸ������-IF_COMMON_ENT002_RCV',
			'msg' => 'ȸ������ ������ - �������(RGST_TIME ����)',
			'idx2' => $_REQUEST_KEY,
			'idx1' => $row['INTEG_ID'],
			'idx3' => $row['SEQ'],
			'data' => serialize($row)
			) );
		
			continue;
		}
		
		
		$data = $ka->pull(array("INTEG_ID"=>$row['INTEG_ID']));
		if(isset($data[0])){
			$data_row = $data[0];
		} else {
			$data_row = array();
		}
		
		
		
		//����������̺��� ���� ������
		
		if(count($data_row) > 0){
			
			if(strtotime($row['RGST_TIME']) < strtotime($data_row['RGST_TIME'])){
				$if_rcv->push(array('SEQ'=>$row['SEQ'], 'IF_STATUS'=>'F','IF_MESSG'=>'ȸ������ ������ - �������(DB�����ͺ��� ������ ������)'));
				//$lsn->write($row['SEQ']);
					
				log_message( 'error', array(
				'title' => 'ȸ������-IF_COMMON_ENT002_RCV',
				'msg' => 'ȸ������ ������ - �������(DB�����ͺ��� ������ ������)',
				'idx2' => $_REQUEST_KEY,
				'idx1' => $row['INTEG_ID'],
				'idx3' => $row['SEQ'],
				'data' => $row['RGST_TIME'],
				'db_data' => $data_row['RGST_TIME']
				) );
			
				continue;
			}
		}
		
		
		//$data = $ka->pull(array("INTEG_ID"=>$row['INTEG_ID']));

		if($ka->push($row) == 1){
			log_message( 'info', array(
				'title' => 'ȸ������-IF_COMMON_ENT002_RCV',
				'msg' => 'ȸ������ ������ - PUSH ���輺��',
				'idx2' => $_REQUEST_KEY,
				'idx1' => $row['INTEG_ID'],
				'idx3' => $row['SEQ'],
				'data' => serialize($row)
			) );
			$if_rcv->push(array('SEQ'=>$row['SEQ'], 'IF_STATUS'=>'S','IF_MESSG'=>'ȸ������ ������-���輺��'));
		} else {
			log_message( 'error', array(
				'title' => 'ȸ������-IF_COMMON_ENT002_RCV',
				'msg' => 'ȸ������ ������ - PUSH �������',
				'idx2' => $_REQUEST_KEY,
				'idx1' => $row['INTEG_ID'],
				'idx3' => $row['SEQ'],
				'data' => serialize($row)
			) );
			$if_rcv->push(array('SEQ'=>$row['SEQ'], 'IF_STATUS'=>'F','IF_MESSG'=>'ȸ������ ������-PUSH(Insert,Update) �������'));
		}
		
		//$lsn->write($row['SEQ']);
	}}
	

}
function main_loop(){
	
	global $_REQUEST_KEY;
	global $_INIT_CONFIG;
	global $_IS_DEV;
	global $_SERVER_IP;
	
	
	log_message( 'info', array(
		'title' => 'ȸ������-IF_COMMON_ENT002_RCV',
		'msg' => 'if_common_ent002 �ؽǽð� ȸ������ ���� ����',
		'idx2' => $_REQUEST_KEY
	) );
	
	
	$oci = connectOrmDB($_IS_DEV,$_SERVER_IP);
	$oci->db->error_check = 0;
	
	$if_rcv = new IF_COMMON_ENT002_RCV($oci);
	//$if_rcv->setLimit(_SYNC_LIMIT_);
	$if_rcv->setLimit(_SYNC_LIMIT_);

	$table_name =  $if_rcv->table();

	//$lsn = new LSN($oci,$table_name);
	
	
	
	// test �ʱ�ȭ 
	

	$max_per_process = 1;
	$i= 0;

	//while($i++ < $max_per_process) {
	while(true) {
		
		$config = parse_ini_file(_CONFIG_INI_);
		
		if($config["run"]===false || $config["version"] != $_INIT_CONFIG["version"]){
			break;
		}
		
		
		//$lsn->write('0');
		
		$kcasOci = connectBatchKcasDB($_IS_DEV);
		$kcasOci->db->error_check = 0;
		$kcasOci->db->error_print = 0;
		$ka = new KcasApply($kcasOci);
		
		//batch_process($lsn,$if_rcv,$ka);
		batch_process($if_rcv,$ka);
		
		$kcasOci->disconnect();
		
		sleep(5);
	}
	
	log_message( 'info', array(
		'title' => 'ȸ������-IF_COMMON_ENT002_RCV',
		'msg' => 'if_common_ent002 �ؽǽð� ȸ������ ���� ����',
		'idx2' => $_REQUEST_KEY,
		'init_config' => $_INIT_CONFIG,
		'config' => $config
	) );
}



main_loop();

?>