<?

ini_set("memory_limit", '500M');

error_reporting(E_ALL&~E_NOTICE); //����������
//error_reporting(false);
//ini_set('error_reporting', 0);

if(strpos(basename(__FILE__), "dev.php") === false){
	$_IS_DEV = false;
} else {
	$_IS_DEV = true;
}

$_SERVER_IP = $argv[1];

$_REQUEST_KEY = rand(5, 15)."_".round(microtime(true) * 1000);

if(php_sapi_name()=="cli"){
if(!$_IS_DEV){
		$_SERVER['SERVER_NAME'] = "EAI";
		$_SERVER['REQUEST_URI'] = "EAI";
	} else {
		$_SERVER['SERVER_NAME'] = "EAI_DEV";
		$_SERVER['REQUEST_URI'] = "EAI_DEV";
	}
	$_SERVER['REMOTE_ADDR'] = $argv[1];
	$_SERVER['SERVER_ADDR'] = $argv[1];
} else {
	die();
}

require_once(dirname(__FILE__)."/../conf/config.inc");

//$_SITE_ROOT_ = dirname(dirname(__FILE__))."/../..";




class IF_USER_ENT003_RCV_COLS{
	public $INTEG_ID_HASH;
	//public $SEQ;
	public $WORK_DATE;
	public $OUT_DATE;
	public $OUT_REASON;
	public $OUT_YN;
	public $WORK_GUBN;
	public $CUD_GUBN;
	//public $IF_ID;
	public $IF_STATUS;
	//public $IF_TIME;
	public $IF_MESSG;
		
}

class IF_USER_ENT003_RCV extends ORM{
	var $oci = null;
	function IF_USER_ENT003_RCV(& $oci){		
		parent::ORM($oci);
	}
}

function DEBUG($msg, $prefix= ""){
	echo "<xmp>";
	if(is_array($msg)){
		print_r($msg);				
	} else {
		echo $msg."\n";
	}
	echo "</xmp>";
}

//function batch_process($lsn,$if_rcv,$ka,$kuo){
function batch_process($if_rcv,$ka,$kuo){
	
	
	global $_REQUEST_KEY;
	
	//$seq = $lsn->read();
	$seq = '0';
	
	
	$where = array('SEQ'=>array('>', $seq), 'IF_STATUS' => 'R');
	$rows = $if_rcv->pull($where,$exp='*',$orderby=" ORDER BY SEQ ASC ");
	
	//foreach($rows as $row){
	//	$if_rcv->push(array('SEQ'=>$row['SEQ'], 'IF_STATUS'=>'P'));
	//}

	if(count($rows) > 0) { foreach($rows as $row){
		
		$_REQUEST_KEY = rand(5, 15)."_".round(microtime(true) * 1000);
		
		log_message( 'info', array(
			'title' => 'ȸ������-IF_USER_ENT003_RCV',
			'msg' => 'ȸ������ ������ - �����غ�',
			'idx1' => $_REQUEST_KEY,
			//'idx2' => $row['INTEG_ID'],
			'idx3' => $row['SEQ'],
			'idx4' => $row['INTEG_ID_HASH'],
			'data' => serialize($row)
		) );

		if(empty($row['INTEG_ID_HASH'])){
			$if_rcv->push(array('SEQ'=>$row['SEQ'], 'IF_STATUS'=>'F','IF_MESSG'=>'ȸ������ ������-�������(INTEG_ID_HASH�� ����)'));
			//$lsn->write($row['SEQ']);
			
			log_message( 'error', array(
				'title' => 'ȸ������-IF_USER_ENT003_RCV',
				'msg' => 'ȸ������ ������ - �������(INTEG_ID_HASH�� ����)',
				'idx1' => $_REQUEST_KEY,
				//'idx2' => $row['INTEG_ID'],
				'idx3' => $row['SEQ'],
				'idx4' => $row['INTEG_ID_HASH'],
				'data' => serialize($row)
			) );
			
			
			continue;
		}
		//DEBUG($row);
		//$data = $ka->pull(array("INTEG_ID"=>$row['INTEG_ID']));
		//���� Ż��� �����ؾ� �ϴ� �κ�
		//Ż����� OUT_REASON ���� ���� ó��
		
		
		$data = $ka->pull(array("INTEG_ID_HASH"=>$row['INTEG_ID_HASH']));
		if(isset($data[0])){
			$data_row = $data[0];
		} else {
			$data_row = array();
		}
		
		
		
		if($ka->outNokieaiByINTEG_ID_HASH($kuo,$row['INTEG_ID_HASH'],$row['OUT_REASON'])){
			
			log_message( 'info', array(
				'title' => 'ȸ������-IF_USER_ENT003_RCV',
				'msg' => 'ȸ������ ������ - Ż�� ���輺��',
				'idx2' => $_REQUEST_KEY,
				'idx1' => $data_row['INTEG_ID'],
				'idx3' => $row['SEQ'],
				'idx4' => $row['INTEG_ID_HASH'],
				'data' => serialize($row)
			) );
			
			$if_rcv->push(array('SEQ'=>$row['SEQ'], 'IF_STATUS'=>'S','IF_MESSG'=>'ȸ������ ������-Ż�𿬰輺��'));
		} else {
			log_message( 'error', array(
				'title' => 'ȸ������-IF_USER_ENT003_RCV',
				'msg' => 'ȸ������ ������ - Ż�� �������',
				'idx2' => $_REQUEST_KEY,
				'idx1' => $data_row['INTEG_ID'],
				'idx3' => $row['SEQ'],
				'idx4' => $row['INTEG_ID_HASH'],
				'data' => serialize($row)
			) );
			$if_rcv->push(array('SEQ'=>$row['SEQ'], 'IF_STATUS'=>'F','IF_MESSG'=>'ȸ������ ������-Push Delete Ż�� �������'));
		}
		
		//$lsn->write($row['SEQ']);
	}}
	

}
function main_loop(){
	
	global $_REQUEST_KEY;
	global $_INIT_CONFIG;
	global $_IS_DEV;
	global $_SERVER_IP;
	
	log_message( 'info', array(
		'title' => 'ȸ������-IF_USER_ENT003_RCV',
		'msg' => 'if_user_ent003 �ؽǽð� ȸ������ ���� ����',
		'idx2' => $_REQUEST_KEY
	) );

	$oci = connectOrmDB($_IS_DEV,$_SERVER_IP);
	$oci->db->error_check = 0;
	
	$if_rcv = new IF_USER_ENT003_RCV($oci);
	$if_rcv->setLimit(_SYNC_LIMIT_);

	$table_name =  $if_rcv->table();

	//$lsn = new LSN($oci,$table_name);
	
	
	
	// test �ʱ�ȭ 
	//$lsn->write('0');

	$max_per_process = 1;
	$i= 0;

	//while($i++ < $max_per_process) {
	while(true) {
		
		$config = parse_ini_file(_CONFIG_INI_);
		
		if($config["run"]===false || $config["version"] != $_INIT_CONFIG["version"]){
			break;
		}
		
		$kcasOci = connectBatchKcasidsDB($_IS_DEV);
		$kcasOci->db->error_check = 0;
		$kcasOci->db->error_print = 0;
		$ka = new KcasUser($kcasOci);
		$kuo = new KcasUserOut($kcasOci);
		
		//batch_process($lsn,$if_rcv,$ka,$kuo);
		batch_process($if_rcv,$ka,$kuo);
		
		$kcasOci->disconnect();
		
		sleep(5);
	}
	
	
	
	log_message( 'info', array(
		'title' => 'ȸ������-IF_USER_ENT003_RCV',
		'msg' => 'if_user_ent003 �ؽǽð� ȸ������ ���� ����',
		'idx2' => $_REQUEST_KEY,
		'init_config' => $_INIT_CONFIG,
		'config' => $config
	) );
}



main_loop();

?>