<?
/*
CLOSE_WAIT �˻�
*/

//= ����� ����ó
$thisDIR = dirname(__FILE__);
require_once($thisDIR.'/../../conf/config.inc');
require_once($thisDIR.'/monitor_conf.inc');				//��ȭ��ȣ �� ��Ÿ ����

$LMTCNT = 3;
$ports  = array('57710', '57711');


$phones = array_merge($phone_dev_support, $phone_etc);

// �׽�Ʈ��
// $phones =array('010-2623-6344');
// $LMTCNT =0;
$isTime1 = ( date("YmdHi")>=$_MONITOR_S_DATETIME && date("YmdHi")<=$_MONITOR_E_DATETIME ) ? true : false;
// $isTime2 = ( date("Hi") >= '0700' && date("Hi") <= '2359' ) 									? true : false;
// $isTime3 = ( date("Hi") >= '0000' && date("Hi") <= '0059' ) 									? true : false;
// $isTime4 = ( date("Hi") >= '2300' && date("Hi") <= '2359' ) 									? true : false;

//if( $isTime1 && ( $isTime2 || $isTime3 ) )
if( $isTime1 )
{
	//echo 'start';
}else
{
	die('Time End');
}

$rsts = array();
foreach ( $ports as $port ) {
	$netstat = "netstat -ant | grep ".$port." | grep CLOSE_WAIT | wc -l";
	$cnt     = (int)exec($netstat);	

	if( $cnt >= $LMTCNT )
	{
		$rsts[]    = array( 'PORT' => $port, 'CNT' => $cnt );
	}
}

if( count($rsts) > 0 ){

	$severName = php_uname('n') ;

	require_once($thisDIR.'/../../common/class.EMSAuto.inc');

	//�ڵ�EMS ��ü ����
	$ems=new EMSAuto();
	//$ems->error_check	=1;
	//$ems->error_print	=1;
	//�ڵ�EMS DB ����
	$ems->connect();

	$param['SMS_CODE']  ='98';
	$param['DEPT_CODE'] ='2020';

	$msg = '[CLOSE_WAIT]('.$ips[$severName].'����)'.PHP_EOL;
	foreach ($rsts as $rst ) {
			$msg .= $rst['PORT'].':PORT '.$rst['CNT'].'��'.PHP_EOL;
	}
	
	$param['MSG']       = substr($msg,0,80);

	foreach($phones as $phone)
	{
			$param['HANDPHONE'] = $phone;
			$ems->sendSMS($param);
	}

	echo "<pre>";
	print_r($param);
	echo "</pre>";
}
?>
