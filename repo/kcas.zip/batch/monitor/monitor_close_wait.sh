#!/bin/bash

# Oracle Specific Environment and Startup Programs
if test -f /usr/local/apache2/bin/envvars; then
  . /usr/local/apache2/bin/envvars
fi

export PATH=$PATH:/usr/local/CrossCertLIB
export LD_LIBRARY_PATH=$LD_LIBRARY_PATH:/usr/local/CrossCertLIB


#/usr/local/php/bin/php /data/project/uwayapply.com/kcas/batch/monitor/monitor_close_wait.php
/usr/local/php/bin/php /data/project/uwayapply.com/kcas/batch/monitor/monitor_agent_restart_chk.php