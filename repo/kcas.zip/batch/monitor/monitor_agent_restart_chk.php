<?
/*
AGENT RESTART�� �˸�....
*/

//= ����� ����ó
$thisDIR = dirname(__FILE__);
require_once($thisDIR.'/../../conf/config.inc');
require_once($thisDIR.'/monitor_conf.inc');				//��ȭ��ȣ �� ��Ÿ ����

$LMT_TERM = 70; //1��
$ports    = array('57710', '57711');

$phones   = array_merge($phone_dev_support, $phone_etc);
//$phones   = array_merge($phone_dev_support);


//�׽�Ʈ��
// $phones =array('010-2623-6344');



$isTime1 = ( date("YmdHi")>=$_MONITOR_S_DATETIME && date("YmdHi")<=$_MONITOR_E_DATETIME ) ? true : false;
// $isTime2 = ( date("Hi") >= '0700' && date("Hi") <= '2359' ) 									? true : false;
// $isTime3 = ( date("Hi") >= '0000' && date("Hi") <= '0059' ) 									? true : false;
// $isTime4 = ( date("Hi") >= '2300' && date("Hi") <= '2359' ) 									? true : false;

//if( $isTime1 && ( $isTime2 || $isTime3 ) )
if( $isTime1 )
{
	//echo 'start';
}else
{
	die('Time End');
}

$date = date("Ymd");

$rsts = array();
foreach ( $ports as $port ) {
	$grep = "grep 'Start Deamon Process' /home/megaware/script/log/{$port}_{$date}";

	//$grep = "grep 'Start Deamon Process' /home/megaware/script/log/57711_20151226";
	//$startDate = trim(substr(exec($grep), 0, 12)).'00';

	$grep_str = exec($grep);	
	list($mdate,$c) = explode(':', $grep_str);
	$mdate = trim($mdate);
	if(strlen($mdate) == 12) {
	    $mdate = $mdate."00";
	}
	$startDate = $mdate;
	
	// $startDate= '20151228105000';
	if( strlen($startDate) == 14 )
	{
		$now  = strtotime(date('YmdHis') );
		$term = $now - strtotime($startDate);

		if( $term <= $LMT_TERM )
		{
			$rsts[] = substr($startDate, 0,12).' ['.$port.']'.' Start';
		}
	}
}

if( count($rsts) > 0 ){

	$severName = php_uname('n') ;

	require_once($thisDIR.'/../../common/class.EMSAuto.inc');

	//�ڵ�EMS ��ü ����
	$ems=new EMSAuto();
	//$ems->error_check	=1;
	//$ems->error_print	=1;
	//�ڵ�EMS DB ����
	$ems->connect();

	$param['SMS_CODE']  ='98';
	$param['DEPT_CODE'] ='2020';

	$msg = '[RESTART]('.$ips[$severName].'����)'.PHP_EOL;
	foreach ($rsts as $rst ) {
			$msg .= $rst.PHP_EOL;
	}
	
	$param['MSG']       = substr($msg,0,80);

	foreach($phones as $phone)
	{
			$param['HANDPHONE'] = $phone;
			$ems->sendSMS($param);
	}

	echo "<pre>";
	print_r($param);
	echo "</pre>";
}
?>
