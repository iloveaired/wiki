#!/bin/bash
/usr/local/php/bin/php /data/project/uwayapply.com/klog/batch_klog/smsLog.php