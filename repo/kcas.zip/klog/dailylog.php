<?php
define('_GET_LOG_PATH'		, '/data/log/LOGD/testlog'	);
define('_PUT_LOG_PATH'		, '/data/log/kcas/log'		);
define('_SEQ_PATH'			, '/data/log/kcas/seq'		);
define('_ERR_LOG_PATH'		, '/data/log/apache/batch_error'	);

$day = ( empty($argv[1]) ) ? date('Ymd',strtotime("-1 day",time())) : $argv[1];
$seq = getSeq();

function logJob( $day, $hour, & $seq )
{
	$mode = ($hour == '00') ? 'w' : 'a';

	$fpG = @fopen( _GET_LOG_PATH . '/' . $day . '/' . $hour, 'r');
	$fpP = @fopen( _PUT_LOG_PATH . '/uway_'.$day.'.txt', $mode	);

	if( ! $fpG ) return false;
	if( ! $fpP ) return false;

	while( feof( $fpG ) === FALSE && $line = fgets( $fpG ) )
	{
		$lines = explode( ' ', $line, 3 );

		if( is_array( $lines ) === FALSE )
		{
			errLog($day, '�������	'. $line);
			continue;
		}
		$v = unserialize($lines[2]);
		
		if( is_array( $v ) === FALSE )
		{
			errLog($day, 'unserialize����	'. $lines[2]);
			continue;
		}

		if( empty($v['KLOG']) === TRUE )
		{
			errLog($day, 'KLOG������	'. $lines[2] );
			continue;
		}

		$row = seqMerge( $v['KLOG'], $seq );
		@fwrite($fpP, $row . PHP_EOL );
	}
	@fclose( $fpG );
	@fclose( $fpP );
} // 


function errLog( $day, $msg )
{
	$file = _ERR_LOG_PATH.'/klog_'.$day.'.txt';
	$fp = @fopen( $file, 'a');	

	$msg = date("Y-m-d H:i:s") . '	' . $msg;
	@fwrite($fp, $msg. PHP_EOL);
	@fclose( $fp );
}

function seqMerge( $row, & $seq )
{
	$tmp	= explode(chr(9), $row);
	$tmp[4] = substr('000000000'.++$seq,-10);
	return implode(chr(9), $tmp);
}

function getSeq()
{
	$fp = @fopen( _SEQ_PATH . '/seq.txt', 'r');
	$tmp= @fgets( $fp );
	@fclose( $fp );

	if(!is_numeric($tmp))
	{
		$seq=0;
	}else{
		$seq=(integer)$tmp;	
	}

	return $seq;
}

function setSeq( $day, $seq )
{
	$fp= @fopen( _SEQ_PATH . '/seq.txt'	, 'w');
	@fwrite( $fp, $seq );
	@fclose( $fp );

	$fp= @fopen( _SEQ_PATH . '/seqLog.txt', 'a');
	@fwrite( $fp, $day.chr(9).$seq.PHP_EOL );
	@fclose( $fp );
}


//logJob( $_GET_LOG_PATH, $_PUT_LOG_PATH, date('Ymd',strtotime("-1 day",time())), 17);
for( $i = 0; $i <= 23; $i++ )
{
	$h = substr('0'.$i, -2);
	logJob( $day, $h, $seq );
}

setSeq( $day, $seq );
?>