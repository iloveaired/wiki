<?php
define('_GET_LOG_PATH'		, '/data/log/LOGD/testlog'	);

function getLog( $day, $hour )
{
	$rst = array();

	$fpG = @fopen( _GET_LOG_PATH . '/' . $day . '/' . $hour, 'r');

	if( ! $fpG ) return $rst;

	while( feof( $fpG ) === FALSE && $line = fgets( $fpG ) )
	{
		$lines = explode( ' ', $line, 3 );

		if( is_array( $lines ) === FALSE ) continue;

		$v = unserialize($lines[2]);
		
		if( is_array( $v ) === FALSE ) continue;

		if( empty($v['KLOG']) === TRUE ) continue;

		$rst[] = $v['KLOG'];
	}
	@fclose( $fpG );

	return $rst;
} // 
if( empty($_REQUEST['y']) )
{
	$day = date('Ymd');
	$_REQUEST['y']=substr($day, 0,4);
	$_REQUEST['m']=substr($day, 4,2);
	$_REQUEST['d']=substr($day, 6,2);
}else{
	$day = $_REQUEST['y'].$_REQUEST['m'].$_REQUEST['d'];
}

$h = ( empty($_REQUEST['h']) ) ? '09' : $_REQUEST['h'];

$data = getLog($day,$h);
?>
<p>�˻�</p>
<table border="0">
	<tr>
		<td>
		<form action="./loglist.php"  method="post">
		<select name="y" onChange="this.form.submit();">
			<option value="2015" <?= ( '2015' == $_REQUEST['y'] ) ? 'selected':'' ?> >2015</option>
		</select>��
		<select name="m"  onChange="this.form.submit();">
<?for( $i = 1; $i <= 12; $i++ ){?><option value="<?= substr('0'.$i, -2);?>" <?= ( substr('0'.$i, -2) == $_REQUEST['m'] ) ? 'selected':'' ?>><?= substr('0'.$i, -2);?></option><?}?>
		</select>��
		<select name="d"  onChange="this.form.submit();">
<?for( $i = 1; $i <= 31; $i++ ){?><option value="<?= substr('0'.$i, -2);?>" <?= ( substr('0'.$i, -2) == $_REQUEST['d'] ) ? 'selected':'' ?>><?= substr('0'.$i, -2);?></option><?}?>
		</select>��

		<select name="h"  onChange="this.form.submit();">
<?for( $i = 0; $i <= 23; $i++ ){?><option value="<?= substr('0'.$i, -2);?>" <?= ( substr('0'.$i, -2) == $_REQUEST['h'] ) ? 'selected':'' ?>><?= substr('0'.$i, -2);?></option><?}?>
		</select>��
	    </td>
	</form>
	</tr>
</table>

<p>���</p>
<table border="1">

<?
foreach( $data as $v ){ 
	$rows = explode( '	', $v );
?>
	<tr>
<?	foreach( $rows as $row ){?>
		<td><?= $row?></td>
<?	}?>
	</tr>
<?}?>
</table>

