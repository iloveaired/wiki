<?php
define('_GET_LOG_PATH', '/data/log/kcas/smslog'					);
define('_PUT_LOG_PATH', '/data/log/kcas/sms'						);
define('_SEQ_PATH'    , '/data/log/kcas/seq'						);
define('_ERR_LOG_PATH', '/data/log/apache/batch_error'	);

$day   =( empty($argv[1]) ) ? date('Ymd',strtotime("-1 day",time())) : $argv[1];
$jabId =array('hp01','sms01','sms02','sms03','sms_daou01','sms_daou02','sms_daou03');		//���� �α����� id


function logJob( $day, $jobId, & $seq )
{
	$fileGet = _GET_LOG_PATH . '/uway_'.$jobId.'_'.$day.'.txt';
	$filePut = _PUT_LOG_PATH . '/uway_'.$jobId.'_'.$day.'.txt';

	$fpG = @fopen( $fileGet, 'r');
	$fpP = @fopen( $filePut, 'w');

	if( ! $fpG ) return false;
	if( ! $fpP ) return false;

	while( feof( $fpG ) === FALSE && $line = fgets( $fpG ) )
	{
		$row = seqMerge( $line, $seq );
		@fwrite($fpP, $row);
	}
	@fclose( $fpG );
	@fclose( $fpP );
} // 


function errLog( $day, $msg )
{
	$file = _ERR_LOG_PATH.'/klog_sms_'.$day.'.txt';
	$fp = @fopen( $file, 'a');	

	$msg = date("Y-m-d H:i:s") . '	' . $msg;
	@fwrite($fp, $msg. PHP_EOL);
	@fclose( $fp );
}

function seqMerge( $row, & $seq )
{
	$tmp	= explode(chr(9), $row);
	$tmp[4] = substr('000000000'.++$seq,-10);
	return implode(chr(9), $tmp);
}

function getSeq()
{
	$fp = @fopen( _SEQ_PATH . '/smsSeq.txt', 'r');
	$tmp= @fgets( $fp );
	@fclose( $fp );

	$v = unserialize($tmp);

	if($v)
	{
		return $v;
	}else{
		return array();
	}
}

function setSeq( $day, $smsSeq )
{
	$seq = serialize($smsSeq);

	$fp= @fopen( _SEQ_PATH . '/smsSeq.txt'	, 'w');
	@fwrite( $fp, $seq );
	@fclose( $fp );

	$fp= @fopen( _SEQ_PATH . '/smsSeqLog.txt', 'a');
	@fwrite( $fp, $day.chr(9).$seq.PHP_EOL );
	@fclose( $fp );
}


//-------------------------------------------------------------------
//�α����� ����
//-------------------------------------------------------------------
$smsSeq = getSeq();

foreach($jabId as $v)
{
	$smsSeq[$v] = ( isset($smsSeq[$v]) === false || empty($smsSeq[$v]) === true ) ? 0 : $smsSeq[$v];

	logJob( $day, $v, $smsSeq[$v] );
}
setSeq( $day, $smsSeq );
//-------------------------------------------------------------------


?>