/*
 * Copyright : ���������� �̴���
 * ���糯¥ : 2015-06-08
 */
var kcasOzManager = (function(){
	var options = {
		encrypt_gb:null
		,encrypt_key:null
		,encrypt_hash_or_devel_key:null
	}
	
	
	var k = new function(){
		
		//�ʱ�ȭ
		this.init = function(){
			this.setEncryptGb();
		}
		
		//��ȣȭ ��� ���� �����Լ�
		this.setEncryptGb = function(set_encrypt_gb){
			switch(set_encrypt_gb){
				case 'user': options.encrypt_gb = set_encrypt_gb; break;
				case 'admin': options.encrypt_gb = set_encrypt_gb; break;
				default: options.encrypt_gb = 'user'; break;
			}
		}
		//��ȣȭ ��� ���ð� ��ȯ �Լ�
		this.getEncryptGb = function(){
			return options.encrypt_gb;
		}

		
		//this.getEncryptKey = function(){
		//	return options.encrypt_key;
		//}
		
		//��ȣȭ ��ȣ Ű�� ���� �Լ�
		this.setEncryptKey = function(set_encrypt_key, opener_bool, fn){
			
			if(opener_bool){
				options.encrypt_hash_or_devel_key = set_encrypt_key;
				SetBaseKey("ARIA", options.encrypt_hash_or_devel_key);
				if(fn){
					fn(options);
				}
				return;
			}
			
			switch(options.encrypt_gb){
				case 'user':
					options.encrypt_hash_or_devel_key = Hash("SHA256", set_encrypt_key);
					SetBaseKey("ARIA", options.encrypt_hash_or_devel_key);
					
					break;
				case 'admin':
					try{
						if (!(typeof options.encrypt_hash_or_devel_key === 'string' && options.encrypt_hash_or_devel_key == ''))
						{
							options.encrypt_hash_or_devel_key = Develop(set_encrypt_key, "KnownUserBased");
						}
						SetBaseKey("ARIA", options.encrypt_hash_or_devel_key);
					}
					catch(e){
						return false;
					}
					break;
				default:
					alert('��ȣȭ ��� ������ �����ϴ�.');
					return false;
					break;
			}
			
			options.encrypt_key = set_encrypt_key;
			
			if(fn){
				fn(options);
			}
		}
		
		//��ȣȭ ��ȣ Ű�� ��ȯ �Լ�
		this.getEncryptHashOrDevelKey = function(){
			return options.encrypt_hash_or_devel_key;
		}
		
		//��ȣȭ ������ ��ȣȭ �Լ�
		this.getDecrypt = function(encrypt_data,base64){
			
			//----------------------------------------------------------------------------------
			// WS ������ ������� �߰��� �κ� - Start
			//----------------------------------------------------------------------------------
			
			if(USER_BROWSER == GOOGLE_CHROME){
				if(WsData.decryptList[encrypt_data]) return WsData.decryptList[encrypt_data];
				else return "";
			}
			//----------------------------------------------------------------------------------
			// WS ������ ������� �߰��� �κ� - End
			//----------------------------------------------------------------------------------

			var return_data = "";
			
			return_data = KnownKeyBasedDecryptData(encrypt_data);
			if(base64 && return_data.length != 0){
//				return_data = Base64Decode(return_data);
				return_data = Base64.decode(return_data);
			}
			if(return_data.length != 0)	return return_data;
			else false;
		}
		
		//��ȣȭ ������ ��ȣȭ �Լ�
		this.getDecryptWithSetEncryptKey = function(data, base64){
			
			var return_data;
			
			//----------------------------------------------------------------------------------
			// WS ������ ������� �߰��� �κ� - Start
			//----------------------------------------------------------------------------------
			
			if(USER_BROWSER == GOOGLE_CHROME){
				if(WsData.decryptList[data]) return WsData.decryptList[data];
				else return "";
			}
			
			//----------------------------------------------------------------------------------
			// WS ������ ������� �߰��� �κ� - End
			//----------------------------------------------------------------------------------
			
			var temp_data = data.split("^^^");
			var set_encrypt_key = temp_data[0];
			var encrypt_data = temp_data[1];

			if(options.encrypt_key != set_encrypt_key){
				this.setEncryptKey(set_encrypt_key);
			}

			return_data = KnownKeyBasedDecryptData(encrypt_data);

			if(base64 && return_data.length != 0){
//				return_data = Base64Decode(return_data);
				return_data = Base64.decode(return_data);
			}
			
			if(return_data.length != 0)	return return_data;
			else false;
		}
		
		
		//�ʱ�ȭ �Լ� ����
		this.init();
	};
	
	return k;
})();

// ����� decode�� �ϴ� ���� �Ʒ� �Լ��� �߰��ϰ�
// var decData = Base64.decode(data) �� �̿��ؼ� decode �Ѵ�.
// ������� / �ڱ�Ұ��� / ��õ�� ��� �����մϴ�.
var Base64={_keyStr:"ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/=",encode:function(e){var t="";var n,r,i,s,o,u,a;var f=0;e=Base64._utf8_encode(e);while(f<e.length){n=e.charCodeAt(f++);r=e.charCodeAt(f++);i=e.charCodeAt(f++);s=n>>2;o=(n&3)<<4|r>>4;u=(r&15)<<2|i>>6;a=i&63;if(isNaN(r)){u=a=64}else if(isNaN(i)){a=64}t=t+this._keyStr.charAt(s)+this._keyStr.charAt(o)+this._keyStr.charAt(u)+this._keyStr.charAt(a)}return t},decode:function(e){var t="";var n,r,i;var s,o,u,a;var f=0;e=e.replace(/[^A-Za-z0-9\+\/\=]/g,"");while(f<e.length){s=this._keyStr.indexOf(e.charAt(f++));o=this._keyStr.indexOf(e.charAt(f++));u=this._keyStr.indexOf(e.charAt(f++));a=this._keyStr.indexOf(e.charAt(f++));n=s<<2|o>>4;r=(o&15)<<4|u>>2;i=(u&3)<<6|a;t=t+String.fromCharCode(n);if(u!=64){t=t+String.fromCharCode(r)}if(a!=64){t=t+String.fromCharCode(i)}}t=Base64._utf8_decode(t);return t},_utf8_encode:function(e){e=e.replace(/\r\n/g,"\n");var t="";for(var n=0;n<e.length;n++){var r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r)}else if(r>127&&r<2048){t+=String.fromCharCode(r>>6|192);t+=String.fromCharCode(r&63|128)}else{t+=String.fromCharCode(r>>12|224);t+=String.fromCharCode(r>>6&63|128);t+=String.fromCharCode(r&63|128)}}return t},_utf8_decode:function(e){var t="";var n=0;var r=c1=c2=0;while(n<e.length){r=e.charCodeAt(n);if(r<128){t+=String.fromCharCode(r);n++}else if(r>191&&r<224){c2=e.charCodeAt(n+1);t+=String.fromCharCode((r&31)<<6|c2&63);n+=2}else{c2=e.charCodeAt(n+1);c3=e.charCodeAt(n+2);t+=String.fromCharCode((r&15)<<12|(c2&63)<<6|c3&63);n+=3}}return t}}
