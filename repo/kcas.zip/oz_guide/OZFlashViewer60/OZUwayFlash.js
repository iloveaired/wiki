var SetOZParamters_OZViewer	= null;

var OZUwayFlash = (function(){
	
	var OZArgsArr = null;
	//Globals
	//Major version of Flash required
	var requiredMajorVersion = 10;
	//Minor version of Flash required
	var requiredMinorVersion = 0;
	//Minor version of Flash required
	var requiredRevision = 0;
	
	
	//Version check for the Flash Player that has the ability to start Player Product Install (6.0r65)
	var hasProductInstall = DetectFlashVer(6, 0, 65);

	//Version check based upon the values defined in globals
	var hasRequestedVersion = DetectFlashVer(requiredMajorVersion, requiredMinorVersion, requiredRevision);

	var k = new function(){
		
		this.SetOZParam = function(OZArgs){
			
			OZArgsArr = OZArgs;
			
			SetOZParamters_OZViewer = function(){
				var oz;
				if ( navigator.appName.indexOf("Microsoft") != -1 ) {
					oz = window["OZViewer"];
				} else {
					oz = document["OZViewer"];
				}
				
				oz.sendToActionScript(	"connection.servlet"			,OZArgsArr.servlet);
				oz.sendToActionScript(  "global.language"    ,	OZArgsArr.language);
				oz.sendToActionScript(	"connection.reportname"			,OZArgsArr.ozr_path);
				oz.sendToActionScript(	"viewer.configmode"			,"html");
				oz.sendToActionScript(	"odi.odinames"			,OZArgsArr.odi_names);
				
				oz.sendToActionScript(	"odi."+OZArgsArr.odi_names+".pcount"			,OZArgsArr.odi_user_params.length);
				for(var i=0,m=OZArgsArr.odi_user_params.length;i<m;i++){
					oz.sendToActionScript(	"odi."+OZArgsArr.odi_names+".args"+(i+1)			,OZArgsArr.odi_user_params[i]);
				}
				
				oz.sendToActionScript(	"export.applyformat"			,OZArgsArr.export_applyformat);
				oz.sendToActionScript(	"export.confirmsave"			,OZArgsArr.export_confirmsave);
				
				oz.sendToActionScript(	"toolbar.print"			,OZArgsArr.toolbar_print	);
				oz.sendToActionScript(	"toolbar.bgcolor"		,OZArgsArr.toolbar_bgcolor	);
				oz.sendToActionScript(	"toolbar.position"		,OZArgsArr.toolbar_position	);
				oz.sendToActionScript(	"toolbar.icon"			,OZArgsArr.toolbar_icon	);
				oz.sendToActionScript(	"toolbar.position"		,OZArgsArr.toolbar_position	);
				oz.sendToActionScript(	"toolbar.all"			,OZArgsArr.toolbar_all	);
				oz.sendToActionScript(	"toolbar.file"			,OZArgsArr.toolbar_file	);
				oz.sendToActionScript(	"toolbar.open"			,OZArgsArr.toolbar_open	);
				oz.sendToActionScript(	"toolbar.left"			,OZArgsArr.toolbar_left	);
				oz.sendToActionScript(	"toolbar.right"			,OZArgsArr.toolbar_right	);
				oz.sendToActionScript(	"toolbar.leftmost"		,OZArgsArr.toolbar_leftmost	);
				oz.sendToActionScript(	"toolbar.rightmost"		,OZArgsArr.toolbar_rightmost	);
				oz.sendToActionScript(	"toolbar.close"			,OZArgsArr.toolbar_close	);
				oz.sendToActionScript(	"toolbar.about"			,OZArgsArr.toolbar_about	);
				oz.sendToActionScript(	"toolbar.find"			,OZArgsArr.toolbar_find	);
				oz.sendToActionScript(	"toolbar.option"		,OZArgsArr.toolbar_option	);
				oz.sendToActionScript(	"toolbar.pagenavigator"		,OZArgsArr.toolbar_pagenavigator	);
							                                
				oz.sendToActionScript(	"toolbar.showtree"		,OZArgsArr.toolbar_showtree	);
				oz.sendToActionScript(	"toolbar.refresh"		,OZArgsArr.toolbar_refresh	);
				oz.sendToActionScript(	"toolbar.addmemo"		,OZArgsArr.toolbar_addmemo	);
				
				oz.sendToActionScript(	"viewer.ozscript_stropr_silent"		,"true"	);
				oz.sendToActionScript(	"viewer.ozscript_dateopr_silent"		,"true"	);
				oz.sendToActionScript(	"viewer.showerrormessage"		,"true"	);
				
				//oz.sendToActionScript("information.debug", "true");
				//oz.sendToActionScript("connection.fetchtype", "concurrent");
				
			
			
				return true;
				
			}
			
		}
		
		
		this.getOzViewer = function(){
			
			if(hasProductInstall && !hasRequestedVersion) {
				//DO NOT MODIFY THE FOLLOWING FOUR LINES
				//Location visited after installation is complete if installation is required
				var MMPlayerType = (isIE == true) ? "ActiveX" : "PlugIn";
				var MMredirectURL = window.location;
				document.title = document.title.slice(0, 47) + " - Flash Player Installation";
				var MMdoctitle = document.title;
				return AC_FL_RunContent (
					"src"			,OZArgsArr.viewer_path+"/playerProductInstall",
					"FlashVars"		,"MMredirectURL="+MMredirectURL+'&MMplayerType='+MMPlayerType+'&MMdoctitle='+MMdoctitle+"",
					"width"			,OZArgsArr.width,
					"height"		,OZArgsArr.height,
					"align"			,"middle",
					"id"			,"playerProductInstall",
					"quality"		,"high",
					"bgcolor"		,"#ffffff",
					"name"			,"playerProductInstall",
					"allowScriptAccess"	,"always",
					"type"			,"application/x-shockwave-flash",
					"pluginspage"		,"http://www.adobe.com/go/getflashplayer"
				);
			} else if(hasRequestedVersion) {
				
				return AC_FL_RunContent(
					"src"			,OZArgsArr.viewer_path+"/OZViewer10",
					"width"			,OZArgsArr.width,
					"height"		,OZArgsArr.height,
					"align"			,"middle",
					"id"			,"OZViewer",
					"quality"		,"high",
					"bgcolor"		,"#ffffff",
					"name"			,"OZViewer",
					"allowScriptAccess"	,"always",
					"type"			,"application/x-shockwave-flash",
					"pluginspage"		,"http://www.adobe.com/go/getflashplayer",
					"flashVars"		,"flash.objectid=OZViewer"
				);
			} else { //flash is too old or we can't detect the plugin
				var alternateContent = 'Alternate HTML content should be placed here. '
				                       + 'This content requires the Adobe Flash Player. '
				                       + '<a href=http://www.adobe.com/go/getflash/>Get Flash</a>';
				return alternateContent; //insert non-flash content
			}
			
			return false;
		}
	
	}
	
	return k;
})();