<object style="display:none;" ID="ZTransferX" CLASSID="CLSID:C7C7225A-9476-47AC-B0B0-FF3B79D55E67" codebase="https://nreport.uwayapply.com/ozviewer53/ZTransferX_2,2,3,7.cab#version=2,2,3,7">
<PARAM NAME="download.Server" VALUE="https://nreport.uwayapply.com/ozviewer/">
<PARAM NAME="download.Port" VALUE="80">
<PARAM NAME="download.Instruction" VALUE="ozrviewer.idf">
<PARAM NAME="install.Base" VALUE="<PROGRAMS>/Forcs">
<PARAM NAME="install.Namespace" VALUE="namseoul">
<PARAM NAME="debug" VALUE="TRUE">
</object>
<object id="ozviewer" style="width:1024px;height:900px" classid="CLSID:0DEF32F8-170F-46f8-B1FF-4BF7443F5F25">
<param name="applet.isframe" value="false">
<param name="viewer.namespace" value="namseoul\ozviewer">
<param name="connection.servlet" value="https://nreport.uwayapply.com/oz/server">
<param name="connection.clientdmtype" value="FILE">
<param name="connection.compresseddatamodule" value="true">
<param name="connection.refreshcache" value="true">
<param name="connection.serverdmtype" value="file">
<param name="connection.pageque" value="100">
<param name="connection.fetchtype" value="concurrent">
<param name="connection.reportname" value="/namseoul.net/pass_pay_y_rst_new.ozr">
<param name="viewer.bgcolor" value="FFFFFF">
<param name="viewer.mode" value="Preview">
<param name="viewer.useinborder" value="false">
<param name="viewer.useoutborder" value="false">
<param name="viewer.zoom" value="150">
<param name="viewer.ozscript_stropr_silent" value="true">
<param name="viewer.ozscript_dateopr_silent" value="true">
<param name="viewer.showerrormessage" value="true">
<param name="applet.configmode" value="html">
<param name="information.debug" value="true">
<param name="odi.odinames" value="pass_rst">
<param name="odi.pass_rst.pcount" value="5">
<param name="odi.pass_rst.args1" value="URL=http://kcas.uwayapply.com/oz_guide/namseoul/test.txt">
<param name="odi.pass_rst.args2" value="TITLE=�հ�������">
<param name="odi.pass_rst.args3" value="SUB_TITLE=�������� : ">
<param name="odi.pass_rst.args4" value="YEAR=2017">
<param name="odi.pass_rst.args5" value="TERM=����">
<param name="toolbar.print" value=true>
<param name="toolbar.bgcolor" value="EEEEEE">
<param name="toolbar.position" value="top">
<param name="toolbar.icon" value="top">
<param name="toolbar.position" value="top">
<param name="toolbar.all" value="true">
<param name="toolbar.file" value="true">
<param name="toolbar.open" value="false">
<param name="toolbar.left" value="false">
<param name="toolbar.right" value="false">
<param name="toolbar.leftmost" value="false">
<param name="toolbar.rightmost" value="false">
<param name="toolbar.close" value="false">
<param name="toolbar.about" value="false">
<param name="toolbar.find" value="false">
<param name="toolbar.option" value="false">
<param name="toolbar.pagenavigator" value="false">
<param name="toolbar.showtree" value="false">
<param name="toolbar.refresh" value="true">
<param name="toolbar.addmemo" value="false">
<param name="export.applyformat" value="pdf">
<param name="export.confirmsave" value="false">
<param name="pdf.author" value="��������б�">
<param name="pdf.creator" value="��������б�">
<param name="pdf.title" value="��������б� �հ�������">
<param name="pdf.subject" value="��������б� �հ�������">
</object>