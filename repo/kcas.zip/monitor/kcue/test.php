<?
require_once(dirname(__FILE__).'/../../conf/inc.conf.php');



$oci = new Altibase_OCI();	
$oci->connect('kcas','kcas12$','kcas',$dboption); //VIP : 222.231.38.11
	


function user_count($oci, $yyyymmdd){
	$date = "$yyyymmdd%";

	$query = "
			SELECT  INTEG_ID_YN, COMPANY_GUBN, count(*)    
	        FROM KCAS_USER 
			WHERE uway_insertdate like '$date'
			GROUP BY INTEG_ID_YN, COMPANY_GUBN
	"; 	
	
	$rows = $oci->getRowsName($query);

	return $rows;
}
function common_count($oci, $yyyymmdd){
	$date = "$yyyymmdd%";
	$query = "
			SELECT   count(*)
			  FROM KCAS_APPLY 
			  WHERE uway_insertdate like '$date'
	"; 		
	$rows = $oci->getRowsName($query);
	return $rows[0];
}

function self_count($oci, $yyyymmdd){
	$date = "$yyyymmdd%";
	$query = "
			SELECT   count(*)
			  FROM KCAS_APPLY 
			  WHERE uway_insertdate like '$date'
	"; 		
	$rows = $oci->getRowsName($query);
	return $rows[0];
}
echo "<xmp>";

$result = user_count($oci, "20150706");
print_r($result);

$result = common_count($oci, "20150706");
print_r($result);

$result = self_count($oci, "20150706");
print_r($result);



?>