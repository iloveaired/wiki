<?

class COMMON_ENT_RES_001{
 public $SEARCH_RSLT; // SEARCH_RSLT
}
class SEARCH_RSLT {
  public $INTEG_ID; // string
  public $CMF_UID; // string
  public $PERS_US_AGRM_YN; // string
  public $UNIQ_US_AGRM_YN; // string
  public $PERS_CONS_AGRM_YN; // string
  public $PERS_THREE_AGRM_YN; // string
  public $VLTN_GDNC_AGRM_YN; // string
  public $ONSL_QLFC_DT_AGRM_YN; // string
}

test1();
die();

$data = file_get_contents("sample2.txt");

$r = unserialize($data);

var_dump($r);

die();

function test1(){

	$rst = new COMMON_ENT_RES_001;

	$search_rslt	= new SEARCH_RSLT;
	
	$rst->SEARCH_RSLT = $search_rslt;
	


	$_RETURN = $rst;

	//$r =  json_decode(json_encode($_RETURN->SEARCH_RSLT));
	$r =  json_decode(json_encode($search_rslt));

	print_r($r);



}





?>
