<?



//$data = preg_replace('!s:(\d+):"(.*?)";!e', "'s:'.strlen('$2').':\"$2\";'",$data);
function eai_parse($data){
	$data = preg_replace('!s:(\d+):"(.*?)";!e', "'s:'.strlen('$2').':\"$2\";'", $data);
	$data = unserialize($data);
	if(!empty($data['server'])) $data['server'] = json_decode(str_replace("\\","",$data['server'])); 
	return $data;
}

$data = file_get_contents("sample.txt");

echo "<xmp>";

$r = eai_parse($data);
print_r($r);