<?
ini_set('allow_url_fopen', 'On');
$_MODE = "api";

require_once(dirname(__FILE__)."/../conf/inc.conf.php");
require_once($_SITE_ROOT_.'/php.auto_prepend_file.inc');



$log = array(
	'title' => 'Mobile Agent Log',
	'msg' => 'isMobile->'.$_REQUEST['isMobile'],
	'idx1' => $_SERVER['HTTP_USER_AGENT'],
	'idx2' => $_REQUEST['isMobile'],
	'idx3' => $_REQUEST['oid'],
	'idx4' => $_REQUEST['paycd']
);


$allow_arr = array(
	"HTTP_REFERER"
	,"HTTP_USER_AGENT"
	,"HTTP_HOST"
	,"QUERY_STRING"
);

$add_log = array();

foreach($_SERVER as $k=>$v){
	if(in_array($k,$allow_arr)){
		$add_log[$k] = $v;
	}
}



$log = array_merge($log,$add_log);


log_message( 'info', $log);


?>