<?


error_reporting(E_ALL&~E_NOTICE); //����������

require_once(dirname(dirname(__FILE__))."/../conf/inc.conf.php");
require_once($_SITE_ROOT_.'/php.auto_prepend_file.inc');


require_once($_SITE_ROOT_.'/common/class.UwayPDO.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/lib/class.ORM.php');
//require_once($_SITE_ROOT_.'/monitor/eai/class.ORM.php');

function & connection_database(){
	$oci = new MySQL_OCI();
	$mode = "real";
	if(isset($_SERVER['HTTP_HOST'][0])){
		$rt = preg_match('/^[^\.]*(dev|re)[^\.]*\./',$_SERVER['HTTP_HOST']);  //���߼���������
		if($rt) { $mode = "dev"; }
	
		$rt = preg_match('/^[^\.]*(devlcl)[^\.]*\./',$_SERVER['HTTP_HOST']);  //���߼���������
		if($rt) { $mode = "devlcl"; }	
	}

	if($mode == "real"){
		//$oci->connect('kcas','kcas12$','kcas');
		$oci->connect('megaware','megawareeoryguq!@#','megaware@192.168.3.21'); //�켱 ���ø����̼��� �����ؼ� ���
		//kcas_1
	} else if($mode == "dev"){		//$oci->connect('dkcas','dkcas12$','kcas');

		$oci->connect('megaware','megawareeoryguq!@#','megaware@192.168.3.96'); //�켱 ���ø����̼��� �����ؼ� ���

	} else 	if($mode== "devlcl") {
		$oci->connect('root','apmsetup','megaware'); //�켱 ���ø����̼��� �����ؼ� ���

	}


	return $oci;
}

$_SERVER_NAME_LIST = array('if_common_ent002','if_user_ent001','if_user_ent002','if_user_ent004','if_user_ent005');

class IF_SELF_ENT002_SND extends ORM{
	var $oci = null;
	function IF_SELF_ENT002_SND(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}
class IF_SELF_ENT002_RCV extends ORM{
	var $oci = null;
	function IF_SELF_ENT002_RCV(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}
class IF_COMMON_ENT002_SND extends ORM{
	var $oci = null;
	function IF_COMMON_ENT002_SND(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}
class IF_COMMON_ENT002_RCV extends ORM{
	var $oci = null;
	function IF_COMMON_ENT002_RCV(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}



class IF_USER_ENT001_SND extends ORM{
	var $oci = null;
	function IF_COMMON_ENT002_SND(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}
class IF_USER_ENT001_RCV extends ORM{
	var $oci = null;
	function IF_COMMON_ENT002_RCV(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}


class IF_USER_ENT002_SND extends ORM{
	var $oci = null;
	function IF_COMMON_ENT002_SND(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}
class IF_USER_ENT002_RCV extends ORM{
	var $oci = null;
	function IF_COMMON_ENT002_RCV(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}


class IF_USER_ENT004_SND extends ORM{
	var $oci = null;
	function IF_COMMON_ENT004_SND(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}
class IF_USER_ENT004_RCV extends ORM{
	var $oci = null;
	function IF_COMMON_ENT004_RCV(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}


class IF_USER_ENT005_SND extends ORM{
	var $oci = null;
	function IF_COMMON_ENT005_SND(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}
class IF_USER_ENT005_RCV extends ORM{
	var $oci = null;
	function IF_COMMON_ENT005_RCV(& $oci){
		$this->oci = $oci;		
		parent::ORM($oci);
	}
}


function get_rows($id, $mode){



	$oci = connection_database();
	
	switch($mode){
		case 'if_self_ent002' :
			$snd = new IF_SELF_ENT002_SND($oci);
			$rcv = new IF_SELF_ENT002_RCV($oci);
			break;
		case 'if_common_ent002' :
			$snd = new IF_COMMON_ENT002_SND($oci);
			$rcv = new IF_COMMON_ENT002_RCV($oci);
			break;
		case 'if_user_ent001':
			$snd = new IF_USER_ENT001_SND($oci);
			$rcv = new IF_USER_ENT001_RCV($oci);
			break;
		
		case 'if_user_ent002':
			$snd = new IF_USER_ENT002_SND($oci);
			$rcv = new IF_USER_ENT002_RCV($oci);
			break;
		
		case 'if_user_ent004':
			$snd = new IF_USER_ENT004_SND($oci);
			$rcv = new IF_USER_ENT004_RCV($oci);
			break;
		case 'if_user_ent005':
			$snd = new IF_USER_ENT005_SND($oci);
			$rcv = new IF_USER_ENT005_RCV($oci);
			break;
				

	}

	
	$snd->setLimit(100);
	$rcv->setLimit(100);

	$where = array('INTEG_ID' => $id);

	$where = array(array('SEQ','>', '0'));

	$rows = $snd->pull($where);
	//echo "----------------SND TABLE ---------------------\n";


	$m = array();

	foreach($rows as $row){
		$row['_TABLE'] = 'SND';
		$key = $row['IF_TIME'] . ' snd ' . $row['INTEG_ID'];
		$m[$key] = $row;
	//	echo $row['INTEG_ID'] . " ". $row['IF_TIME'] ." ". $row['IF_MESSG'] . "  \n";
	}
	//echo "----------------RCV TABLE ---------------------\n";
	$rows = $rcv->pull($where);

	foreach($rows as $row){
		$row['_TABLE'] = 'RCV';
		$key = $row['IF_TIME'] . ' rcv ' . $row['INTEG_ID'];
		$m[$key] = $row;

	//	echo $row['INTEG_ID'] . " ". $row['IF_TIME'] ." ". $row['IF_MESSG'] . "  \n";
	}
	//echo "----------------- Summary --------------------\n";
	ksort($m);
	return $m;
}


$results = get_rows("dfd", 'if_self_ent002');

echo "<xmp>";
foreach ($results as $result) {
	echo $result['INTEG_ID']. "\n";
}


?>
