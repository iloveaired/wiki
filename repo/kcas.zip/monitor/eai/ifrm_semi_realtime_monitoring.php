<?
die();

error_reporting(E_ALL&~E_NOTICE); //����������

require_once(dirname(dirname(__FILE__))."/../conf/inc.conf.php");
require_once($_SITE_ROOT_.'/php.auto_prepend_file.inc');
require_once($_SITE_ROOT_.'/lib/class.ORM.php');

$_ORM_NM = $_REQUEST['table_nm'];
$_REQUEST['atag'] = empty($_REQUEST['atag'])?'':$_REQUEST['atag'];
$field_arr = array();

include "inc/".$_ORM_NM.".inc";

$oci = connectOrmDB($_IS_DEV_);
$oci->db->error_check = 0;

switch($_ORM_NM){
	case 'IF_COMMON_ENT002_RCV': $orm = new IF_COMMON_ENT002_RCV($oci); $field_arr = array_keys(get_object_vars(new IF_COMMON_ENT002_RCV_COLS)); break;
	case 'IF_COMMON_ENT002_SND': $orm = new IF_COMMON_ENT002_SND($oci); $field_arr = array_keys(get_object_vars(new IF_COMMON_ENT002_SND_COLS)); break;
	case 'IF_SELF_ENT002_RCV': $orm = new IF_SELF_ENT002_RCV($oci); $field_arr = array_keys(get_object_vars(new IF_SELF_ENT002_RCV_COLS)); break;
	case 'IF_SELF_ENT002_SND': $orm = new IF_SELF_ENT002_SND($oci); $field_arr = array_keys(get_object_vars(new IF_SELF_ENT002_SND_COLS)); break;
	
	case 'IF_SERVICE_ENT001_RCV': $orm = new IF_SERVICE_ENT001_RCV($oci); $field_arr = array_keys(get_object_vars(new IF_SERVICE_ENT001_RCV_COLS)); break;
	case 'IF_SERVICE_ENT001_SND': $orm = new IF_SERVICE_ENT001_SND($oci); $field_arr = array_keys(get_object_vars(new IF_SERVICE_ENT001_SND_COLS)); break;
	
	case 'IF_USER_ENT001_RCV': $orm = new IF_USER_ENT001_RCV($oci); $field_arr = array_keys(get_object_vars(new IF_USER_ENT001_RCV_COLS)); break;
	case 'IF_USER_ENT001_SND': $orm = new IF_USER_ENT001_SND($oci); $field_arr = array_keys(get_object_vars(new IF_USER_ENT001_SND_COLS)); break;
	case 'IF_USER_ENT003_RCV': $orm = new IF_USER_ENT003_RCV($oci); $field_arr = array_keys(get_object_vars(new IF_USER_ENT003_RCV_COLS)); break;
	case 'IF_USER_ENT003_SND': $orm = new IF_USER_ENT003_SND($oci); $field_arr = array_keys(get_object_vars(new IF_USER_ENT003_SND_COLS)); break;
}

$orm->setLimit(100);

if($_REQUEST['q'] == 'all'){
	$where = array('1'=>'1');
	$sub = "";
} else {
	$where = array('IF_STATUS' => 'F');
	$sub = "���г���";
}

$rows = $orm->pull($where,implode(",",$field_arr)," ORDER BY SEQ DESC");


?>
<html>
<title></title>
<style>
td {border: 1px solid currentColor;font-size:12px;}
.td_title {font-weight:bold;}
body {}
</style>
<body>
<h2><?=$_ORM_NM?> ���̺� ��ȸ ��� <?=$sub?> ���� 100�� <?if($_REQUEST['atag'] != 'false'){?><a href="ifrm_semi_realtime_monitoring.php?q=<?=$_REQUEST['q']?>&table_nm=<?=$_ORM_NM?>&atag=false" target="_blank">[��â���� ũ�Ժ���]</a><?}?></h2>
<table board="1">
<tr>
<?
if(count($rows) > 0){ foreach($rows as $k=>$v){
?>
<?
	if($k==0){
		foreach($field_arr as $vv){
?>
	<td class="td_title"><?=$vv?></td>

<?
		}
	} 
?>
</tr>
<tr>
<?
	foreach($v as $kk=>$vv){
?>
	<td><div style="width:120px;height:40px;overflow:auto;"><?=$vv?></div></td>
<?
	} 
?>

<?
}} else {
?>
<td><?=$sub?> ������ ����� �����ϴ�.</td>
<?
}
?>
</tr>
</table>
</body>
</html>