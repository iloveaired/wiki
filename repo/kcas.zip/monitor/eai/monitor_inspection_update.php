<?
require_once(dirname(__FILE__)."/../../conf/inc.conf.php");
require_once($_SITE_ROOT_.'/php.auto_prepend_file.inc');
require_once(dirname(__FILE__)."/monitor_inspection_conf.php");


$_PATH             = "/nfsdata/uwayapply.com/kcas/monitor/inspection_update"; 
$_JOB_LIST         = array('apply','self','phone'); //�۾� �з�

$_DB_SERVER_INFO   = array('kcas'=>array('kcas','kcasuway12$','kcas_1a'), 'dkcas'=>array('dkcas','dkcasuway12$','kcas_1c') );
$sType             = (in_array($_REQUEST['sType'], array('kcas', 'dkcas'))) ? $_REQUEST['sType'] : 'kcas';

$job_type 			   = (in_array($_REQUEST['job_type'], array('file', 'update'))) ? $_REQUEST['job_type'] : '';
	
// $sType = 'dkcas';


function getTypeSQL( $type, $data, $jobKey, $ip )
{

	$tmp = explode("|", $data);

	if(count($tmp) < 3) return '';

	$sql = array();
		
	if( $type == 'apply' )
	{

		$sql['INS'] = "
		INSERT INTO KCAS_APPLY_LOG (INTEG_ID,RRNO,CRAL_TEL,BNK_CD,BNK_NM,ACHL,ACNO,PERS_ID,PERS_ID1,JOBKEY,IP) 
		SELECT INTEG_ID,RRNO,CRAL_TEL,BNK_CD,BNK_NM,ACHL,ACNO,PERS_ID,PERS_ID1,'{$jobKey}' AS JOBKEY, '{$ip}' AS IP FROM KCAS_APPLY WHERE INTEG_ID = '{$tmp[0]}' ";

		$sql['UPD'] = "UPDATE KCAS_APPLY SET RRNO='{$tmp[1]}', CRAL_TEL='{$tmp[2]}',BNK_CD='{$tmp[3]}',BNK_NM='{$tmp[4]}', ACHL='{$tmp[5]}', ACNO='{$tmp[6]}',PERS_ID='{$tmp[7]}',PERS_ID1='{$tmp[8]}' WHERE INTEG_ID = '{$tmp[0]}'";
	}
	else if( $type == 'self' )
	{
		$sql['INS'] = "
		INSERT INTO KCAS_SELFINTRODUCTION_LOG (INTEG_ID,QESITM1_ASWR,QESITM2_ASWR,QESITM3_ASWR,JOBKEY,IP)
		SELECT INTEG_ID,QESITM1_ASWR,QESITM2_ASWR,QESITM3_ASWR,'{$jobKey}' AS JOBKEY, '{$ip}' AS IP FROM KCAS_SELFINTRODUCTION WHERE INTEG_ID = '{$tmp[0]}' ";

		$sql['UPD'] = "UPDATE KCAS_SELFINTRODUCTION SET QESITM1_ASWR='{$tmp[1]}',QESITM2_ASWR='{$tmp[2]}',QESITM3_ASWR='{$tmp[3]}' WHERE INTEG_ID = '{$tmp[0]}'";
	}
	else if( $type == 'phone' )
	{
		$sql['INS'] = "
		INSERT INTO KCAS_USER_LOG (INTEG_ID,CRAL_TEL,CRAL_TEL_HASH,JOBKEY,IP)
		SELECT INTEG_ID,CRAL_TEL,CRAL_TEL_HASH,'{$jobKey}' AS JOBKEY, '{$ip}' AS IP FROM KCAS_USER WHERE INTEG_ID = '{$tmp[0]}' ";

		$sql['UPD'] = "UPDATE KCAS_USER SET CRAL_TEL='{$tmp[1]}',CRAL_TEL_HASH='{$tmp[2]}' WHERE INTEG_ID = '{$tmp[0]}'";
	}

	return $sql;
}

function getTimeToMicroseconds() {
    $t = microtime(true);
    $micro = sprintf("%06d", ($t - floor($t)) * 1000000);
    $d = new DateTime(date('Y-m-d H:i:s.' . $micro, $t));

    return substr($d->format("YmdHisu"), 0,16); 
}


if( $job_type == 'file' )
{
	$files  = fileUpLoad($_FILES, $_PATH);
	$jobKey = getTimeToMicroseconds();
	$ip     = $_SERVER['REMOTE_ADDR'];

	$sqls = array();
	foreach($files as $k => $file )
	{
		$fp = @fopen( $file[0], 'r' );
		while( feof( $fp ) == FALSE && $line = fgets( $fp ) )
		{
			$sqls[$k][] = getTypeSQL($k, trim($line), $jobKey, $ip);
		}
	}
}

?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv='Content-Type' content='text/html; charset=euc-kr' />
<style type='text/css'>

	body, a						{ font-family:tahoma; font-size:8pt; text-decoration: none; color: #000000; }
	a{color:#369;}
	a:hover{color:#963;}

	table, input, select		{ font-family:tahoma; font-size:8pt; border-width:2px }
	font.help					{ font-family:tahoma; font-size:8pt; color:#777777; }

	tr								{ height:18pt; }
	tr.title						{ background-color: #ADC5E9; font-weight:bold; }
	tr.log							{ background-color: #D9E1EF; cursor:hand; }
	.require_input{ color:red; }
	
	table{border-collapse:collapse; border:1px solid gray}
	table td{ border:1px solid gray;}


</style>
<script type="text/javascript">
//<![CDATA[
function chk_form(f){
	return true;
}


//]]>
</script>
</head>
<body onload="timeChk()">

<form name='search' method='post' onsubmit='return chk_form( this );'  enctype='multipart/form-data'>
	<input type='hidden' name='page' value='1'>
	<input type='hidden' name='job_type' value='file'>
<table border='1' cellpadding="1" cellspacing="0">
	<tr class='title'>
		<td colspan="2">�������� SQL�� ����</td>
	</tr>
	<tr>
		<td width='120' nowrap class="require_input">�������</td>
		<td colspan="5">
		<input type="file" name="apply[]" title="����÷��" />
		</td>
	</tr>
	<tr>
		<td width='120' nowrap class="require_input">�ڼҼ�</td>
		<td colspan="5">
		<input type="file" name="self[]" title="����÷��" />
		</td>
	</tr>

	<tr>
		<td width='120' nowrap class="require_input" title="�ʼ�">�޴���</td>
		<td colspan="5">
		<input type="file" name="phone[]" title="����÷��" />
		</td>
	</tr>			
	<tr>
		<td colspan='2' align='center'><input type='submit' value='do submit'></td>
	</tr>

	<tr>
		<td colspan='2' align='center'>
			<div align='center' style="width:800">
<?

?>
			</div>			
		</td>
	</tr>
</table>
</form>
 
<div>
<?
if( count($sqls) > 0 )
{
	$oci = new Altibase_OCI();
	$oci->connect($_DB_SERVER_INFO[$sType][0],$_DB_SERVER_INFO[$sType][1],$_DB_SERVER_INFO[$sType][2],array()); // VIP : 222.231.38.11

	$cnts = array('apply'=>0,'self'=>0,'phone'=>0); //�з��� ī��Ʈ

	foreach( $sqls as $k => $rows )
	{
		echo '<br>//'.$k.'<br><br>';

		foreach( $rows as $row )
		{
			$oci->parseExec($row['INS']); //����� INSERT
			$oci->parseExec($row['UPD']);	//UPDATE
			$oci->commit();
			$cnts[$k]++;
			echo $row['INS'].";<br>";
			echo $row['UPD'].";<br>";
		}	
	}
	$oci->disconnect();

	$msg = "apply: {$cnts['apply']}��, self: {$cnts['self']}��, phone: {$cnts['phone']}��";
	echo "<script>alert('{$msg}�������� �Ǿ����ϴ�.');</script>";
}
?>
</div>

</body>
</html>

