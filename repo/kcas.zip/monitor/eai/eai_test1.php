<?

error_reporting(E_ALL&~E_NOTICE); //����������
include $_SERVER['DOCUMENT_ROOT']."/eai/conf/config.inc";
//require_once(dirname(dirname(__FILE__))."/../conf/inc.conf.php");
require_once($_SITE_ROOT_.'/php.auto_prepend_file.inc');


require_once($_SITE_ROOT_.'/common/class.UwayPDO.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/common/class.Altibase_OCI.inc');
require_once($_SITE_ROOT_.'/lib/class.ORM.php');
require_once($_SITE_ROOT_.'/lib/class.KcasApply.php');




$dbmode = "real";
if(isset($_SERVER['HTTP_HOST'][0])){
	$rt = preg_match('/^[^\.]*(dev|re)[^\.]*\./',$_SERVER['HTTP_HOST']);  //���߼���������
 	if($rt) { $dbmode = "dev"; }
	
 	$rt = preg_match('/^[^\.]*(devlcl)[^\.]*\./',$_SERVER['HTTP_HOST']);  //���߼���������
	if($rt) { $dbmode = "devlcl"; }	
}

function & connection_database($mode = 'real', $in_out = "in"){
	$oci = new MySQL_OCI();
	if($mode == "real"){
		//$oci->connect('kcas','kcas12$','kcas');
		if($in_out === "in"){
			$oci->connect('megaware','megawareeoryguq!@#','megaware@192.168.3.21'); 
		} else {
			$oci->connect('megaware','megawareeoryguq!@#','megaware@222.231.38.21'); 
		}
		
	} else if($mode == "dev"){		//$oci->connect('dkcas','dkcas12$','kcas');

		if($in_out === "in"){
			$oci->connect('megaware','megawareeoryguq!@#','megaware@192.168.3.96'); 
		} else {
			$oci->connect('megaware','megawareeoryguq!@#','megaware@222.231.38.96'); 
		}

	} else 	if($mode== "devlcl") {
		$oci->connect('root','apmsetup','megaware'); //�켱 ���ø����̼��� �����ؼ� ���

	}

	return $oci;
}


function a_minus_b($row1, $row2){
	$common_row  = array_intersect_assoc($row1, $row2);

	return array_diff_assoc($row1, $common_row);
	// test code
	$kcas_row=array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow");
	$eai_row=array("a"=>"red","b"=>"green","c"=>"blu1");
	print_r(a_minus_b($kcas_row, $eai_row));
	print_r(a_minus_b($eai_row, $kcas_row));	
}
$kcas_row=array("a"=>"red","b"=>"green","c"=>"blue","d"=>"yellow");
$eai_row=array("a"=>"red","b"=>"green","c"=>"blu1");


echo "<xmp>";

function connection_altibase($mode = "real"){
	$oci = new Altibase_OCI();
	if($mode === "real") {
		$oci->connect('kcas','kcas12$','kcas_1c');
	} else if($mode === "dev"){
		$oci->connect('dkcas','dkcas12$','kcas_1c');
	}

	return $oci;
}
function fetch_altiase_apply($oci, $integ_id){
	
	$ka = new KcasApply($oci);
	$sh = array();
	$sh['INTEG_ID'] = $integ_id;
	$rows = $ka->pull($sh);
	return $rows[0];
}

$integ_id = "ssl9333";
$oci = connection_altibase($mode = "real");

$kcas_row = fetch_altiase_apply($oci, $integ_id);


require(_EAI_COMMON_DIR_.'/class.EAIApi.php');
$eai = new EAIApi();


$eai->actionURL = "http://kcas.uwayapply.com/eai/api/json_server.php";
$result = $eai->eaiApi($method = "if_common_ent001",$params = array(
			"INTEG_ID"=>$integ_id));

var_dump($result);
$eai_row = $result['data'];

print_r($eai_row);
die();

echo "KcasApply  minus EAI Agent(jinhak)\n";
print_r(a_minus_b($kcas_row, $eai_row));
echo "EAI Agent(jinhak) minus KcasApply\n";
print_r(a_minus_b($eai_row, $kcas_row));

echo "KcasApply\n";
print_r($kcas_row);
echo "EAI Agent(jinhak)\n";
print_r($eai_row);
?>

