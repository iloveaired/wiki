<?php
require_once(dirname(__FILE__)."/../../conf/inc.conf.php");
require_once($_SITE_ROOT_.'/php.auto_prepend_file.inc');
require_once(dirname(__FILE__)."/monitor_inspection_conf.php");

ini_set('odbc.defaultlrl', '16000000000');


if( !in_array($_SERVER['REMOTE_ADDR'], array('127.0.0.1','192.168.20.12', '210.92.76.12') ) )
{
	// die("���α׷� ������");	
}


$_JOB_LIST         = array('apply','self','phone'); //�۾� �з�
$_SEARCH_START_YMD = '20160620100000';			//���ñ⺰ ����
$_PATH             = "/nfsdata/uwayapply.com/kcas/monitor/inspection";
$sql               = array();
$isSearch          = false;
$_DB_SERVER_INFO   = array('kcas'=>array('kcas','kcasuway12$','kcas_1c'), 'dkcas'=>array('dkcas','dkcasuway12$','kcas_1c') );

$sType             = (in_array($_REQUEST['sType'], array('kcas', 'dkcas'))) ? $_REQUEST['sType'] : 'kcas';
$INTEG_IDs			   = $_REQUEST['INTEG_IDs'];
$SPLIT_LINE				 = array( 'apply'=>10000,'self'=>5000,'phone'=>5000 );


 
// ���丮 ���� ����
function fileAllDelete($path)
{
	$files = scandir($path);
	foreach($files as $file)
	{
		if ($file == "." || $file == ".." || is_dir($path.'/'.$file) ) continue;
		unlink($path.'/'.$file);
	}
}

if( !empty($_REQUEST['st_d']) && !empty($_REQUEST['ed_d']) )
{
	$isSearch = true;

	fileAllDelete($_PATH);	//�˻��� ���� ���� ��� ���� ó��

	$oci = new Altibase_OCI();
	$oci->connect($_DB_SERVER_INFO[$sType][0],$_DB_SERVER_INFO[$sType][1],$_DB_SERVER_INFO[$sType][2],array()); // VIP : 222.231.38.11

	// �˻��� ����� ����
	$searchS = str_replace(array('-',':', ' '), '', $_REQUEST['st_d']);
	$searchE = str_replace(array('-',':', ' '), '', $_REQUEST['ed_d']);



	if( strlen($INTEG_IDs) > 4 )
	{
		$searchId =  implode("','",explode('|',$INTEG_IDs));

		$where['apply'] = " AND KA.INTEG_ID IN ('{$searchId}')";
		$where['self']  = str_replace('KA.','KS.',$where['apply']);
		$where['phone'] = str_replace('KA.','KU.',$where['apply']);		
	}
	else
	{
		$where['apply'] = " 
									      AND ((KA.UWAY_INSERTDATE >= '{$searchS}' AND KA.UWAY_INSERTDATE <= '{$searchE}') OR 
										         (KA.UWAY_UPDATEDATE >= '{$searchS}' AND KA.UWAY_UPDATEDATE <= '{$searchE}')
									          )
									    ";
		$where['self']  = str_replace('KA.','KS.',$where['apply']);
		$where['phone'] = str_replace('KA.','KU.',$where['apply']);
	}

	$_fnm['apply'] = $sType.'_'.date('YmdHis')."_apply";
	$_fnm['self']  = $sType.'_'.date('YmdHis')."_apply_self";
	$_fnm['phone'] = $sType.'_'.date('YmdHis')."_user_phone";

	//�������
	$sql['apply'] = "
	SELECT INTEG_ID||'|'||RRNO||'|'||CRAL_TEL||'|'||BNK_CD||'|'||BNK_NM||'|'||ACHL||'|'||ACNO||'|'||PERS_ID||'|'||PERS_ID1 AS DATA
	FROM KCAS_APPLY KA
	WHERE RRNO IS NOT NULL 
	  AND KA.UWAY_INSERTDATE>= '{$_SEARCH_START_YMD}'
	  {$where['apply']}
	";

	$sql['self'] = "
	SELECT KA.INTEG_ID||'|'||KS.QESITM1_ASWR||'|'||KS.QESITM2_ASWR||'|'||KS.QESITM3_ASWR||'||'||KA.PERS_ID||'|'||KA.PERS_ID1 AS DATA
	FROM KCAS_APPLY KA, KCAS_SELFINTRODUCTION KS 
	WHERE KA.INTEG_ID=KS.INTEG_ID 
  	AND KA.RRNO IS NOT NULL AND WRT_HR IS NOT NULL 
  	AND KS.UWAY_INSERTDATE>= '{$_SEARCH_START_YMD}'
  	{$where['self']}
	"; 


	$sql['phone'] = "
	SELECT KU.INTEG_ID||'|'||KU.CRAL_TEL||'|'||KU.CRAL_TEL_HASH AS DATA
	FROM KCAS_USER KU
	WHERE 1=1 
  	AND KU.UWAY_INSERTDATE>= '{$_SEARCH_START_YMD}'
  	AND KU.CRAL_TEL IS NOT NULL
  	AND KU.CRAL_TEL_HASH IS NOT NULL
  	{$where['phone']}
	"; 

	foreach( $_JOB_LIST as $job )
	{
		$oci->parseExec($sql[$job]);

		$cnt[$job] = 0;
		$col       = array();
		// $fp        = fopen( $_PATH.'/'.$_fnm[$job], 'w');
		$i         = 0;
		$f_no      = 1;  //���ϼ���

		while($oci->fetchinto($col))
		{
			if( $i++ == 0 ) $fp = fopen( $_PATH.'/'.$_fnm[$job].'_'.substr('0'.$f_no,-2).'.txt', 'w');

			fwrite( $fp, $col['DATA'].PHP_EOL);

			if( $i == $SPLIT_LINE[$job] )
			{
					$i = 0;
					$f_no++;
					fclose($fp);
			} 

			$cnt[$job]++;
		}

		if( $fp ) fclose($fp);
		
	}
}

$tmps = scandir($_PATH);
$files= array();
foreach($tmps as $file)
{
	if ($file == "." || $file == ".." || is_dir($_PATH.$file) ) continue;
	// exec("split -l 5000 {$file} {$file}_" );  
	$files[substr($file,0,strlen($file)-7)][] = $file;
}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv='Content-Type' content='text/html; charset=euc-kr' />
<style type='text/css'>

	body, a						{ font-family:tahoma; font-size:8pt; text-decoration: none; color: #000000; }
	a{color:#369;}
	a:hover{color:#963;}

	table, input, select		{ font-family:tahoma; font-size:8pt; border-width:2px }
	font.help					{ font-family:tahoma; font-size:8pt; color:#777777; }

	tr								{ height:18pt; }
	tr.title						{ background-color: #ADC5E9; font-weight:bold; }
	tr.log							{ background-color: #D9E1EF; cursor:hand; }
	.require_input{ color:red; }
	
	table{border-collapse:collapse; border:1px solid gray}
	table td{ border:1px solid gray;}


</style>
<script type="text/javascript">
//<![CDATA[
function chk_form(f){
	return true;
}

function validate_date(input,value){
	var v = value.replace(/[^0-9]/g,'');
	if(v.length !=14){
		alert('���Ŀ� �´� ��¥�� �־��ּ���');
		input.focus();
		return false;
	}
	var re = /(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/;
	var arr = v.match(re);
	input.value = arr[1]+'-'+arr[2]+'-'+arr[3]+' '+arr[4]+':'+arr[5]+':'+arr[6];
	return true;
}


function timeChk()
{
	var st_d = '<?= $_REQUEST['st_d']?>';

	if( st_d == '' ) setD(document.search, 0);
}

//]]>
</script>
</head>
<body onload="timeChk()">

<form name='search' method='post' onsubmit='return chk_form( this );'>
	<input type='hidden' name='page' value='1'>
<table border='1' cellpadding="1" cellspacing="0">
	<tr class='title'>
		<td colspan="2">�˻�����</td>
	</tr>
	<tr>
		<td width='120' nowrap class="require_input" title="�ʼ�">����*</td>
		<td colspan="5">
				<label>
					� : <input type="radio" name="sType" value="kcas"  <?= ( $sType == 'kcas' ) ? 'checked':'' ?> />
					���� : <input type="radio" name="sType" value="dkcas" <?= ( $sType == 'dkcas') ? 'checked':'' ?> />
				</label>
		</td>
		</tr>
	<tr>
		<td width='120' nowrap class="require_input" title="�ʼ�">�Ⱓ*</td>
		<td colspan="5"><label>��¥ : 
			<input type='text' name='st_d' size='24' value='<?= $_REQUEST['st_d']?>'   onblur="validate_date(this,this.value)">
			~
			<input type='text' name='ed_d' size='24' value='<?= $_REQUEST['ed_d']?>'   onblur="validate_date(this,this.value)">			
			<font class='help'>(YYYY-MM-DD HH24:MI:SS)</font></label>
				<input type='button' value='����' onclick="setD(this.form,0);" />
				<input type='button' value='����' onclick="setD(this.form,1);" />
								<script type="text/javascript">
				function setD(form,gap_d,today_m){
					var st_d = form.st_d;
					var ed_d = form.ed_d;
					var dt = new Date(); //����
					d=dt.getDate();
					y=dt.getFullYear();
					m=dt.getMonth()+1;
					if(today_m!==undefined){
						d = 1;
						var dt3 = new Date(dt.getFullYear(),(m-1)+1,1,0,0,0,-1); //�������� ����	
					}else{
						var dt3 = new Date();  //�������� ����	
					}
					var dt2 = new Date(y,(m-1),(d-gap_d),0,0,0,0);
					
					var t = dt2.getFullYear()+'-'+((dt2.getMonth()+1).toString().replace(/^(.)$/,'0$1'))+'-'+(dt2.getDate().toString().replace(/^(.)$/,'0$1'));
					st_d.value = t+' 00:00:00';
					var t = dt3.getFullYear()+'-'+((dt3.getMonth()+1).toString().replace(/^(.)$/,'0$1'))+'-'+(dt3.getDate().toString().replace(/^(.)$/,'0$1'));
					ed_d.value = t+' 23:59:59';					
				}
				</script>
		</td>
		</tr>
	<tr>
		<td width='120' nowrap class="require_input" title="�ʼ�">���̵�*</td>
		<td colspan="5">
		<input type="text" name="INTEG_IDs" size="50" value="<?= $INTEG_IDs?>" > # ���̵� �˻� ������ "<font color=red>aaaa|bbbb</font>"
		</td>
	</tr>

	<tr>
		<td width='120' nowrap class="require_input" title="�ʼ�">UPDATE SQL�� ����</td>
		<td colspan="5">
		<a href="./monitor_inspection_update.php" target="_blank">UPDATE SQL�� ���� ������ �̵�</a>
		</td>
	</tr>

	<tr>
		<td colspan='2' align='center'><input type='submit' value='do submit'></td>
	</tr>

	<tr>
		<td colspan='2' align='center'>
			<div align='center' style="width:800">
<?
if($isSearch)
{
	echo "SQL :<br>";
	foreach( $_JOB_LIST as $job )
	{	
		echo nl2br($sql[$job]);
		echo "<b>�˻�ī��Ʈ : ".$cnt[$job].'</b><br>';
	}

	echo "<br><br><br>�˻����� :<br>";
	echo "�˻����� ������ : ".$_SEARCH_START_YMD.'<br>';
	echo "�˻����� ������ : ".$searchS.'<br>';
	echo "�˻����� ������ : ".$searchE.'<br>';
}
?>
			</div>			
		</td>
	</tr>
</table>
</form>


<table border='1' width='700'>
	<tr class='title'>
		<td align='center' width='300'>����</td>
		<td align='center'>���ϸ�</td>
	</tr>
<?
foreach( $files as $k => $rows )
{
?>	
	<tr class='log'>
		<td align='center'><?= $k?></td>
		<td >
		<?foreach( $rows as $v ){?>
		<a href="./monitor_inspection_down.php?id=<?= base64_encode($v)?>" target="_blank"><?= $v?></a><br>
		<?}?>
		</td>
	</tr>
<?
}
?>	
</table>


</body>
</html>

