<?
die();

if($_REQUEST['q'] == 'all'){
	$sub = "";
} else {
	$sub = "���г���";
}
?>
<html>
<head>
<title>�� �ǽð� ���̺� ��ȸ ������(����)</title>
</head>
<script type="text/javascript">
<!--
	function setIFrameSrc(table_nm){
		document.getElementById('ifrm_monitor').src = "ifrm_semi_realtime_monitoring.php?table_nm="+table_nm+"&q=<?=$_REQUEST['q']?>";
	}
//-->
</script>
<body>
<h1>�� �ǽð� ���̺� ��ȸ ������ <?=$sub?></h1>
<dl>
	<dt>
		�������<br />
		<input type="button" onclick="setIFrameSrc('IF_COMMON_ENT002_RCV');" value="IF_COMMON_ENT002_RCV">
		<input type="button" onclick="setIFrameSrc('IF_COMMON_ENT002_SND');" value="IF_COMMON_ENT002_SND">
	</dt>
	
	<dt>
		�ڱ�Ұ���<br />
		<input type="button" onclick="setIFrameSrc('IF_SELF_ENT002_RCV');" value="IF_SELF_ENT002_RCV">
		<input type="button" onclick="setIFrameSrc('IF_SELF_ENT002_SND');" value="IF_SELF_ENT002_SND">
	</dt>
	<dt>
		����<br />
		<input type="button" onclick="setIFrameSrc('IF_SERVICE_ENT001_RCV');" value="IF_SERVICE_ENT001_RCV">
		<input type="button" onclick="setIFrameSrc('IF_SERVICE_ENT001_SND');" value="IF_SERVICE_ENT001_SND">
	</dt>
		
	<dt>
		����ȸ�� ����,����,��й�ȣ�ʱ�ȭ,��й�ȣ����<br />
		<input type="button" onclick="setIFrameSrc('IF_USER_ENT001_RCV');" value="IF_USER_ENT001_RCV">
		<input type="button" onclick="setIFrameSrc('IF_USER_ENT001_SND');" value="IF_USER_ENT001_SND">
	</dt>
	<dt>
		ȸ��Ż��<br />
		<input type="button" onclick="setIFrameSrc('IF_USER_ENT003_RCV');" value="IF_USER_ENT003_RCV">
		<input type="button" onclick="setIFrameSrc('IF_USER_ENT003_SND');" value="IF_USER_ENT003_SND">
	</dt>
</dl>
<iframe id="ifrm_monitor" style="width:1500px;height:600px;" frameboard="0" src="about:blank"></iframe>
</body>
</html>