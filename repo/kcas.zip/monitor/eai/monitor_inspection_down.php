<?
require_once(dirname(__FILE__)."/../../conf/inc.conf.php");
require_once($_SITE_ROOT_.'/php.auto_prepend_file.inc');
require_once(dirname(__FILE__)."/monitor_inspection_conf.php");

$_PATH    = "/nfsdata/uwayapply.com/kcas/monitor/inspection"; 

$file     = base64_decode($_REQUEST['id']);

$filename =	$_PATH.'/'.$file;
$fp       =	@fopen($filename, "r");

if(is_resource($fp))
{
	header("Content-type:application/octet-stream");
	header("Content-Disposition:attachment; filename=".$file);
	header("Content-Transfer-Encoding:binary");
	header('Cache-Control: private');

	while (!feof($fp))
	{
		echo fread($fp, 1024);
	}

	fclose($fp);
}else{
	echo "���� �����ʴ� ����";	
}
?>