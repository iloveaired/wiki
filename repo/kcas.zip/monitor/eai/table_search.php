<?


error_reporting(E_ALL&~E_NOTICE); //����������

require_once(dirname(dirname(__FILE__))."/../conf/inc.conf.php");
require_once($_SITE_ROOT_.'/php.auto_prepend_file.inc');


require_once($_SITE_ROOT_.'/common/class.UwayPDO.inc');
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');
require_once($_SITE_ROOT_.'/lib/class.ORM.php');
//require_once($_SITE_ROOT_.'/monitor/eai/class.ORM.php');






$dbmode = "real";
if(isset($_SERVER['HTTP_HOST'][0])){
	$rt = preg_match('/^[^\.]*(dev|re)[^\.]*\./',$_SERVER['HTTP_HOST']);  //���߼���������
 	if($rt) { $dbmode = "dev"; }
	
 	$rt = preg_match('/^[^\.]*(devlcl)[^\.]*\./',$_SERVER['HTTP_HOST']);  //���߼���������
	if($rt) { $dbmode = "devlcl"; }	
}

$CFG_F = array('INTEG_ID' =>1);

$R = array(
//'_LOGFILE'=>'',
//'_LOGSEQ'=>'',
//'_LOGDATE'=>'',
//'_LEVEL'=>'3',
'TITLE'=>'',
'MSG'=>'',
'IDX1'=>'',
'IDX2'=>'',
'IDX3'=>'',
'IDX4'=>'',
'IDX5'=>'',
'st_d'=>date('Y-m-d H:i:s',time()-10*60),
'ed_d'=>date('Y-m-d H:i:s'),
'd_type'=>'I',  //I=INTERVAL , D=DATE PERIOD
'level'=>'3',
'level_op'=>'gte',
'opt_detail'=>'',
'opt_order'=>'desc',
'opt_php_except'=>'',
'interval'=>'10',
'page'=>'1',
'connection' => $dbmode,
'table_type' =>'snd',
);
$R = array_merge($R,$_REQUEST);

//---- �⺻�˻��ʵ�
$wheres = array();
foreach($CFG_F as $k=>$v){
	if($v==1 && isset($R[$k][0])){
		$t = mysql_escape_string(stripcslashes($R[$k]));
		$wheres[$k]= " {$k} = '$t' ";
	}
}

//---- �˻��Ⱓ
if($R['d_type']=='D'){
	$wheres['IF_TIME'] = " IF_TIME BETWEEN '{$R['st_d']}' AND '{$R['ed_d']}' ";
	$t = preg_replace('/[^0-9]/','',$R['st_d']);
	$t2 = mktime(intval($t[8].$t[9],10),intval($t[10].$t[11],10),intval($t[11].$t[12],10),intval($t[4].$t[5],10)
		,intval($t[6].$t[7],10),intval($t[0].$t[1].$t[2].$t[3],10));
	$t = preg_replace('/[^0-9]/','',$R['ed_d']);
	$t3 = mktime(intval($t[8].$t[9],10),intval($t[10].$t[11],10),intval($t[11].$t[12],10),intval($t[4].$t[5],10)
		,intval($t[6].$t[7],10),intval($t[0].$t[1].$t[2].$t[3],10));
	if(date('Ym',$t2)==date('Ym',$t3)){
		$table = 'log'.date('m',$t2);
	}else{
		$table = 'log'.date('m',$t2);
		//$table = 'mrg_log';		
	}
	
	$able = true;		
}else if($R['d_type']=='I'){
	$wheres['IF_TIME'] = " IF_TIME >= DATE_SUB(now(),INTERVAL {$R['interval']} MINUTE) ";
	$table = 'log'.date('m');
	$able = true;	
}else{
	$able = false;
}

//---
$order = '';
switch($R['opt_order']){
	case 'asc':$order  = " ORDER BY IF_TIME ASC";break;
	case 'desc':$order  = " ORDER BY IF_TIME DESC";break;
	case '': break;

}

$page = ((int)$R['page'])?(int)$R['page']:1;
$limit = 50;
$offset = ($page - 1)*$limit;

if(isset($R['table_type'])){
	$table_type = strtoupper($R['table_type']);
}else {
	$table_type = "SND";
}

if(isset($R['_TABLE_NAME'])){

	$table = strtoupper($R['_TABLE_NAME'])."_$table_type";
} else {
	$table = 'IF_COMMON_ENT002_SND';	
}
if(empty($wheres)){
	$sql = "
	SELECT * FROM {$table}
	{$order}
	LIMIT  {$offset} , {$limit}
	";

}else {
	$where = implode(' AND ' ,$wheres);
	$sql = "
	SELECT * FROM {$table}
	WHERE {$where}
	{$order}
	LIMIT  {$offset} , {$limit}
	";
}



function & connection_database($mode = 'real'){
	$oci = new MySQL_OCI();
	//$mode = "real";
	// if(isset($_SERVER['HTTP_HOST'][0])){
	// 	$rt = preg_match('/^[^\.]*(dev|re)[^\.]*\./',$_SERVER['HTTP_HOST']);  //���߼���������
	// 	if($rt) { $mode = "dev"; }
	
	// 	$rt = preg_match('/^[^\.]*(devlcl)[^\.]*\./',$_SERVER['HTTP_HOST']);  //���߼���������
	// 	if($rt) { $mode = "devlcl"; }	
	// }

	if($mode == "real"){
		//$oci->connect('kcas','kcas12$','kcas');
		$oci->connect('megaware','megawareeoryguq!@#','megaware@192.168.3.21'); //�켱 ���ø����̼��� �����ؼ� ���
		//kcas_1
	} else if($mode == "dev"){		//$oci->connect('dkcas','dkcas12$','kcas');

		$oci->connect('megaware','megawareeoryguq!@#','megaware@192.168.3.96'); //�켱 ���ø����̼��� �����ؼ� ���

	} else 	if($mode== "devlcl") {
		$oci->connect('root','apmsetup','megaware'); //�켱 ���ø����̼��� �����ؼ� ���

	}


	return $oci;
}

$_TABLE_NAME_LIST = array('if_self_ent002','if_common_ent002','if_user_ent001','if_user_ent002','if_user_ent004','if_user_ent005');

function cmp($a, $b){
	return -strcasecmp($a,$b);
}

function get_rows( $id, $mode){

	$oci = connection_database("devlcl");
	
	switch($mode){
		case 'if_self_ent002' :
			break;
		case 'if_common_ent002' :
			break;
		case 'if_user_ent001':
			break;		
		case 'if_user_ent002':
			break;	
		case 'if_user_ent004':
			break;
		case 'if_user_ent005':
			break;
	}





	//echo "----------------SND TABLE ---------------------\n";

	$m = array();

	foreach($rows as $row){
		$row['_TABLE'] = 'SND';
		$key = $row['IF_TIME'] . ' snd ' . $row['INTEG_ID'];
		$m[$key] = $row;
	//	echo $row['INTEG_ID'] . " ". $row['IF_TIME'] ." ". $row['IF_MESSG'] . "  \n";
	}
	//echo "----------------RCV TABLE ---------------------\n";
	$rows = $rcv->pull($where);

	foreach($rows as $row){
		$row['_TABLE'] = 'RCV';
		$key = $row['IF_TIME'] . ' rcv ' . $row['INTEG_ID'];
		$m[$key] = $row;

	//	echo $row['INTEG_ID'] . " ". $row['IF_TIME'] ." ". $row['IF_MESSG'] . "  \n";
	}
	//echo "----------------- Summary --------------------\n";
	//ksort($m);
	uksort($m, 'cmp');
	return $m;
}


?>


<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv='Content-Type' content='text/html; charset=euc-kr' />
<style type='text/css'>

	body, a						{ font-family:tahoma; font-size:8pt; text-decoration: none; color: #000000; }
	a{color:#369;}
	a:hover{color:#963;}

	table, input, select		{ font-family:tahoma; font-size:8pt; border-width:2px }
	font.help					{ font-family:tahoma; font-size:8pt; color:#777777; }

	tr								{ height:18pt; }
	tr.title						{ background-color: #ADC5E9; font-weight:bold; }
	tr.log							{ background-color: #D9E1EF; cursor:hand; }
	.require_input{ color:red; }
	
	table{border-collapse:collapse; border:1px solid gray}
	table td{ border:1px solid gray;}


</style>
<script type="text/javascript">
//<![CDATA[
function chk_form(f){
	return true;
}
function toggle_display( id )
{
	var obj = document.getElementById( id );
	obj.style.display = obj.style.display == 'none' ? '' : 'none';
}

function go_page( page )
{
	var f = document.forms['search'];

	f.page.value = page;

	f.submit();
}

function toggle_result( val )
{
	var trs = document.getElementsByTagName( 'tr' );

	for( i=0; i < trs.length; i++ )
	{
		if( trs[i].result )
		{
			trs[i].style.display = val == true ? '' : 'none';
		}
	}
}
function validate_date(input,value){
	var v = value.replace(/[^0-9]/g,'');
	if(v.length !=14){
		alert('���Ŀ� �´� ��¥�� �־��ּ���');
		input.focus();
		return false;
	}
	var re = /(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})/;
	var arr = v.match(re);
	input.value = arr[1]+'-'+arr[2]+'-'+arr[3]+' '+arr[4]+':'+arr[5]+':'+arr[6];
	return true;
	
}

//]]>
</script>
</head>
<body>

<form name='search' method='get' action='<?php echo $_SERVER['PHP_SELF']; ?>' onsubmit='return chk_form( this );'>
	<input type='hidden' name='page' value='<?=$R['page']; ?>'>
<table border='1' cellpadding="1" cellspacing="0">
	<tr class='title'>
		<td colspan="6">�˻�����</td>
		<td align="center">��ũ</td>
	</tr>
	<tr>
		<td> DB ���� </td>
		<td>
			<input type='radio' name='connection' value='real' <?=$R['connection'] == 'real' ? 'checked' : ''; ?> id='c_opt_order1'><label for='c_opt_order1'>21(eai1 �)L</label>
			<input type='radio' name='connection' value='dev' <?=$R['connection'] == 'dev' ? 'checked' : ''; ?> id='c_opt_order2'><label for='c_opt_order2'>96(����)</label>
			<input type='radio' name='connection' value='devlcl' <?=$R['connection'] === 'devlcl' ? 'checked' : ''; ?> id='c_opt_order3'><label for='c_opt_order3'>local pc</label>			
		</td>
		<td>Table(SND,RCV)</td>
		<td>
			<input type='radio' name='table_type' value='snd' <?=$R['table_type'] == 'snd' ? 'checked' : ''; ?> id='t_opt_order1'><label for='t_opt_order1'>SND</label>
			<input type='radio' name='table_type' value='rcv' <?=$R['table_type'] == 'rcv' ? 'checked' : ''; ?> id='t_opt_order2'><label for='t_opt_order2'>RCV</label>



		</td>
		<td></td><td></td>
		<td></td>
	</tr>
	<tr>
		<td nowrap class="require_input" title="�ʼ�">������(�����̸�)*</td>
		<td colspan="5"><input name='_TABLE_NAME' type='text' id="_TABLE_NAME" value='<?=$R['_TABLE_NAME']; ?>' size='40' />
			<?
	
		?>
			<select name="" onchange="this.form._TABLE_NAME.value=this.value;" >
				<option value="">�����Է�</option>
				<? 
			$t0 = $R['_TABLE_NAME'];
			foreach($_TABLE_NAME_LIST as $v){
			$t = htmlspecialchars($v);
			$t2 = ($v==$t0)?'selected="selected"':'';
			?>
				<option <?=$t2 ?> value="<?=$t?>"><?=$t?></option>
				<?
			}
			unset($_TABLE_NAME_LIST,$t,$v,$t0,$t2);
			?>
				</select>
			(tip : select �ڽ������� Ű����� �Է��Ͻø� �˻��̵˴ϴ�.)</td>
		<td rowspan="9" valign="top"><p>[<a href="error_summary.php" target="_blank">10�к� ������Ȳ</a>]<br />
			[<a href="index_old.htm">���� �α� ������</a>] </p></td>
	</tr>
	<tr>
		<td width='120' nowrap class="require_input" title="�ʼ�">�Ⱓ*</td>
		<td colspan="5"><label><input type="radio" name="d_type" value="D" <?=$R['d_type'] == 'D' ? 'checked' : ''; ?>  /> ��¥ : 
			<input type='text' name='st_d' size='24' value='<?=$R['st_d']; ?>'   onblur="validate_date(this,this.value)">
			~
			<input type='text' name='ed_d' size='24' value='<?=$R['ed_d']; ?>'   onblur="validate_date(this,this.value)">			
			<font class='help'>(YYYY-MM-DD HH24:MI:SS)</font></label>
				<input type='button' value='����' onclick="setD(this.form,0);this.form.d_type[0].click()" />
				<input type='button' value='����' onclick="setD(this.form,1);this.form.d_type[0].click()" />
				<? if($ableRange){ ?>
				<input type='button' value='������' onclick="setD(this.form,7);this.form.d_type[0].click()" />
				<input type='button' value='�̹���' onclick="setD(this.form,0,0);this.form.d_type[0].click()" />
				<? } ?>
				<script type="text/javascript">
				function setD(form,gap_d,today_m){
					var st_d = form.st_d;
					var ed_d = form.ed_d;
					var dt = new Date(); //����
					d=dt.getDate();
					y=dt.getFullYear();
					m=dt.getMonth()+1;
					if(today_m!==undefined){
						d = 1;
						var dt3 = new Date(dt.getFullYear(),(m-1)+1,1,0,0,0,-1); //�������� ����	
					}else{
						var dt3 = new Date();  //�������� ����	
					}
					var dt2 = new Date(y,(m-1),(d-gap_d),0,0,0,0);
					
					var t = dt2.getFullYear()+'-'+((dt2.getMonth()+1).toString().replace(/^(.)$/,'0$1'))+'-'+(dt2.getDate().toString().replace(/^(.)$/,'0$1'));
					st_d.value = t+' 00:00:00';
					var t = dt3.getFullYear()+'-'+((dt3.getMonth()+1).toString().replace(/^(.)$/,'0$1'))+'-'+(dt3.getDate().toString().replace(/^(.)$/,'0$1'));
					ed_d.value = t+' 23:59:59';					
				}

				</script>
			<br />
			<label><input type="radio" name="d_type" value="I" <?=$R['d_type'] == 'I' ? 'checked' : ''; ?>  />
			<input name="interval" type="text" value="<?=$R['interval']?>" size="5" maxlength="5" />���� ���� ���ݱ��� : 
				<input type='button' value='10����' onclick="this.form.interval.value='10';this.form.d_type[1].click()" />
				<input type='button' value='20����' onclick="this.form.interval.value='20';this.form.d_type[1].click()"  />
				<input type='button' value='30����' onclick="this.form.interval.value='30';this.form.d_type[1].click()"  />
				<input type='button' value='60����' onclick="this.form.interval.value='60';this.form.d_type[1].click()"  />
				</label>
		</td>
		</tr>
	
	<tr>
		<td>IDENT(�α� ���а�)</td>
		<td><input type='text'  <?=!$ableRange?'disabled="disabled" title="�������������������ּ���."':''?>  name='_IDENT' size='40' value='<?=$R['_IDENT']; ?>'></td>
		<td>���ϸ�</td>
		<td><input type='text' name='_SCRIPT_NAME' size='40' value='<?=$R['_SCRIPT_NAME']; ?>' /></td>
		<td>����</td>
		<td><input type='text' name='TITLE' size='40' value='<?=$R['TITLE']; ?>' /></td>
		</tr>
	<tr>
		<td>�޽���</td>
		<td><input type='text' name='MSG' size='40' value='<?=$R['MSG']; ?>' /></td>
		<td>REMOTE_ADDR</td>
		<td><input type='text' name='remote_addr' size='40' value='<?=$R['remote_addr']; ?>' /></td>
		<td></td>
		<td></td>
		</tr>
	<tr>
		<td>INTEG_ID</td>
		<td><input type='text' name='INTEG_ID' size='40' value='<?=$R['INTEG_ID']; ?>'></td>
		<td>IDX2</td>
		<td><input type='text' name='IDX2' size='40' value='<?=$R['IDX2']; ?>'></td>
		<td>IDX3</td>
		<td><input type='text' name='IDX3' size='40' value='<?=$R['IDX3']; ?>'  <?=!$ableRange?'disabled="disabled" title="�������������������ּ���."':''?>></td>
		</tr>
	
	<tr class='title'>
		<td colspan="6">����Ʈ ǥ��</td>
		</tr>
	<tr>
		<td>��� ���ĺ���</td>
		<td><input type='checkbox' name='opt_detail' value='1' <?=$R['opt_detail'] == '1' ? 'checked' : ''; ?> onclick='toggle_result( this.checked )'></td>
		<td>����</td>
		<td>
			<input type='radio' name='opt_order' value='asc' <?=$R['opt_order'] == 'asc' ? 'checked' : ''; ?> id='opt_order1'><label for='opt_order1'>ASC</label>
			<input type='radio' name='opt_order' value='desc' <?=$R['opt_order'] == 'desc' ? 'checked' : ''; ?> id='opt_order2'><label for='opt_order2'>DESC</label>
			<input type='radio' name='opt_order' value='' <?=$R['opt_order'] === '' ? 'checked' : ''; ?> id='opt_order3'><label for='opt_order3'>NONE</label>
			<font class='help'>�α׽ð�</font>		</td>
		<td>PHP Log ����</td>
		<td>
			<input type='checkbox' name='opt_php_except' value='1' <?=$R['opt_php_except'] == '1' ? 'checked' : ''; ?> id='opt_php_except'>
			<font class='help'><label for='opt_php_except'>�����ڵ鷯�� PHP �α״� ����</label></font>		</td>
		</tr>
	<tr>
		<td colspan='7' align='center'><input type='submit' value='do submit'></td>
	</tr>
</table>
</form>
<div>


<?=$sql?>
</div>

<?php

	//if( $able )
	if(!empty($R['INTEG_ID']))	{

		// $id = $R['INTEG_ID'];

		// if(isset($R['_TABLE_NAME'])){
		// 	$mode = $R['_TABLE_NAME'];
		// }else {
		// 	$mode = 'if_common_ent002';
		// }
		//$results = get_rows($id,$mode);


		$oci = connection_database($R['connection']);
		//$oci = connection_database("dev");
    
		$results = $oci->getRowsName($sql);
    

		
?>

<br/>
<br/>
<div align='center'></div>
<br/>

<table border='1' width='100%'>
	<tr class='title'>
		<td>����</td>
		<td>�ۼ��ð�</td>
		<td>INTEG_ID</td>		
		<td>���̺�</td>		
		<td>�޽���</td>		
		<td>����</td>
		<td>��Ÿ</td>
	</tr>

	<?php
		
		if( isset($results) )
		{
			// $seq = $paging->get_property( 'article_start' );
			// $log_level = config_item( 'log_level' );
			$detail_style = $R['opt_detail'] == '1' ? '' : 'none';

			//while( $result = $mng->get_result( $results ) )
			foreach($results as $result)
			{


	?>
	<tr onclick="toggle_display( 'detail_<?php echo $seq; ?>' );" class='log'>
		<td align='center'><?php echo number_format( $seq ); ?></td>
		<td nowrap><?php echo trim($result['IF_TIME']); ?></td>				
		<td><?php echo $result['INTEG_ID'] ?>&nbsp;</td>
		<td><?php echo $result['_TABLE'] ?></td>
		<td><?php echo $result['IF_MESSG'] ?>&nbsp;</td>		
		<td><?php echo $result['IF_STATUS']; ?></td>
		<td><?php echo htmlspecialchars( $result['MSG'] ); ?>&nbsp;</td>
	</tr>
	<tr id='detail_<?php echo $seq; ?>' style="display:<?php echo $detail_style; ?>;" result='true'>
		<td colspan="7" width="100%">

			<table border='1' width='100%' frame="void">
				<tr>
					<td width='100'>LOGSEQ</td>
					<td><?php echo $result['SEQ'] ?>&nbsp;</td>
				</tr>
				<tr>
					<td width='100'>IDENT</td>
					<td><?php echo $result['_IDENT'] ?>&nbsp;</td>
				</tr>
				<tr>
					<td width='100'>QUERY_STRING</td>
					<td><?php echo $result['_QUERY_STRING'] ?>&nbsp;</td>
				</tr>
				<tr>
					<td>INTEG_ID</td>
					<td><?php echo $result['INTEG_ID']; ?>&nbsp;</td>
				</tr>
				<tr>
					<td>DATA</td>
					<td><?php echo print_r($result,0) ?>&nbsp;</td>
				</tr>
				<tr>
					<td>IDX3</td>
					<td><?php echo $result['IDX3']; ?>&nbsp;</td>
				</tr>
				<tr>
					<td>IDX4</td>
					<td><?php echo $result['IDX4']; ?>&nbsp;</td>
				</tr>
				<tr>
					<td>IDX5</td>
					<td><?php echo $result['IDX5']; ?>&nbsp;</td>
				</tr>
				<tr>
					<td>SERVER_ADDR</td>
					<td><?php echo long2ip( $result['_SERVER_ADDR'] ); ?></td>
				</tr>
				<tr>
					<td>REMOTE_ADDR</td>
					<td><?php echo long2ip( $result['_REMOTE_ADDR'] ); ?></td>
				</tr>
				<?php

					if( empty( $result['ETC'] ) == FALSE )
					{
				?>
				<?php
						$etc_array = @unserialize( $result['ETC'] );

						if( is_array( $etc_array ) == TRUE )
						{
							foreach( $etc_array as $key => $value )
							{
				?>
				<tr>
					<td><?php echo "[".$key; ?></td>
					<td style='word-break:break-all;'><?php echo is_array( $value ) == TRUE ? print_r( $value ) : htmlspecialchars( $value ); ?>&nbsp;</td>
				</tr>
				<?php
							} // end of foreach
						}
						else
						{
				?>
				<tr>
					<td>ETC</td>
					<td><?php echo $result['ETC']; ?></td>
				</tr>
				<?php
						} // end of else

					} // end of if
				?>
				<tr>
					<td colspan='2' style='height:10pt'></td>
				</tr>
			</table>


		</td>
	</tr>
	<?php
				$seq++;


			} // end of while
		}
	?>
</table>

<br/>

<?php
	}
?>


</body>
</html>

