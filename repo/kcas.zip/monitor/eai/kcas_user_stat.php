<?php
require_once(dirname(__FILE__)."/../../conf/inc.conf.php");
require_once($_SITE_ROOT_.'/php.auto_prepend_file.inc');

$oci = new Altibase_OCI();
$oci->connect('kcas','kcas12$','kcas_1c',$dboption); // VIP : 222.231.38.11

$to_time = strtotime(date("Y-m-d H:i").":00");
$prev_time = $to_time - (60 * 60 * 2); //3�ð���
$prev_time_query = $prev_time;

$dual_table_data = array();
$hour_min_table_data = array();
$dual_table = "";

while($prev_time <= $to_time){
	$dual_table_data[] = "'".date("YmdHi",$prev_time)."'";
	if(date("i",$prev_time)%5 == 0) $hour_min_table_data[] = date("H:i",$prev_time);
	else $hour_min_table_data[] = "";
	$prev_time += 60;
}

$dual_table = "
	(SELECT * FROM (
		SELECT ".implode($dual_table_data, " AS UWAY_INSERTDATE FROM DUAL 
		UNION ALL SELECT ")." AS UWAY_INSERTDATE FROM DUAL 
	) T )
";


$sql="
SELECT
 A.UWAY_INSERTDATE
 ,NVL(B.CNT,0) AS CNT
FROM
		
	".$dual_table." A
			
	LEFT OUTER JOIN
			
	(
	SELECT 
	    substr(UWAY_INSERTDATE,1,12) AS UWAY_INSERTDATE,
	    count(*) AS CNT
	FROM 
		KCAS.KCAS_USER
	WHERE
		UWAY_INSERTDATE BETWEEN '".date("YmdHis",$prev_time_query)."' AND '".date("YmdHis",$to_time)."'
		AND INTEG_ID NOT LIKE 'uway%'
	GROUP BY
	    substr(UWAY_INSERTDATE,1,12)
	ORDER BY
	    substr(UWAY_INSERTDATE,1,12) ASC
	) B
	
	ON A.UWAY_INSERTDATE = B.UWAY_INSERTDATE
				
	ORDER BY A.UWAY_INSERTDATE
";


$data = $oci->getRowsName($sql);



$_datas = array();

foreach($data as $k=>$v){
	$_datas[] = array("join"=>($v['CNT']+0));
}



?>
<html>
<head>
<title>Uway ȸ�� �д� ���� ���</title>
<script src="lib/jquery-1.8.0.min.js"></script>
<script src="dist/jui.js"></script>
<script type="text/javascript">
<!--
$(function(){
	var chart = jui.include("chart.builder");
	
	chart("#chart-content", {
	    axis : {
	        x : {
	            type : "fullblock",
	            domain : <? echo json_encode($hour_min_table_data)?>,
	            line : true
	        },
	        y : {
	            type : "range",
	            domain : function(d) {
	                return Math.max(d.join);
	            },
	            step : 1
	        },
	        data : <? echo json_encode($_datas)?>
	    },
	    brush : [{
	        type : "line",
	        animate : true
	    }, {
	        type : "scatter",
	        hide : true
	    }],
	    widget : [
	    	{ type : "title", text : "������ ȸ������ �д� ��� ( <?=date("Y-m-d H:i",$prev_time_query)?> ~ <?=date("Y-m-d H:i",$to_time)?> )" },
	    	{ type : "legend" },
	        { type : "tooltip", brush : 1 }
	    ]
	});
});
//-->
</script>
</head>
<body>
<div id="chart-content" ></div>
</body>
</html>