<?

$t = dirname(__FILE__).'/../../../uway.com/bridge';
require_once($t.'/lib/class.MyUcash.inc');
require_once($t.'/common/class.Mcache.inc');
require_once(dirname(__FILE__).'/../common/class.Oracle_OCI.inc');
require_once(dirname(__FILE__).'/../conf/inc.conf.php');


/**
* USERID ���� UCASH �ݾ� ��������
Array
(
    [UCASH_COUNT] => 1
    [UCASH_AMOUNT] => 99009
    [UCASH_CASH_AMOUNT] => 2015
    [UCASH_POINT_AMOUNT] => 96994
)
*/

function getMyUcash($userid){
	$t = dirname(__FILE__).'/../../../uway.com/bridge';
	require($t.'/conf/myapply.inc'); //myapply ����
	//$config['use']['memcache'] = false; //��ĳ�� off

	$oci = & new Oracle_OCI;
	$mu = & new MyUcash();
	$mu->init($config,$oci);

	//$k2 = $mu->getMcKey($userid,'cnt'); //��ĳ��Ű
	$r2 = $mu->getCount($userid);
	//exit('x');
	//print_r($r2);
	var_dump($mu->usedDB);
	return $r2;

}