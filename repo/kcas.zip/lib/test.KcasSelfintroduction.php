<?
/**
* TEST
*/

require_once('inc.conf.php');
require_once(_SITE_ROOT_.'/lib/class.KcasSelfintroduction.php');


function resetdata(){
	global $oci;
	$sql = "delete from kcas_selfintroduction where CMF_UID LIKE 'xTEST%'";
	$oci->parse($sql);

	/*
	foreach($binds as $k=>$v){
		$oci->->bindByName(':'.$k,$binds[$k]);
	}
	*/
	$r = $oci->exec();
	$oci->commit();
}


$oci = connectDB(true);



$ka = new KcasSelfintroduction($oci);
$ka->debug = 1;

resetdata(); //insert�� �ش� �����Ͱ� ������ ������. ������

$row = array();
$row['CMF_UID'] = 'xTEST01';
$row['QESITM1_ASWR'] = 'UNIV'.time();
$r = $ka->push($row);
if(!assert($r==1)){
	echo $ka->error;
}

$sh = array();
$sh['CMF_UID'] = $row['CMF_UID'];
$rows = $ka->pull($sh);

if(!assert(isset($rows[0]) && $rows[0]['QESITM1_ASWR'] == $row['QESITM1_ASWR'])){
	echo 'ERROR : '.$ka->error;
}

resetdata();
echo 'END';
?>