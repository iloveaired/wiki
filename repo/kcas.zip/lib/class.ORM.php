<?
class ORM {

	var $oci = null;
	var $limit = 300;
	var $debug = false;
	var $pk = "SEQ";

	var $table = "kcas";
	var $error;

	function ORM(& $oci)
	{
		
		
		return $this->__construct($oci);
	}

	function __construct(& $oci)
	{
		//if(!empty($table)) $this->table  = $table;
		
		$this->table = self::table();
		//return $this->setOci($oci);
		$this->oci = $oci;
	}
	function setLimit($limit){
		$this->limit = $limit;
	}
	function dbExec($sql,$binds=array()){
		if(!isset($sql[0])){
			$this->error = __FUNCTION__.': sql ���� ���̰� ª���ϴ�.';
			return false;
		}
		if(!is_array($binds)){
			$this->error = __FUNCTION__.': binds ���� �迭�� �ƴմϴ�.';
			return false;
		}
		if($this->debug){
			echo "# SQL :{$sql}\n";
			echo "# BINDS\n";
			print_r($binds);
			echo '# END BINDS';
		}

		$this->oci->parse($sql);
		foreach($binds as $k=>$v){
			$this->oci->bindByName(':'.$k,$binds[$k]);
		}
		$r = $this->oci->exec();
		if(!$r && defined(__FUNCTION__)){
			$this->error = __FUNCTION__.': '.$oci->error;
		}
		//return $r;
		return true;
	}
	function dbCommit(){
		$this->oci->commit();
	}
	//==== get Rows
	function dbExecAndResult($sql,$binds=array()){
		if(!$this->dbExec($sql,$binds)){
			return false;
		}

		$rows = array();
		$col = array();
		while($this->oci->fetchinto($col))
		{
			$rows[] = $col;
		}
		return $rows;
	}

	function checkInsertRow($row, & $flds,& $vals, & $binds){

		foreach($row as $k=>$v){
			
			$binds[$k] = $row[$k]; //binds�� �� �ֱ�
			$flds[] = $k;
			$vals[] = ':'.$k;
		}
		if(count($flds)==0){
			$this->error = __FUNCTION__.': insert field�� ���� �����ϴ�.';
			return false;
		}
		if(count($vals)==0){
			$this->error = __FUNCTION__.': insert values�� ���� �����ϴ�.';
			return false;
		}

		return true;

	}
	function insert($row) {
		$flds = array();
		$vals = array();
		$binds = array();
		if(!$this->checkInsertRow($row, $flds, $vals, $binds)) {
			return false;
		}
		$FLD = implode(' , ',$flds);
		$VAL = implode(' , ',$vals);

		$sql = "
		INSERT INTO {$this->table} ({$FLD})
		values ({$VAL})
		";

		$this->dbExec($sql,$binds);
		$r = $this->oci->getNumRows();
		$this->dbCommit();
		return $r;
	}

	function _pull($sh,$exp='*',$orderby='', $where_etc = ''){
		//�������� SELECT 
		
		foreach($sh as $k=>$v){
			// if(!isset($this->fields[$k])){
			// 	$this->error = __FUNCTION__.': '.$k.' �� ����� �� ���� �ʵ�� �Դϴ�.';
			// 	return false;
			// }
			$binds[$k] = $sh[$k]; //binds�� �� �ֱ�
			$wheres[] = "{$k} = :{$k}";
		}
		$WHERE = implode(' AND ',$wheres);
		$sql = "SELECT {$exp} FROM {$this->table} WHERE {$WHERE} {$orderby}";
		$this->oci->setLimit($this->limit); //�ִ� �˻��� ����. �ʿ��ϴٸ� ����¡ ó������

		return $this->dbExecAndResult($sql,$binds);
	}

	function pull($sh,$exp='*',$orderby='', $where_etc = ''){
		//�������� SELECT 
		
		foreach($sh as $k=>$v){
			// if(!isset($this->fields[$k])){
			// 	$this->error = __FUNCTION__.': '.$k.' �� ����� �� ���� �ʵ�� �Դϴ�.';
			// 	return false;
			// }
			$op = " = ";
			if(is_array($v)){
				if(count($v) == 2){					
					list($op, $bind_value) = $v;					
				}		
			} else {
				$bind_value = $v;
			}

			
			$binds[$k] = $bind_value;//binds�� �� �ֱ�

			//$binds[$k] = $sh[$k]; //binds�� �� �ֱ�


			$wheres[] = "{$k} ". $op ." :{$k}";
		}
		$WHERE = implode(' AND ',$wheres);
		$sql = "SELECT {$exp} FROM {$this->table} WHERE {$WHERE} {$orderby}";

		
		$this->oci->setLimit($this->limit); //�ִ� �˻��� ����. �ʿ��ϴٸ� ����¡ ó������

		return $this->dbExecAndResult($sql,$binds);
	}


	function push($row){
		return $this->update($row);

	}

	function checkUpdateRow($row,& $wheres,& $sets,& $binds){
		//FIXME : number �ΰ�� error 
		//if(!isset($row[$this->pk][0])){
		if(empty($row[$this->pk])){
			//echo "----". $row[$this->pk];
			$this->error = __FUNCTION__.': pk value short';
			return false;
		}

		//-- PK where
		$wheres[] = "{$this->pk} = :{$this->pk}";
		$binds[$this->pk] = $row[$this->pk];

		foreach($row as $k=>$v){
			// if(!isset($this->fields[$k])){
			// 	//$this->error = __FUNCTION__.': '.$k.' �� ����� �� ���� �ʵ�� �Դϴ�.';
			// 	//return false;
			// 	continue; //���� �ȳ��� �׳� �����Ѵ�.
			// }
			// if($this->fields[$k] < 0){
			// 	continue; //�Է� ���� �ʵ�
			// }else if($this->fields[$k] >0 && !isset($v[$this->fields[$k]])){
			// 	$this->error = __FUNCTION__.': '.$k.' �� �ʼ����Դϴ�. ('.$this->fields[$k].' Byte)';
			// 	return false;
			// }
			$binds[$k] = $row[$k]; //binds�� �� �ֱ�
			if($this->pk != $k){ //PK���� ����
				$sets[] = "{$k} = :{$k}";
			}
		}
		if(count($wheres)==0){
			$this->error = __FUNCTION__.': no where condition';
			return false;
		}
		if(count($sets)==0){
			$this->error = __FUNCTION__.': no update set value';
			return false;
		}

		
		return true;
	}
	function update($row){
		if(!is_array($row)){
			$this->error = __FUNCTION__.': �Է°��� �迭�� �ƴմϴ�.';
			return false;
		}
		//insert,update ����(merge�� �ǰ���)

		$wheres = array();
		$sets = array();
		$flds = array();
		$vals = array();
		$binds = array();
		if(!$this->checkUpdateRow($row,$wheres,$sets,$binds)){
	
			return false;
		}
	
		$WHERE = implode(' AND ',$wheres);
		$SET = implode(' , ',$sets);
		$sql = "UPDATE {$this->table} 
		SET {$SET}
		WHERE {$WHERE}
		";
		

		$rt = $this->dbExec($sql,$binds);
		
		if($rt == false) return false;

		$r = $this->oci->getNumRows();
		$this->dbCommit();
		return $r;
	}


	function get_called_class(){
		$objects = array();
		$traces = debug_backtrace();
		foreach ($traces as $trace)
		{
			if (isset($trace['object'])){
				if (is_object($trace['object'])){
					$objects[] = $trace['object'];
				}
			}
		}
		if (count($objects)){
			return get_class($objects[0]);
		}
	}
	function table()
	{
		return $this->get_called_class();
	}


	function cols(){
		$class_name = self::table()."_COLS";
		return get_object_vars(new $class_name);
	
	}


	function filter_by_columns($row){
		$cols = $this->cols();
		$common_keys = array_intersect_key($cols,$row);	
		
		$filtered_column_row = array();
		foreach ($common_keys as $key=>$val) {
			$filtered_column_row[$key] = $row[$key];
		}
		return $filtered_column_row;
	}

	
}

?>