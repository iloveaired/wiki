<?
/**
* TEST
*/

require_once('inc.conf.php');
require_once(_SITE_ROOT_.'/lib/class.KcasApply.php');


function resetdata(){
	global $oci;
	$sql = "delete from kcas_apply where INTEG_ID LIKE 'xTEST%'";
	$oci->parse($sql);

	/*
	foreach($binds as $k=>$v){
		$oci->->bindByName(':'.$k,$binds[$k]);
	}
	*/
	$r = $oci->exec();
	$oci->commit();
}


$oci = connectKcasDB(true);



$ka = new KcasApply($oci);
$ka->debug = 1;

resetdata(); //insert�� �ش� �����Ͱ� ������ ������. ������

$row = array();
$row['INTEG_ID'] = 'xTEST01';
$row['CMF_UID'] = 'UNIV'.time();
$r = $ka->push($row);
if(!assert($r==1)){
	echo $ka->error;
}

$sh = array();
$sh['INTEG_ID'] = $row['INTEG_ID'];
$rows = $ka->pull($sh);

if(!assert(isset($rows[0]) && $rows[0]['CMF_UID'] == $row['CMF_UID'])){
	echo 'ERROR : '.$ka->error;
}

resetdata();
echo 'END';
?>