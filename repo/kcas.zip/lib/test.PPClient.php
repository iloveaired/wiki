<?
/**
* Pull/Push Ŭ���̾�Ʈ
* ���� : PHP 5.0 �̻� �ʼ�! cURL ���� �ʼ�!
*/
require(dirname(__FILE__).'/class.MProxy.php'); //<- �ʼ�
require(dirname(__FILE__).'/class.PPClient.php');

header("Content-Type: text/plain;charset=ms949");

//-- ����ȸ��


$actionURL = 'http://kcasids.uwayapply.com/user/user_pp.php'; //�
//$actionURL = 'http://kcasidsdev.uwayapply.com/user/user_pp.php'; //����
//$actionURL = 'http://kcasidsdevlcl.uwayapply.com/user/user_pp.php'; //����

$mproxy = new MProxy();
$ppclient = new PPClient($actionURL,$mproxy);

echo "# ����ȸ��\n";
echo "\n";
echo "# PUSH\n";
$row = array();
$row['INTEG_ID'] = 'testPPClient';
$row['NAME'] = '�̸�'.date('H:i:s');

$r = $ppclient->push($row);
if($r === false){
	var_dump($ppclient->error);
	var_dump($ppclient->lastResult);
}else{
	echo "��� :";
	echo "\n==============================\n";
	print_r($r);
	echo "\n==============================\n";
	echo "lastResponseMode : ".$ppclient->lastResponseMode,"\n";
	echo "error : ".$ppclient->error,"\n";
}


echo "\n";
echo "# PULL\n";
$sh = array();
$sh['INTEG_ID'] = 'testPPClient';

//--- ���ø����̼� �ð� ��ٸ�
//usleep(2000000); //2��
usleep(500000); //0.5��

$r = $ppclient->pull($sh);
if($r === false){
	echo "���� :";
	var_dump($ppclient->error);
	var_dump($ppclient->lastResult);
}else{
	echo "��� :";
	echo "\n==============================\n";
	print_r($r);
	echo "\n==============================\n";
	if(!assert($r[0]['NM']==$row['NM'])){
		echo "����ȸ��\n ���� ����\n";
		echo "{$r[0]['NM']}!={$row['NM']}\n";
	}
	echo "lastResponseMode : ".$ppclient->lastResponseMode,"\n";
	echo "error : ".$ppclient->error,"\n";
}


echo "\n\n\n\n\n";

//-- �������
echo "\n";
echo "# �������\n";

$actionURL = 'http://kcas.uwayapply.com/apply/pp_apply_test.php'; //�
//$actionURL = 'http://kcasdev.uwayapply.com/apply/apply_pp.php'; //����
//$actionURL = 'http://kcasdevlcl.uwayapply.com/apply/apply_pp.php'; //����

$mproxy = new MProxy();
$ppclient = new PPClient($actionURL,$mproxy);



echo "\n";
echo "# PUSH\n";
/*
$row = array();
$row['INTEG_ID'] = 'jeff2033';
//$row['NM'] = '�̸�'.date('H:i:s');

//$r = $ppclient->push($row);
if($r === false){
	var_dump($ppclient->error);
	var_dump($ppclient->lastResult);
}else{
	echo "��� :";
	echo "\n==============================\n";
	print_r($r);
	echo "\n==============================\n";
	echo "lastResponseMode : ".$ppclient->lastResponseMode,"\n";
	echo "error : ".$ppclient->error,"\n";
}
echo "\n";
echo "# PULL\n";
*/
$sh = array();
$sh['INTEG_ID'] = 'jeff2033';

//--- ���ø����̼� �ð� ��ٸ�
//usleep(2000000); //2��
usleep(500000); //0.5�� 

$r = $ppclient->pull($sh);
if($r === false){
	echo "���� :";
	var_dump($ppclient->error);
	var_dump($ppclient->lastResult);
}else{
	echo "��� :";
	echo "\n==============================\n";
	print_r($r);
	echo "\n==============================\n";
	if(!assert($r[0]['NM']==$row['NM'])){
		echo "�������\n ���� ����\n";
		echo "{$r[0]['NM']}!={$row['NM']}\n";
	}
	echo "lastResponseMode : ".$ppclient->lastResponseMode,"\n";
	echo "error : ".$ppclient->error,"\n";
}

/*
//-- �ڱ�Ұ���
echo "\n";
echo "# �ڱ�Ұ���\n";

//$actionURL = 'http://kcas.uwayapply.com/apply/selfintro_pp.php'; //�
//$actionURL = 'http://kcasdev.uwayapply.com/apply/selfintro_pp.php'; //����
$actionURL = 'http://kcasdevlcl.uwayapply.com/apply/selfintro_pp.php'; //����

$mproxy = new MProxy();
$ppclient = new PPClient($actionURL,$mproxy);



echo "\n";
echo "# PUSH\n";
$row = array();
$row['CMF_UID'] = 'testPPClient';
$row['QESITM1_ASWR'] = '�̸�'.date('H:i:s');

$r = $ppclient->push($row);
if($r === false){
	var_dump($ppclient->error);
	var_dump($ppclient->lastResult);
}else{
	echo "��� :";
	echo "\n==============================\n";
	print_r($r);
	echo "\n==============================\n";
	echo "lastResponseMode : ".$ppclient->lastResponseMode,"\n";
	echo "error : ".$ppclient->error,"\n";
}
echo "\n";
echo "# PULL\n";
$sh = array();
$sh['CMF_UID'] = 'testPPClient';

//--- ���ø����̼� �ð� ��ٸ�
//usleep(2000000); //2��
usleep(500000); //0.5�� 

$r = $ppclient->pull($sh);
if($r === false){
	echo "���� :";
	var_dump($ppclient->error);
	var_dump($ppclient->lastResult);
}else{
	echo "��� :";
	echo "\n==============================\n";
	print_r($r);
	echo "\n==============================\n";
	if(!assert($r[0]['QESITM1_ASWR']==$row['QESITM1_ASWR'])){
		echo "�������\n ���� ����\n";
		echo "{$r[0]['QESITM1_ASWR']}!={$row['QESITM1_ASWR']}\n";
	}
	echo "lastResponseMode : ".$ppclient->lastResponseMode,"\n";
	echo "error : ".$ppclient->error,"\n";
}
*/




?>