<?php
/**
*/
define('_EAI_ROOT_'  , dirname(__FILE__));

$_REQUEST['serverGb']     = (empty($_REQUEST['serverGb'])) ? 'server': $_REQUEST['serverGb'];
$_REQUEST['serverTarget'] = (empty($_REQUEST['serverTarget'])) ? 'L4': $_REQUEST['serverTarget'];

$arrowMethods = array('if_user_ent002', 'if_user_ent004', 'if_user_ent005', 'if_user_ent006', 'if_common_ent001','if_common_ent003', 'if_self_ent001');
$sslMethods   = array('if_user_ent002', 'if_common_ent003');
$sslTypes		  = array('client_jinhak', 'server_jinhak');


if( in_array($_REQUEST['gb'], $arrowMethods) )
{
	$method = $_REQUEST['gb'];

	if( in_array( $method, array('if_user_ent002','if_user_ent006') ) )
	{
		if( strlen($_REQUEST['INTEG_ID_HASH']) > 1 && strlen($_REQUEST['INTEG_ID_HASH']) < 20 )
		{
			$_REQUEST['INTEG_ID_HASH'] = hash("sha256",$_REQUEST["INTEG_ID_HASH"]);		
		}
	} 

	switch( $method )
	{
		case 'if_user_ent002'  : $_DATA = array( 'INTEG_ID_HASH' => $_REQUEST['INTEG_ID_HASH'] ); break;
		case 'if_user_ent004'  : $_DATA = array( 'NAME' => iconv('cp949','utf-8',$_REQUEST['NAME']), 'BRDY_YYMMDD' => $_REQUEST['BRDY_YYMMDD'], 'CRAL_TEL' => $_REQUEST['CRAL_TEL'] ); break;
		case 'if_user_ent005'  : $_DATA = array( 'NAME' => iconv('cp949','utf-8',$_REQUEST['NAME']), 'BRDY_YYMMDD' => $_REQUEST['BRDY_YYMMDD'], 'EMAIL' => $_REQUEST['EMAIL'] ); break;
		case 'if_user_ent006'  : $_DATA = array( 'INTEG_ID_HASH' => $_REQUEST['INTEG_ID_HASH'] ); break;
		case 'if_common_ent001': $_DATA = array( 'INTEG_ID' => $_REQUEST['INTEG_ID'] ); break;
		case 'if_common_ent003': $_DATA = array( 'INTEG_ID' => $_REQUEST['INTEG_ID'] ); break;		
		case 'if_self_ent001'  : $_DATA = array( 'INTEG_ID' => $_REQUEST['INTEG_ID'] ); break;
	}

	$_MODE = "api";
	$soapOptions = array('trace' => 1);

	if( $_REQUEST['serverGb'] == 'client' && $_REQUEST['serverTarget'] != 'L4' )
	{
		$locations = array(
				 'if_common_ent001'=> 'COMMON/IF_COMMON_ENT001'
				,'if_common_ent003'=> 'COMMON/IF_COMMON_ENT003'
				,'if_self_ent001'  => 'SELF/IF_SELF_ENT001'
				,'if_user_ent002'  => 'USER/IF_USER_ENT002'
				,'if_user_ent004'  => 'USER/IF_USER_ENT004'
				,'if_user_ent005'  => 'USER/IF_USER_ENT005'
				,'if_user_ent006'  => 'USER/IF_USER_ENT006'
			);

			$soapOptions['location'] = 'http://'.$_REQUEST['serverTarget'].':57710/route/KCUE/B340014JIN/Request/'.$locations[$method];
	}

	define('_EAI_WSDL_CLIENT_DIR_', _EAI_ROOT_.'/wsdl/'.$_REQUEST['serverGb']);
	define('_EAI_TARGET_AGENT_'		, (in_array( $_REQUEST['serverGb'], $sslTypes))? '2':'1' );
	
	if( _EAI_TARGET_AGENT_ == '2' && !in_array($method, $sslMethods) )
	{
		die('SSL �Ұ�['.$method.'] ��� �Դϴ�.<a href="'.$_SERVER['PHP_SELF'].'">reLoad</a>');
	}
	
	include _EAI_ROOT_.'/client/'.$method.'.php';


	//$result = $eai->eaiApi($method,$params);
}else{
	$method = 'if_common_ent001';
}
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
	<title>eaiTest</title>
</head>
<body>
<style type="text/css">
/* Tables */

.table-wrapper {
	width: 900px;
	background: #E0E0E0;
	table-layout: fixed;
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#E9E9E9', endColorstr='#D7D7D7');
	background: -webkit-gradient(linear, left top, left bottom, from(#E9E9E9), to(#D7D7D7)); 
	background: -moz-linear-gradient(top,  #E9E9E9,  #D7D7D7); 
	padding: 8px;
	-webkit-box-shadow: inset 0px 2px 2px #B2B3B5, 0px 1px 0 #fff;
	-moz-box-shadow: inset 0px 2px 2px #B2B3B5, 0px 1px 0 #fff;
	-o-box-shadow: inset 0px 2px 2px #B2B3B5, 0px 1px 0 #fff;
	-khtml-box-shadow: inset 0px 2px 2px #B2B3B5, 0px 1px 0 #fff;
	box-shadow: inset 0px 2px 2px #B2B3B5, 0px 1px 0 #fff;
	-webkit-border-radius: 10px; 
	/*-moz-border-radius: 10px; firefox doesn't allow rounding of tables yet*/
	-o-border-radius: 10px; 
	-khtml-border-radius: 10px;
	border-radius: 10px;
	margin-bottom: 20px;
}

.table-wrapper table {
	width: 900px;
}

.table-header {
	height: 35px;
	font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
	font-size: 14px;
	text-align: center;
	line-height: 34px;
	text-decoration: none;
	font-weight: bold;
	
}

.table-row td {
	font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
	font-size: 12px;
	text-align: left;
	text-decoration: none;
	font-weight: normal;
	color: #858585;
	padding: 10px;
	border-left: 1px solid #ccc;
	-khtml-box-shadow: 0px 1px 0px #B2B3B5;
	-webkit-box-shadow: 0px 1px 0px #B2B3B5;
	-moz-box-shadow: 0px 1px 0px #ddd;
	-o-box-shadow: 0px 1px 0px #B2B3B5;
	box-shadow: 0px 1px 0px #B2B3B5;
}

tr th {
	border-left: 1px solid #ccc;
}

tr th:first-child {
	-khtml-border-top-left-radius: 8px;
	-webkit-border-top-left-radius: 8px;
	-o-border-top-left-radius: 8px;
	/*-moz-border-radius-topleft: 8px; firefox doesn't allow rounding of tables yet*/
	border-top-left-radius: 8px;
	border: none;
}

tr td:first-child {
	border: none;
}

tr th:last-child {
	-khtml-border-top-right-radius: 8px;
	-webkit-border-top-right-radius: 8px;
	-o-border-top-right-radius: 8px;
	/*-moz-border-radius-topright: 8px; firefox doesn't allow rounding of tables yet*/
	border-top-right-radius: 8px;
}

tr {
	background: #fff;
}

tr:nth-child(odd) {
	background: #F3F3F3;
}

tr:nth-child(even) {
	background: #fff;
}

tr:last-child td:first-child {
	-khtml-border-bottom-left-radius: 8px;
	-webkit-border-bottom-left-radius: 8px;
	-o-border-bottom-left-radius: 8px;
	/*-moz-border-radius-bottomleft: 8px; firefox doesn't allow rounding of tables yet*/
	border-bottom-left-radius: 8px;
}

tr:last-child td:last-child {
	-khtml-border-bottom-right-radius: 8px;
	-webkit-border-bottom-right-radius: 8px;
	-o-border-bottom-right-radius: 8px;
	/*-moz-border-radius-bottomright: 8px; firefox doesn't allow rounding of tables yet*/
	border-bottom-right-radius: 8px;
}


a.tangerine, input.tangerine, ul.tangerine li a, th.tangerine {
	background: #F48E10;
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#E7A50F', endColorstr='#EC6D0B');
	background: -webkit-gradient(linear, left top, left bottom, from(#E7A50F), to(#EC6D0B)); 
	background: -moz-linear-gradient(top,  #E7A50F,  #EC6D0B); 
	color: #904108;
	text-shadow: 0px 1px 0px #E9C14D;
	-webkit-box-shadow: inset 0px 1px 0 #CB5D0B;
	-moz-box-shadow: inset 0px 1px 0 #CB5D0B;
	-o-box-shadow: inset 0px 1px 0 #CB5D0B;
	-khtml-box-shadow: inset 0px 1px 0 #CB5D0B;
	box-shadow: inset 0px 1px 0 #CB5D0B;
}


/* Ocean */

a.ocean, input.ocean, ul.ocean li a, th.ocean {
	background: #4AD4EE;
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#4AD4EE', endColorstr='#278FAC');
	background: -webkit-gradient(linear, left top, left bottom, from(#4AD4EE), to(#278FAC)); 
	background: -moz-linear-gradient(top,  #4AD4EE,  #278FAC); 
	color: #125267;
	text-shadow: 0px 1px 0px #60ACC1;
	-webkit-box-shadow: inset 0px 1px 0 #197A9D;
	-moz-box-shadow: inset 0px 1px 0 #197A9D;
	-o-box-shadow: inset 0px 1px 0 #197A9D;
	-khtml-box-shadow: inset 0px 1px 0 #197A9D;
	box-shadow: inset 0px 1px 0 #197A9D;
}

a.ocean:hover, input.ocean:hover, ul.ocean li a:hover {
	color: #125267;
	background: #3BB7D2;
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#5ADDF5', endColorstr='#218DB0');
	background: -webkit-gradient(linear, left top, left bottom, from(#5ADDF5), to(#218DB0)); 
	background: -moz-linear-gradient(top,  #5ADDF5, #218DB0); 
}

a.ocean:active, input.ocean:active, ul.ocean li a:active {
	color: #125267;
	background: #33A4BC;
	-webkit-box-shadow: inset 0px 2px 3px #333E4E, inset 0px 1px 0 #93E6F6;
	-moz-box-shadow: inset 0px 2px 3px #333E4E, inset 0px 1px 0 #93E6F6;
	-o-box-shadow: inset 0px 2px 3px #333E4E, inset 0px 1px 0 #93E6F6;
	-khtml-box-shadow: inset 0px 2px 3px #333E4E, inset 0px 1px 0 #93E6F6;
	box-shadow: inset 0px 2px 3px #333E4E, inset 0px 1px 0 #93E6F6;
}

ul.tabs li.ocean a { border-right: 1px solid #2184A1;}

input.login-ocean, input.login-ocean:hover, input.login-ocean:active  {
	background: url('images/btn-login-ocean.png') no-repeat center;
	text-indent: -5000px;
}

input.login-ocean:hover {
	-webkit-box-shadow: inset 0px 1px 1px #4A97BA, inset 0px -1px 1px #4A97BA, 0 0 8px #4A97BA;
	-moz-box-shadow: inset 0px 1px 1px #4A97BA, inset 0px -1px 1px #4A97BA, 0 0 8px #4A97BA;
	-o-box-shadow: inset 0px 1px 1px #4A97BA, inset 0px -1px 1px #4A97BA, 0 0 8px #4A97BA;
	-khtml-box-shadow: inset 0px 1px 1px #4A97BA, inset 0px -1px 1px #4A97BA, 0 0 8px #4A97BA;
	box-shadow: inset 0px 1px 1px #4A97BA, inset 0px -1px 1px #4A97BA, 0 0 8px #4A97BA;
}

input.login-ocean:active {
	-webkit-box-shadow: inset 0px 2px 3px #333E4E, inset 0px 1px 0 #93E6F6;
	-moz-box-shadow: inset 0px 2px 3px #333E4E, inset 0px 1px 0 #93E6F6;
	-o-box-shadow: inset 0px 2px 3px #333E4E, inset 0px 1px 0 #93E6F6;
	-khtml-box-shadow: inset 0px 2px 3px #333E4E, inset 0px 1px 0 #93E6F6;
	box-shadow: inset 0px 2px 3px #333E4E, inset 0px 1px 0 #93E6F6;
}

th.ocean {
	border-left: 1px solid #2184A1;
}

th.ocean:first-child {
	border: none;
}

input.search-button {
	display: block;
	width: 85px;
	height: 35px;
	font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
	font-size: 14px;
	text-align: center;
	line-height: 34px;
	text-decoration: none;
	-webkit-border-radius: 50px; 
	-moz-border-radius: 50px; 
	-o-border-radius: 50px; 
	-khtml-border-radius: 50px;
	border-radius: 50px;
	font-weight: bold;
	border: none;
	padding: 0;
	float: right;
	cursor: pointer;
}

/* Tabs */

ul.tabs {
	height: 35px;
	background: #E0E0E0;
	filter: progid:DXImageTransform.Microsoft.gradient(startColorstr='#E9E9E9', endColorstr='#D7D7D7');
	background: -webkit-gradient(linear, left top, left bottom, from(#E9E9E9), to(#D7D7D7)); 
	background: -moz-linear-gradient(top,  #E9E9E9,  #D7D7D7); 
	padding: 8px;
	-webkit-box-shadow: inset 0px 2px 2px #B2B3B5, 0px 1px 0 #fff;
	-moz-box-shadow: inset 0px 2px 2px #B2B3B5, 0px 1px 0 #fff;
	-o-box-shadow: inset 0px 2px 2px #B2B3B5, 0px 1px 0 #fff;
	-khtml-box-shadow: inset 0px 2px 2px #B2B3B5, 0px 1px 0 #fff;
	box-shadow: inset 0px 2px 2px #B2B3B5, 0px 1px 0 #fff;
	-webkit-border-radius: 10px; 
	-moz-border-radius: 10px; 
	-o-border-radius: 10px; 
	-khtml-border-radius: 10px;
	border-radius: 10px;
	margin-bottom: 20px;
	margin-left: 0;
}

ul.tabs li {
	list-style: none;
	margin-left: 0;
	display: inline-block;
	float: left;
}

ul.tabs li a {
	display: inline-block;
	float: left;
	width: 150px;
	height: 35px;
	font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
	font-size: 14px;
	text-align: center;
	line-height: 34px;
	text-decoration: none;
	-webkit-border-radius: 0px;
	-o-border-radius: 0px;
	-moz-border-radius: 0px;
	-khtml-border-radius: 0px;
	border-radius: 0px;
	font-weight: bold;
}

ul.tabs li:first-child a {
	-khtml-border-top-left-radius: 8px; -khtml-border-bottom-left-radius: 8px;
	-o-border-top-left-radius: 8px; -o-border-bottom-left-radius: 8px;
	-webkit-border-top-left-radius: 8px; -webkit-border-bottom-left-radius: 8px;
	-moz-border-radius-topleft: 8px; -moz-border-radius-bottomleft: 8px;
	border-top-left-radius: 8px; border-bottom-left-radius: 8px;
}

ul.tabs li:last-child a {
	-khtml-border-top-right-radius: 8px; -khtml-border-bottom-right-radius: 8px;
	-o-border-top-right-radius: 8px; -o-border-bottom-right-radius: 8px;
	-webkit-border-top-right-radius: 8px; -webkit-border-bottom-right-radius: 8px;
	-moz-border-radius-topright: 8px; -moz-border-radius-bottomright: 8px;
	border-top-right-radius: 8px; border-bottom-right-radius: 8px;
}
</style>
<script type="text/javascript">
<!--
	function jfnEai_if_user_ent002( INTEG_ID_HASH )
	{
		var f = document.getElementById('eaiTestForm');
		f.INTEG_ID_HASH.value = INTEG_ID_HASH;
		f.gb.value = 'if_user_ent002';
		f.submit();
	}

	function jfnEai_if_user_ent004( NAME, BRDY_YYMMDD, CRAL_TEL )
	{
		var f = document.getElementById('eaiTestForm');
		f.NAME.value = NAME;
		f.BRDY_YYMMDD.value = BRDY_YYMMDD;
		f.CRAL_TEL.value = CRAL_TEL;
		f.gb.value = 'if_user_ent004';
		f.submit();
	}

	function jfnEai_if_user_ent005( NAME, BRDY_YYMMDD, EMAIL )
	{
		var f = document.getElementById('eaiTestForm');
		f.NAME.value = NAME;
		f.BRDY_YYMMDD.value = BRDY_YYMMDD;
		f.EMAIL.value = EMAIL;
		f.gb.value = 'if_user_ent005';
		f.submit();
	}
	
	function jfnEai_if_user_ent006( INTEG_ID_HASH )
	{
		var f = document.getElementById('eaiTestForm');
		f.INTEG_ID_HASH.value = INTEG_ID_HASH;
		f.gb.value = 'if_user_ent006';
		f.submit();
	}

	function jfnEai_if_common_ent001( INTEG_ID )
	{
		var f = document.getElementById('eaiTestForm');
		f.INTEG_ID.value = INTEG_ID;
		f.gb.value = 'if_common_ent001';
		f.submit();
	}

	function jfnEai_if_common_ent003( INTEG_ID )
	{
		var f = document.getElementById('eaiTestForm');
		f.INTEG_ID.value = INTEG_ID;
		f.gb.value = 'if_common_ent003';
		f.submit();
	}

	function jfnEai_if_self_ent001( INTEG_ID )
	{
		var f = document.getElementById('eaiTestForm');
		f.INTEG_ID.value = INTEG_ID;
		f.gb.value = 'if_self_ent001';
		f.submit();
	}

	function jfnShowDiv(name)
	{
		var idList = ['if_common_ent001','if_common_ent003','if_self_ent001', 'if_user_ent002', 'if_user_ent004', 'if_user_ent005', 'if_user_ent006'];

		for( var i = 0; i < idList.length; i++ )
		{
			document.getElementById('div_'+idList[i]).style.display="none";
		}

		document.getElementById('div_'+name).style.display="";
	}
//-->
</script>

<form method="post" id="eaiTestForm" action="<?=$_SERVER['PHP_SELF']?>">
	<input type="hidden" name="gb" value="">
	<input type="hidden" name="serverGb" value="<?= $_REQUEST['serverGb']?>">
	<input type="hidden" name="serverTarget" value="<?= $_REQUEST['serverTarget']?>">
	<input type="hidden" name="INTEG_ID" value="">
	<input type="hidden" name="INTEG_ID_HASH" value="">
	<input type="hidden" name="NAME" value="">
	<input type="hidden" name="BRDY_YYMMDD" value="">
	<input type="hidden" name="CRAL_TEL" value="">
	<input type="hidden" name="EMAIL" value="">
</form>
<article>
	<ul class="tabs ocean" width="700px">
		<li class="ocean"><a href="javascript:jfnShowDiv('if_common_ent001')">�������</a></li>
		<li class="ocean"><a href="javascript:jfnShowDiv('if_common_ent003')">���������������</a></li>		
		<li class="ocean"><a href="javascript:jfnShowDiv('if_self_ent001')">�ڱ�Ұ���</a></li>
		<li class="ocean"><a href="javascript:jfnShowDiv('if_user_ent002')">����ȸ��ID�ߺ�üũ</a></li>
		<li class="ocean"><a href="javascript:jfnShowDiv('if_user_ent004')">�޴���ȭ�ߺ�</a></li>
		<li class="ocean"><a href="javascript:jfnShowDiv('if_user_ent005')">�����ߺ�</a></li>
		<li class="ocean"><a href="javascript:jfnShowDiv('if_user_ent006')">ĳ��Ȯ��</a></li>
	</ul>
</article>

<div class="table-wrapper" id="serverList">
	<table>
		<form >
		<tr class="table-row">
			<td>���ۼ��� ���� : 
				<select name="serverGb" onchange="document.getElementById('eaiTestForm').serverGb.value = this.value;">
					<option value="server" <?=($_REQUEST['serverGb']=="server")?"selected":""?>>������ SOAP �</option>
					<option value="server_dev" <?=($_REQUEST['serverGb']=="server_dev")?"selected":""?>>������ SOAP ����</option>
					<option value="client" <?=($_REQUEST['serverGb']=="client")?"selected":""?>>UWAY EAI AGENT SOAP => ���л�</option>
					<option value="client_dev" <?=($_REQUEST['serverGb']=="client_dev")?"selected":""?>>UWAY EAI AGENT SOAP => ���л簳��</option>
					<option value="client_jinhak" <?=($_REQUEST['serverGb']=="client_jinhak")?"selected":""?>>SSL SOAP ���л�</option>
					<!-- <option value="server_jinhak" <?=($_REQUEST['serverGb']=="server_jinhak")?"selected":""?>>SSL SOAP ������</option> -->					
				</select>

				UWAY EAI AGENT SOAP �̿�� ����
				<select name="serverTarget" onchange="document.getElementById('eaiTestForm').serverTarget.value = this.value;">
					<option value="L4" <?=($_REQUEST['serverTarget']=="L4")?"selected":""?>>L4 ����</option>
					<option value="192.168.3.23" <?=($_REQUEST['serverTarget']=="192.168.3.23")?"selected":""?>>KEAI03 ����</option>
					<option value="192.168.3.24" <?=($_REQUEST['serverTarget']=="192.168.3.24")?"selected":""?>>KEAI04 ���ڹ��� ����</option>
				</select>				
			</td>
		</tr>
		</form>
	</table>
</div> 

<div class="table-wrapper" id="div_if_common_ent001">
	<table>
		<form >
		<tr>
			<th class="table-header Ocean" colspan="3">������� ��������</th>
		</tr>
		<tr class="table-row">
			<td>INTEG_ID</td>
			<td width="400px"><input type="text" size="50" name="INTEG_ID" value="<?= $_REQUEST['INTEG_ID']?>"></td>
			<td rowspan="3"><input type="button" onClick="jfnEai_if_common_ent001(this.form.INTEG_ID.value)" class="search-button Ocean" value="search" /></td>
		</tr>
		</form>
	</table>
</div>
<div class="table-wrapper" id="div_if_common_ent003">
	<table>
		<form >
		<tr>
			<th class="table-header Ocean" colspan="3">��������������� ��������</th>
		</tr>
		<tr class="table-row">
			<td>INTEG_ID</td>
			<td width="400px"><input type="text" size="50" name="INTEG_ID" value="<?= $_REQUEST['INTEG_ID']?>"></td>
			<td rowspan="3"><input type="button" onClick="jfnEai_if_common_ent003(this.form.INTEG_ID.value)" class="search-button Ocean" value="search" /></td>
		</tr>
		</form>
	</table>
</div>

<div class="table-wrapper" id="div_if_self_ent001">
	<table>
		<form >
		<tr>
			<th class="table-header Ocean" colspan="3">�ڱ�Ұ��� ��������</th>
		</tr>
		<tr class="table-row">
			<td>INTEG_ID</td>
			<td width="400px"><input type="text" size="50" name="INTEG_ID" value="<?= $_REQUEST['INTEG_ID']?>"></td>
			<td rowspan="3"><input type="button" onClick="jfnEai_if_self_ent001( this.form.INTEG_ID.value)" class="search-button Ocean" value="search" /></td>
		</tr>
		</form>
	</table>
</div>


<div class="table-wrapper" id="div_if_user_ent002">
	<table>
		<form >
		<tr>
			<th class="table-header Ocean" colspan="3">����ȸ��ID�ߺ�üũ �׽�Ʈ</th>
		</tr>
		<tr class="table-row">
			<td>INTEG_ID_HASH</td>
			<td width="400px">
				<input type="text" size="60" name="INTEG_ID_HASH" value="<?= $_REQUEST['INTEG_ID_HASH']?>"><br>
				1~20�ڴ� INTEG_ID�� �ν��Ͽ� sha256���� ����˴ϴ�.
			</td>
			<td rowspan="3"><input type="button" onClick="jfnEai_if_user_ent002( this.form.INTEG_ID_HASH.value)" class="search-button Ocean" value="search" /></td>
		</tr>
		</form>
	</table>
</div>

<div class="table-wrapper" id="div_if_user_ent004">
	<table>
		<form >
		<tr>
			<th class="table-header Ocean" colspan="3">�޴���ȭ��ȣ�� �ִ� ����� �ߺ�üũ �׽�Ʈ</th>
		</tr>
		<tr class="table-row">
			<td>NAME</td>
			<td width="400px"><input type="text" size="50" name="NAME" value="<?= $_REQUEST['NAME']?>"></td>
			<td rowspan="3"><input type="button" onClick="jfnEai_if_user_ent004( this.form.NAME.value,this.form.BRDY_YYMMDD.value,this.form.CRAL_TEL.value )" class="search-button Ocean" value="search" /></td>
		</tr>
		<tr class="table-row">
			<td>BRDY_YYMMDD</td>
			<td><input type="text" size="50" name="BRDY_YYMMDD" value="<?= $_REQUEST['BRDY_YYMMDD']?>"></td>
		</tr>
		<tr class="table-row">
			<td>CRAL_TEL</td>
			<td><input type="text" size="50" name="CRAL_TEL" value="<?= $_REQUEST['CRAL_TEL']?>"></td>
		</tr>
		</form>
	</table>
</div>


<div class="table-wrapper" id="div_if_user_ent005">
	<table>
		<form >
		<tr>
			<th class="table-header Ocean" colspan="3">�޴���ȭ��ȣ�� ���� ����� �ߺ�üũ</th>
		</tr>
		<tr class="table-row">
			<td>NAME</td>
			<td width="400px"><input type="text" size="50" name="NAME" value="<?= $_REQUEST['NAME']?>"></td>
			<td rowspan="3"><input type="button" onClick="jfnEai_if_user_ent005( this.form.NAME.value,this.form.BRDY_YYMMDD.value,this.form.EMAIL.value )" class="search-button Ocean" value="search" /></td>
		</tr>
		<tr class="table-row">
			<td>BRDY_YYMMDD</td>
			<td><input type="text" size="50" name="BRDY_YYMMDD" value="<?= $_REQUEST['BRDY_YYMMDD']?>"></td>
		</tr>
		<tr class="table-row">
			<td>EMAIL</td>
			<td><input type="text" size="50" name="EMAIL" value="<?= $_REQUEST['EMAIL']?>"></td>
		</tr>
		</form>
	</table>
</div>

<div class="table-wrapper" id="div_if_user_ent006">
	<table>
		<form >
		<tr>
			<th class="table-header Ocean" colspan="3">ĳ�� �ܾ� Ȯ��</th>
		</tr>
		<tr class="table-row">
			<td>INTEG_ID_HASH</td>
			<td width="400px">
				<input type="text" size="60" name="INTEG_ID_HASH" value="<?= $_REQUEST['INTEG_ID_HASH']?>"><br>
				1~20�ڴ� INTEG_ID�� �ν��Ͽ� sha256���� ����˴ϴ�.
			</td>
			<td rowspan="3"><input type="button" onClick="jfnEai_if_user_ent006( this.form.INTEG_ID_HASH.value )" class="search-button Ocean" value="search" /></td>
		</tr>
		</form>
	</table>
</div>
<script type="text/javascript">
<!--
	jfnShowDiv('<?= $method?>');
//-->
</script>
<?
if( count($_RETURN) == 0 ) die();
?>
<div class="table-wrapper">
	<table width="900px" >
		<tr>
			<th class="table-header Ocean"  colspan="2" ><p align="left">&nbsp;�Է°�</p></th> 
		</tr>
	<tr class="table-row">
		<td width="80px">WEB SERVER IP</td>
		<td width="800px" ><?= $_SERVER['SERVER_ADDR']?></td>
	</tr>		
<?
foreach( $_REQUEST as $k => $v )
{
?>
	<tr class="table-row">
		<td width="80px"><?= $k?></td>
		<td width="800px" ><?= $v?></td>
	</tr>
<?
}
?>
</table>
</div>

<div class="table-wrapper">
	<table width="1100px" >
		<tr>
			<th class="table-header Ocean" colspan="2"><p align="left">&nbsp;<?= $method?> ���ϰ�</p></th>
		</tr>
<?
foreach( $_RETURN->SEARCH_RSLT as $k => $v )
{
?>
	<tr class="table-row">
		<td width="80px"><?= $k?></td>
		<td width="900px" ><?= iconv('utf8','euckr',$v)?></td>
	</tr>
<?
}
?>
</table>
</div>


<div class="table-wrapper">
	<table width="1100px" >
		<tr>
			<th class="table-header Ocean" colspan="2"><p align="left">SOAP TRACE [<?= $_SERVER['SERVER_ADDR']?>]</p></th>
		</tr>
	  <tr class="table-row">
		  <td width="80px">Request Header</td>
		  <td width="900px" ><?= nl2br($soapClient->__getLastRequestHeaders())?></td>
	  </tr>
 	  <tr class="table-row">
		  <td width="80px">Debug</td>
		  <td width="900px" ><?= nl2br($soapClient->__getLastResponse())?></td>
	  </tr>
</table>
</div>
</body>
</html>