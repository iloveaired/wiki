<?php
//include_once $_SERVER['DOCUMENT_ROOT'].'/eai/conf/config.inc';
include_once '/data/project/uwayapply.com/kcas/eai/conf/config.inc';


function getMilliSeconds2($prev_milliseconds,$next_milliseconds){
  return round(($next_milliseconds - $prev_milliseconds)*1000)/1000; 
}


class USER_ENT_002 {
    public $SEARCH_COND;

    function USER_ENT_002($SEARCH_COND) 
    {
        $this->SEARCH_COND = $SEARCH_COND;
    }
}



class SEARCH_COND {
    public $INTEG_ID_HASH;

    function SEARCH_COND($INTEG_ID_HASH) 
    {
        $this->INTEG_ID_HASH = $INTEG_ID_HASH;
    }
}


try{

	$options = array(
			'uri'=>'http://schemas.xmlsoap.org/soap/envelope/',
			'style'=>SOAP_RPC,
			'use'=>SOAP_ENCODED,
			'soap_version'=>SOAP_1_1,
			'cache_wsdl'=>WSDL_CACHE_NONE,
			'connection_timeout'=>15,
			'trace'=>true,
			'encoding'=>'UTF-8',
			'exceptions'=>true,
		);


	$input = new USER_ENT_002( new SEARCH_COND('96508a508d9dba6fa1e1db19c5eacb1767f2bf5c7baf4b725016669ecc443da0') );
	$soap  = new SoapClient(_EAI_ROOT_.'/wsdl/client_jinhak'."/IF_USER_ENT002.wsdl", $options);
	$rst = $soap->USER_ENT_002($input);

echo "<pre>";
print_r('SERVER IP : ' . $_SERVER['SERVER_ADDR']);
echo "</pre>";


echo "<pre>";
print_r('RETURN :');
print_r($rst);
echo "</pre>";


soapDebug($soap);

}catch(SoapFault $e){
	echo "SoapFault";	
	echo "<pre>";
	print_r($e);
	echo "</pre>";
	//$log = date("Y/m/d H:i:s"). " ". print_r($e);
}catch(Exception $e){

echo "Exception";	
echo "<pre>";
print_r($e);
echo "</pre>";
}




?>