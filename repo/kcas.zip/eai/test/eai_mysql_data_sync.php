<?php

include_once '/data/project/uwayapply.com/kcas/eai/conf/config.inc';
require_once($_SITE_ROOT_.'/common/class.MySQL_OCI.inc');


// DIE('�ƹ����� ���� ū�ϳ��� ^^;;');

$dbhosts = array('SELECT'=> '192.168.3.24', 'INSERT'=>'192.168.3.23' );
$gbs     = array('SND','RCV');
//$gbs     = array('SND');
$tables  = array('IF_SELF_ENT002','IF_USER_ENT001','IF_COMMON_ENT002','IF_USER_ENT003','IF_SERVICE_ENT001');
//$tables  = array('IF_USER_ENT001');


$s_oci = new MySQL_OCI();
$i_oci = new MySQL_OCI();

$s_oci->connect('megaware','megawareeoryguq!@#','megaware@'.$dbhosts['SELECT']);
$i_oci->connect('megaware','megawareeoryguq!@#','megaware@'.$dbhosts['INSERT']);


$whereSQL = " WHERE 1=1 AND WORK_DATE = '".date('Ymd')."' ";
$orderbySQL = " ORDER BY SEQ ";
$insertRowCnts = array();
foreach ($gbs as $gb) {
	foreach ($tables as $table){

		$talbeName = $table.'_'.$gb;
		$selectSQL = 'SELECT * FROM '.$talbeName.$whereSQL.$orderbySQL;
		$s_oci->parseExec($selectSQL);

		$insertRowCnts[$talbeName] = 0;
		

		$row = array();
		while($s_oci->fetchinto($row))
		{
			$fields = array();
			$binds = array();
			foreach ($row as $k => $v ) 
			{
				$fields[] = $k;
				if( $gb == 'SND' && $k == 'SEQ' )
				{
					$binds[] = 'null';
				}else{
					$binds[] = $v;
				}
			}
			$field = implode(",", $fields);
			$bind  = str_replace("'null'", 'null', implode("','", $binds));

			$insertSQL = "INSERT INTO ".$talbeName. "({$field})VALUES('{$bind}')";
			echo $insertSQL.';'.PHP_EOL;
			//
			//
			$i_oci->parseExec($insertSQL);
			$insertRowCnts[$talbeName]++;			
		}
	}
}

print_r("EXEC COUNT");
echo "<pre>";
print_r($insertRowCnts);
echo "</pre>";
?>