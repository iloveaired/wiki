<?php
//include_once $_SERVER['DOCUMENT_ROOT'].'/eai/conf/config.inc';
include_once '/data/project/uwayapply.com/kcas/eai/conf/config.inc';


// function getMilliSeconds2($prev_milliseconds,$next_milliseconds){
//   return round(($next_milliseconds - $prev_milliseconds)*1000)/1000; 
// }
	$options = array(
			'uri'=>'http://schemas.xmlsoap.org/soap/envelope/',
			'style'=>SOAP_RPC,
			'use'=>SOAP_ENCODED,
			'soap_version'=>SOAP_1_1,
			'cache_wsdl'=>WSDL_CACHE_NONE,
			'connection_timeout'=>15,
			'trace'=>true,
			'encoding'=>'UTF-8',
			'exceptions'=>true,
		);
			include_once _EAI_COMMON_DIR_.'/class.IF_COMMON_ENT003_SOAP.inc';
			$milliseconds = round(microtime(true) * 1000)/1000;
			$soapClient   = new IF_COMMON_ENT003_SOAP(_EAI_ROOT_.'/wsdl/server_jinhak'."/IF_COMMON_ENT003.wsdl",$options);
			$input        = new COMMON_ENT_003();
			$search_cond  = new SEARCH_COND();
			
			$_DATA['INTEG_ID'] = 'sykim';
			if(count($_DATA) > 0){ foreach($_DATA as $k=>$v){
				$search_cond->{$k} = $v;
			}}
			
			$input->SEARCH_COND = $search_cond;

			$rst = $soapClient->receive($input);	//COMMON_ENT_RES_003 Object 리턴
echo "<pre>";
print_r($rst);
echo "</pre>";


echo "<pre>";
print_r('SERVER IP : ' . $_SERVER['SERVER_ADDR']);
echo "</pre>";




soapDebug($soapClient);

die();
/*
class COMMON_ENT_003{
    public $SEARCH_COND;

    function COMMON_ENT_003($SEARCH_COND) 
    {
        $this->SEARCH_COND = $SEARCH_COND;
    }
}



class SEARCH_COND {
    public $INTEG_ID; // string
    public $CMF_UID;  // string

    function SEARCH_COND($INTEG_ID, $CMF_UID) 
    {
        $this->INTEG_ID = $INTEG_ID;
        $this->CMF_UID  = $CMF_UID;
    }
} 



try{

	$options = array(
			'uri'=>'http://schemas.xmlsoap.org/soap/envelope/',
			'style'=>SOAP_RPC,
			'use'=>SOAP_ENCODED,
			'soap_version'=>SOAP_1_1,
			'cache_wsdl'=>WSDL_CACHE_NONE,
			'connection_timeout'=>15,
			'trace'=>true,
			'encoding'=>'UTF-8',
			'exceptions'=>true,
		);


	$input = new COMMON_ENT_003( new SEARCH_COND('sykim','') );
	$soap  = new SoapClient(_EAI_ROOT_.'/wsdl/server_jinhak'."/IF_COMMON_ENT003.wsdl", $options);
	$rst   = $soap->COMMON_ENT_003($input);




echo "<pre>";
print_r('SERVER IP : ' . $_SERVER['SERVER_ADDR']);
echo "</pre>";


echo "<pre>";
print_r('RETURN :');
print_r($rst);
echo "</pre>";


soapDebug($soap);

}catch(SoapFault $e){
	echo "SoapFault";	
	echo "<pre>";
	print_r($e);
	echo "</pre>";
	//$log = date("Y/m/d H:i:s"). " ". print_r($e);
}catch(Exception $e){

echo "Exception";	
echo "<pre>";
print_r($e);
echo "</pre>";
}

*/


?>