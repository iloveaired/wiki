<?php
include $_SERVER['DOCUMENT_ROOT']."/eai/conf/config.inc";
//error_reporting(E_ALL ^ E_NOTICE);
error_reporting(E_ALL);

require(_EAI_COMMON_DIR_.'/class.EAIApi.php');

$arrowMethod = array('if_user_ent002', 'if_user_ent004', 'if_user_ent005', 'if_user_ent006', 'if_common_ent001', 'if_self_ent001');

$url = 'http://kcasdev.uwayapply.com/eai/api/json_server.php';
$arrowMethod = array('if_user_ent002', 'if_user_ent004', 'if_user_ent005', 'if_user_ent006', 'if_common_ent001', 'if_self_ent001');

function callURL($post){
	global $url;
	$eai = new EAIApi();


	$result = $eai->eaiApi($post['mode'], $postRaw);

	var_dump($result);

	
		
	//assert($s->data->rsltYn == "N");	

}


// 통합회원ID중복체크 테스트
function if_common_ent001(){	

	$params = array( 'INTEG_ID' => 'uwaykcue20305');
	
	$eai = new EAIApi();

	$result = $eai->eaiApi(__FUNCTION__, $params);
	assert($params['INTEG_ID'] == $result['data']['INTEG_ID']);

//var_dump($result);
	
}


// 통합회원ID중복체크 테스트
function if_user_ent002(){	


	$params = array("INTEG_ID_HASH"=> "61107ed106e9fce1f0267808cff6cb1f1d9b7e1f7258045c642a82b9d478f2e");
	$eai = new EAIApi();

	$result = $eai->eaiApi(__FUNCTION__, $params);

	assert($result['data']['DUP_YN'] == 'N');
	
}

function if_user_ent004(){
	$name = "";
	$yyyymmdd = "";
	$cral_tel_hash = "";

	$params = array( 'NAME' => $name, 
		'BRDY_YYMMDD' => $yyyymmdd,
		'CRAL_TEL' => $cral_tel_hash
	); 
	
	$eai = new EAIApi();

	$result = $eai->eaiApi(__FUNCTION__, $params);
	
}

// http://kcasdevlcl.uwayapply.com/eai/eaiTest.php
//if_common_ent001();
//if_user_ent002();

echo $h['k1'];


?>