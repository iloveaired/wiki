<?php
//include_once $_SERVER['DOCUMENT_ROOT'].'/eai/conf/config.inc';



include_once '/data/project/uwayapply.com/kcas/eai/conf/config.inc';
include_once _EAI_COMMON_DIR_.'/class.IF_USER_ENT002_SOAP.inc';
function getMilliSeconds_test($prev_milliseconds,$next_milliseconds){
	return round(($next_milliseconds - $prev_milliseconds)*1000)/1000; 
}
$log = "init";


try{

		//$option = array('trace' => 1);

		//$soapClient = new IF_USER_ENT002_SOAP(_EAI_WSDL_CLIENT_DIR_."/IF_USER_ENT002.wsdl",$option);
		
		// uway wsdl server
		$soapClient = new IF_USER_ENT002_SOAP(_EAI_WSDL_SERVER_DIR_."/IF_USER_ENT002.wsdl",$option);

		
		$input			= new USER_ENT_002();
		$search_cond	= new SEARCH_COND();
		
		$milliseconds = round(microtime(true) * 1000)/1000;
		$search_cond->INTEG_ID_HASH = 'a96d83cc4bed5fe32984cfb728ab3994a78dd4f90fcd3b13fcb640d8986c561f'; //INTEG_ID_HASH
		
		$input->SEARCH_COND = $search_cond;
		

		for($i  = 0; $i < 1; $i++){

			$rst = $soapClient->receive($input);	//USER_ENT_RES_002 Object 리턴
		
		}

		
		$exectime = getMilliSeconds_test($milliseconds,round(microtime(true) * 1000)/1000);

		$log =   date("Y/m/d H:i:s"). " $exectime";

}catch(SoapFault $e){
	$log = date("Y/m/d H:i:s"). " ". $e->getMessage()	;
	//$log = date("Y/m/d H:i:s"). " ". print_r($e);
}catch(Exception $e){
	
	$log = date("Y/m/d H:i:s"). " ". $e->getMessage()	;
}

echo $log."\n";

