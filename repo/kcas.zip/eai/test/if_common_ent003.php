<?php
//include_once $_SERVER['DOCUMENT_ROOT'].'/eai/conf/config.inc';
include_once '/data/project/uwayapply.com/kcas/eai/conf/config.inc';


try{

	$options = array(
			'uri'=>'http://schemas.xmlsoap.org/soap/envelope/',
			'style'=>SOAP_RPC,
			'use'=>SOAP_ENCODED,
			'soap_version'=>SOAP_1_1,
			'cache_wsdl'=>WSDL_CACHE_NONE,
			'connection_timeout'=>15,
			'trace'=>true,
			'encoding'=>'UTF-8',
			'exceptions'=>true,
		);

		include_once _EAI_COMMON_DIR_.'/class.IF_COMMON_ENT003_SOAP.inc';
		$milliseconds = round(microtime(true) * 1000)/1000;
		$soapClient   = new IF_COMMON_ENT003_SOAP(_EAI_WSDL_CLIENT_DIR_."/IF_COMMON_ENT003.wsdl");
		$input        = new COMMON_ENT_003();
		$search_cond  = new SEARCH_COND();
		
		$_DATA['INTEG_ID'] = 'tjdgml3917';
		if(count($_DATA) > 0){ foreach($_DATA as $k=>$v){
			$search_cond->{$k} = $v;
		}}
		
		$input->SEARCH_COND = $search_cond;

		$rst = $soapClient->receive($input);	//COMMON_ENT_RES_003 Object 리턴

echo "<pre>";
print_r('SERVER IP : ' . $_SERVER['SERVER_ADDR']);
echo "</pre>";


echo "<pre>";
print_r('RETURN :');
print_r($rst);
echo "</pre>";


soapDebug($soap);

}catch(SoapFault $e){
	echo "SoapFault";	
	echo "<pre>";
	print_r($e);
	echo "</pre>";
	//$log = date("Y/m/d H:i:s"). " ". print_r($e);
}catch(Exception $e){

echo "Exception";	
echo "<pre>";
print_r($e);
echo "</pre>";
}




?>