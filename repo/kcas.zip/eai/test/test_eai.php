<?
for($i = 0; $i < 1000; $i++ )
{
	//$data = 'idididi'.$i;
	$data = 'idididi'.$i;
	echo hash('sha256', $data).'<br>';

}


die();
include_once '/data/project/uwayapply.com/kcas/eai/conf/config.inc';

require(_EAI_COMMON_DIR_.'/class.EAIApi.php');

function getMilliSeconds_test($prev_milliseconds,$next_milliseconds){
	return round(($next_milliseconds - $prev_milliseconds)*1000)/1000; 
}

$eai = new EAIApi();

$arrowMethod = array('if_user_ent002', 'if_user_ent004', 'if_user_ent005', 'if_user_ent006', 'if_common_ent001', 'if_self_ent001');


$method = "if_user_ent002";
$params = array( 'INTEG_ID_HASH' => "a96d83cc4bed5fe32984cfb728ab3994a78dd4f90fcd3b13fcb640d8986c561");

// switch( $method )
// {
// 	case 'if_user_ent002'	: $params = array( 'INTEG_ID_HASH' => "a96d83cc4bed5fe32984cfb728ab3994a78dd4f90fcd3b13fcb640d8986c561f"); break;
// 	case 'if_user_ent004'	: $params = array( 'NAME' => $_REQUEST['NAME'], 'BRDY_YYMMDD' => $_REQUEST['BRDY_YYMMDD'], 'CRAL_TEL' => $_REQUEST['CRAL_TEL'] ); break;
// 	case 'if_user_ent005'	: $params = array( 'NAME' => $_REQUEST['NAME'], 'BRDY_YYMMDD' => $_REQUEST['BRDY_YYMMDD'], 'EMAIL' => $_REQUEST['EMAIL'] ); break;
// 	case 'if_user_ent006'	: $params = array( 'INTEG_ID_HASH' => $_REQUEST['INTEG_ID_HASH'] ); break;
// 	case 'if_common_ent001'	: $params = array( 'INTEG_ID' => $_REQUEST['INTEG_ID'] ); break;
// 	case 'if_self_ent001'	: $params = array( 'INTEG_ID' => $_REQUEST['INTEG_ID'] ); break;
// }

$milliseconds = round(microtime(true) * 1000)/1000;

$result = $eai->eaiApi($method,$params);

$exectime = getMilliSeconds_test($milliseconds,round(microtime(true) * 1000)/1000);

$log =   date("Y/m/d H:i:s"). " $exectime";

var_dump($result);
