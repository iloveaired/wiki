<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<title>wsdlTest</title>
	<style>
		body {font-size:10pt;}
	</style>
</head>
<body>

<?

if(strpos($_SERVER['REMOTE_ADDR'], "210.92.76.") === false){
	die();
}





	//include(dirname(__FILE__)."/")
$mydir = dirname(__FILE__)."/../wsdl/";
$client_dir = dirname(__FILE__)."/../client/";

$_DATA_FIELD = array(
	"INTEG_ID","INTEG_ID_HASH","NAME","BRDY_YYMMDD","CRAL_TEL","EMAIL"
);


$_SERVER_MAPPING = array(
	"EAI"=>array(
		array(
			"IP"=>"192.168.3.21"
			,"HOST"=>"192.168.3.21"
			,"PORT"=>"57710"
		)
		,array(
			"IP"=>"192.168.3.22"
			,"HOST"=>"192.168.3.22"
			,"PORT"=>"57710"
		)
		,array(
			"IP"=>"192.168.3.23"
			,"HOST"=>"192.168.3.23"
			,"PORT"=>"57710"
		)
		,array(
			"IP"=>"192.168.3.24"
			,"HOST"=>"192.168.3.24"
			,"PORT"=>"57710"
		)
		,array(
			"IP"=>"192.168.3.96"
			,"HOST"=>"192.168.3.96"
			,"PORT"=>"57710"
		)
	)
	,"UWAY"=>array(
		array(
			"IP"=>"192.168.3.106"
			,"HOST"=>"kcas.uwayapply.com"
			,"PORT"=>"80"
		)
		,array(
			"IP"=>"192.168.3.107"
			,"HOST"=>"kcas.uwayapply.com"
			,"PORT"=>"80"
		)
		,array(
			"IP"=>"192.168.3.108"
			,"HOST"=>"kcas.uwayapply.com"
			,"PORT"=>"80"
		)
		,array(
			"IP"=>"192.168.3.109"
			,"HOST"=>"kcas.uwayapply.com"
			,"PORT"=>"80"
		)
		,array(
			"IP"=>"192.168.3.110"
			,"HOST"=>"kcas.uwayapply.com"
			,"PORT"=>"80"
		)
		,array(
			"IP"=>"192.168.3.105"
			,"HOST"=>"kcas.uwayapply.com"
			,"PORT"=>"80"
		)
		,array(
			"IP"=>"192.168.3.104"
			,"HOST"=>"kcas.uwayapply.com"
			,"PORT"=>"80"
		)
		,array(
			"IP"=>"192.168.3.103"
			,"HOST"=>"kcas.uwayapply.com"
			,"PORT"=>"80"
		)
		/*
		,array(
			"IP"=>"192.168.3.102"
			,"HOST"=>"kcas.uwayapply.com"
			,"PORT"=>"80"
		)
		*/
		,array(
			"IP"=>"192.168.3.89"
			,"HOST"=>"kcas.uwayapply.com"
			,"PORT"=>"80"
		)
		,array(
			"IP"=>"192.168.3.90"
			,"HOST"=>"kcas.uwayapply.com"
			,"PORT"=>"80"
		)
	)
);








$_DATA_MAPPING = array(
	'IF_COMMON_ENT001.wsdl'=>array(
		"INTEG_ID"
		,"CMF_UID"
	)
	,'IF_COMMON_ENT003.wsdl'=>array(
		"INTEG_ID"
		,"CMF_UID"
	)
	,'IF_SELF_ENT001.wsdl'=>array(
		"INTEG_ID"
		,"CMF_UID"
	)
	,'IF_USER_ENT002.wsdl'=>array(
		"INTEG_ID_HASH"
	)
	,'IF_USER_ENT004.wsdl'=>array(
		"NAME"
		,"BRDY_YYMMDD"
		,"CRAL_TEL"
	)
	,'IF_USER_ENT005.wsdl'=>array(
		"NAME"
		,"BRDY_YYMMDD"
		,"EMAIL"
	)
	,'IF_USER_ENT006.wsdl'=>array(
		"INTEG_ID_HASH"
	)
		
);


//http://kcas.uwayapply.com/eai/wsdl/server/IF_USER_ENT002.wsdl
//http://kcas.uwayapply.com/eai/wsdl/client/IF_USER_ENT002.wsdl


$_DATA_SOAP_MAPPING = array(
	'EAI'=>array(
		'IF_COMMON_ENT001.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/route/KCUE/B340014JIN/Request/COMMON/IF_COMMON_ENT001"
		,'IF_COMMON_ENT003.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/route/KCUE/B340014JIN/Request/COMMON/IF_COMMON_ENT003"
		,'IF_SELF_ENT001.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/route/KCUE/B340014JIN/Request/SELF/IF_SELF_ENT001"
		,'IF_USER_ENT002.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/route/KCUE/B340014JIN/Request/USER/IF_USER_ENT002"
		,'IF_USER_ENT004.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/route/KCUE/B340014JIN/Request/USER/IF_USER_ENT004"
		,'IF_USER_ENT005.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/route/KCUE/B340014JIN/Request/USER/IF_USER_ENT005"
		,'IF_USER_ENT006.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/route/KCUE/B340014JIN/Request/USER/IF_USER_ENT006"
	)
	,'UWAY'=>array(
		'IF_COMMON_ENT001.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/eai/server/if_common_ent001.php"
		,'IF_COMMON_ENT003.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/eai/server/if_common_ent003.php"
		,'IF_SELF_ENT001.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/eai/server/if_self_ent001.php"
		,'IF_USER_ENT002.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/eai/server/if_user_ent002.php"
		,'IF_USER_ENT004.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/eai/server/if_user_ent004.php"
		,'IF_USER_ENT005.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/eai/server/if_user_ent005.php"
		,'IF_USER_ENT006.wsdl'=>"http://{{SERVER_IP}}:{{SERVER_PORT}}/eai/server/if_user_ent006.php"
	)
);

if($_REQUEST['mode']=="submit" && !empty($_REQUEST['serverGb']) && !empty($_REQUEST['wsdlGb'])){
	
	echo "Request Time : ".date("Y-m-d H:i:s")."<br><br>";
	
	
	$get_xml = file_get_contents(dirname(__FILE__)."/server/".$_REQUEST['wsdlGb'].".xml");
	
	foreach($_DATA_MAPPING[$_REQUEST['wsdlGb']] as $k=>$v){
		$get_xml = str_replace("{{".$v."}}", $_REQUEST[$v], $get_xml);
	}
	
	
	foreach($_SERVER_MAPPING[$_REQUEST['serverGb']] as $k=>$v){
		get_soap_curl($v['IP'],$v['HOST'],$v['PORT'],$_DATA_SOAP_MAPPING[$_REQUEST['serverGb']][$_REQUEST['wsdlGb']],$get_xml);
	}
	
	//print_r($get_xml);
}



function get_soap_curl($ip,$host,$port,$soap_url,$xml){
	
	$xml = str_replace("{{SERVER_HOST}}", $host, $xml);
	$xml = str_replace("{{SERVER_PORT}}", $port, $xml);
	
	$soap_url = str_replace("{{SERVER_IP}}", $ip, $soap_url);
	$soap_url = str_replace("{{SERVER_PORT}}", $port, $soap_url);

	
	$ch = curl_init($soap_url);
	
	$headers = array(
			"Content-type: text/xml;charset=\"utf-8\"",
			"Accept: text/xml",
			"Cache-Control: no-cache",
			"Pragma: no-cache",
			"SOAPAction: {$soap_url}",
			"Content-length: ".strlen($xml),
			'Host: '.$host
	); //SOAPAction: your op URL
	
	curl_setopt($ch, CURLOPT_PORT, $port);
	curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
	curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
	curl_setopt($ch, CURLOPT_HTTPAUTH, CURLAUTH_ANY);
	curl_setopt($ch, CURLOPT_TIMEOUT, 10);
	curl_setopt($ch, CURLOPT_POST, true);
	curl_setopt($ch, CURLOPT_POSTFIELDS, $xml); // the SOAP request
	
	$response = curl_exec($ch);
	
	$info = curl_getinfo($ch);
	
	curl_close($ch);
	
	echo "Request Result ------------------------------------------------------------------------------------------------- <br />";
	echo "URL => ".$info['url']."<br>";
	echo "HOST => ".$host."<br>";
	echo "".($info['http_code']=="200"?"<b style='color:blue'>HTTP_CODE => ".$info['http_code']."</b>":"<b style='color:red'>HTTP_CODE => ".$info['http_code']."</b>")."<br>";
	echo "<xmp>";
	
	//print_r($info);
	
	
	
	echo "</xmp>";
	echo "<br>Result Data -- <a href='javascript:;' onclick='var a = document.getElementById(\"soap_{$ip}\");if(a.style.display==\"none\"){a.style.display=\"\";} else {a.style.display=\"none\";};'>[보기]</a><br>";
	echo "<xmp id='soap_{$ip}' style='display:none;'>";
	echo str_replace(">", ">\n", $response);
	echo "</xmp>";
	
	
	echo "<br>";
}


?>

<form name="testFrm" method="post">
<input type="hidden" name="mode" value="submit" />
<select name="serverGb">
	<option value="EAI" <?=($_REQUEST['serverGb']=="EAI")?"selected":""?>> =>> EAI</option>
	<option value="UWAY" <?=($_REQUEST['serverGb']=="UWAY")?"selected":""?>> =>> UWAY</option>
</select>
<select name="wsdlGb">

	<option value="IF_COMMON_ENT001.wsdl" <?=($_REQUEST['wsdlGb']=="IF_COMMON_ENT001.wsdl")?"selected":""?>>IF_COMMON_ENT001 공통원서(INTEG_ID)</option>
	<option value="IF_COMMON_ENT003.wsdl" <?=($_REQUEST['wsdlGb']=="IF_COMMON_ENT003.wsdl")?"selected":""?>>IF_COMMON_ENT003 공통원서존재유무(INTEG_ID)</option>
	<option value="IF_SELF_ENT001.wsdl" <?=($_REQUEST['wsdlGb']=="IF_SELF_ENT001.wsdl")?"selected":""?>>IF_SELF_ENT001 자기소개서(INTEG_ID)</option>
	<option value="IF_USER_ENT002.wsdl" <?=($_REQUEST['wsdlGb']=="IF_USER_ENT002.wsdl")?"selected":""?>>IF_USER_ENT002 통합회원ID중복체크(INTEG_ID_HASH)</option>
	<option value="IF_USER_ENT004.wsdl" <?=($_REQUEST['wsdlGb']=="IF_USER_ENT004.wsdl")?"selected":""?>>IF_USER_ENT004 휴대전화중복("NAME","BRDY_YYMMDD","CRAL_TEL")</option>
	<option value="IF_USER_ENT005.wsdl" <?=($_REQUEST['wsdlGb']=="IF_USER_ENT005.wsdl")?"selected":""?>>IF_USER_ENT005 메일중복("NAME","BRDY_YYMMDD","EMAIL")</option>
	<option value="IF_USER_ENT006.wsdl" <?=($_REQUEST['wsdlGb']=="IF_USER_ENT006.wsdl")?"selected":""?>>IF_USER_ENT006 캐시확인(INTEG_ID_HASH)</option>
</select>
<input type="submit" value="확인">
<br />
<br />

<?php
foreach($_DATA_FIELD as $k=>$v){ 
?>
<div><?=$v?> : </div>
<input type="text" name="<?=$v?>" value="<?=$_REQUEST[$v]?>" style="width:700px;" /><br />
<?php
} 
?>
</form>
</body>
</html>