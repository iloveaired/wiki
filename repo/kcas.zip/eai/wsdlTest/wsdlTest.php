<?

if(strpos($_SERVER['REMOTE_ADDR'], "210.92.76.") === false){
	die();
}

	//include(dirname(__FILE__)."/")
$mydir = dirname(__FILE__)."/../wsdl/";
$client_dir = dirname(__FILE__)."/../client/";

$_DATA_FIELD = array(
	"INTEG_ID","INTEG_ID_HASH","NAME","BRDY_YYMMDD","CRAL_TEL","EMAIL"
);

if($_REQUEST['mode']=="submit" && !empty($_REQUEST['serverGb']) && !empty($_REQUEST['wsdlGb'])){
	
	$_MODE = "api";
	
	define('_EAI_WSDL_CLIENT_DIR_'	, $mydir.$_REQUEST['serverGb']);
	define('_EAI_TARGET_AGENT_',($_REQUEST['serverGb']=="client_jinhak")?2:1);
	
	
	if(!empty($_REQUEST["INTEG_ID_CONVERT"]) && empty($_REQUEST['INTEG_ID_HASH'])){
		$_REQUEST['INTEG_ID_HASH'] = hash("sha256",$_REQUEST["INTEG_ID_CONVERT"]);
	}
	
	
	$_DATA = array();
	foreach($_DATA_FIELD as $k=>$v){
		if(!empty($_REQUEST[$v])) $_DATA[$v] = $_REQUEST[$v];
	}
	
	include $client_dir.$_REQUEST['wsdlGb'];
	
	//echo _EAI_WSDL_CLIENT_DIR_;
	
	
	
	echo "<pre>";
	echo "��ȸ�ð� : ".date("Y-m-d H:i:s")."\n\n";
	
	if(!empty($_REQUEST["INTEG_ID_CONVERT"]) && empty($_REQUEST['INTEG_ID_HASH'])){
		echo "INTEG_ID CONVERT ��� : \n";
		echo $_REQUEST['INTEG_ID_CONVERT']." => ".hash("sha256",$_REQUEST["INTEG_ID_CONVERT"])."\n\n";
	}
	
	echo "Soap Request Data : ";
	print_r($_DATA);
	
	//echo "URL $"."_REQUEST �������� : ";
	//print_r($_REQUEST);
	
	echo "SOAP Result : ";
	print_r($_RETURN);
	echo "</pre>";
}
?>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
	<title>wsdlTest</title>
</head>
<body>
<form name="testFrm" method="post">
<input type="hidden" name="mode" value="submit" />
<select name="serverGb">
	<option value="server" <?=($_REQUEST['serverGb']=="server")?"selected":""?>>eai -> uway</option>
	<option value="server_dev" <?=($_REQUEST['serverGb']=="server_dev")?"selected":""?>>eai dev -> uway dev</option>
	<option value="client" <?=($_REQUEST['serverGb']=="client")?"selected":""?>>uway -> eai</option>
	<option value="client_dev" <?=($_REQUEST['serverGb']=="client_dev")?"selected":""?>>uway dev -> eai dev</option>
	<option value="client_jinhak" <?=($_REQUEST['serverGb']=="client_jinhak")?"selected":""?>>jinhak</option>
</select>
<select name="wsdlGb">
	<option value="if_common_ent001.php" <?=($_REQUEST['wsdlGb']=="if_common_ent001.php")?"selected":""?>>if_common_ent001.php �������(INTEG_ID)</option>
	<option value="if_common_ent003.php" <?=($_REQUEST['wsdlGb']=="if_common_ent003.php")?"selected":""?>>if_common_ent003.php ���������������(INTEG_ID)</option>
	<option value="if_self_ent001.php" <?=($_REQUEST['wsdlGb']=="if_self_ent001.php")?"selected":""?>>if_self_ent001.php �ڱ�Ұ���(INTEG_ID)</option>
	<option value="if_user_ent002.php" <?=($_REQUEST['wsdlGb']=="if_user_ent002.php")?"selected":""?>>if_user_ent002.php ����ȸ��ID�ߺ�üũ(INTEG_ID_HASH)</option>
	<option value="if_user_ent004.php" <?=($_REQUEST['wsdlGb']=="if_user_ent004.php")?"selected":""?>>if_user_ent004.php �޴���ȭ�ߺ�("NAME","BRDY_YYMMDD","CRAL_TEL")</option>
	<option value="if_user_ent005.php" <?=($_REQUEST['wsdlGb']=="if_user_ent005.php")?"selected":""?>>if_user_ent005.php �����ߺ�("NAME","BRDY_YYMMDD","EMAIL")</option>
	<option value="if_user_ent006.php" <?=($_REQUEST['wsdlGb']=="if_user_ent006.php")?"selected":""?>>if_user_ent006.php ĳ��Ȯ��(INTEG_ID_HASH)</option>
</select>
<input type="submit" value="Ȯ��">
<br />
<br />

INTEG_ID (�ؽð����� �������) : <br />
<input type="text" name="INTEG_ID_CONVERT" value="<?=$_REQUEST['INTEG_ID_CONVERT']?>" />
 => <input type="text" name="INTEG_ID_CONVERT_RESULT" value="<?=$_REQUEST['INTEG_ID_CONVERT_RESULT']?>" /><br />
<br />
<br />
<?php
foreach($_DATA_FIELD as $k=>$v){ 
?>
<div><?=$v?> : </div>
<input type="text" name="<?=$v?>" value="<?=$_REQUEST[$v]?>" style="width:700px;" /><br />
<?php
} 
?>
</form>
</body>
</html>