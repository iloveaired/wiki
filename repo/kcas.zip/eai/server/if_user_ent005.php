<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/eai/conf/config.inc';
include_once _EAI_COMMON_DIR_.'/class.IF_USER_ENT005_SOAP.inc';


$isDev = false;
if(isset($_SERVER['HTTP_HOST'][0])){
	$isDev = preg_match('/^[^\.]*(dev|re)(|l|lcl)[^\.]*\./',$_SERVER['HTTP_HOST']);  //개발서버는제외
}

if($isDev){
	$_SERVER['SERVER_NAME'] = "SOAP_DEV";
	$_SERVER['REQUEST_URI'] = "SOAP_DEV";

}else {
	$_SERVER['SERVER_NAME'] = "SOAP";
	$_SERVER['REQUEST_URI'] = "SOAP";
}



$server = new SoapServer(_EAI_WSDL_SERVER_DIR_."/IF_USER_ENT005.wsdl");
$server->setClass("IF_USER_ENT005_SOAP_SERVER");
$server->handle();




?>