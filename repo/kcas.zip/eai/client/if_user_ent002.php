<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/eai/conf/config.inc';

$soapOptions = ( isset($soapOptions) ) ? $soapOptions : $_SOAP_OPTIONS;

try{
	if(isset($_MODE) && $_MODE=="api"){

		if( _EAI_TARGET_AGENT_ == '1' )
		{
			include_once _EAI_COMMON_DIR_.'/class.IF_USER_ENT002_SOAP.inc';

			$soapClient  = new IF_USER_ENT002_SOAP(_EAI_WSDL_CLIENT_DIR_."/IF_USER_ENT002.wsdl",$soapOptions);
			$input       = new USER_ENT_002();
			$search_cond = new SEARCH_COND();
			
			if(count($_DATA) > 0)
			{ 
				foreach($_DATA as $k=>$v)
				{
					$search_cond->{$k} = $v;
				}
			}
			
			$input->SEARCH_COND = $search_cond;
			
			$rst = $soapClient->receive($input);	//USER_ENT_RES_002 Object ����
		}
		else if( _EAI_TARGET_AGENT_ == '2' )
		{
			include_once _EAI_COMMON_DIR_.'/class.IF_USER_ENT002_SOAP_SSL.inc';

			$input      = new USER_ENT_002( new SEARCH_COND($_DATA['INTEG_ID_HASH']) );
			$soapClient = new SoapClient(_EAI_WSDL_CLIENT_DIR_."/IF_USER_ENT002.wsdl",$soapOptions);
			$rst        = $soapClient->USER_ENT_002($input);
		}
		else
		{
			$rst = null;
		}

		$_RETURN = $rst;

	} else {

		//$option = array('trace' => 1);
		$option = array();
		$_DATA['INTEG_ID_HASH'] = '96508a508d9dba6fa1e1db19c5eacb1767f2bf5c7baf4b725016669ecc443da0';


		if( _EAI_TARGET_AGENT_ == '1' )
		{
			include_once _EAI_COMMON_DIR_.'/class.IF_USER_ENT002_SOAP.inc';

			$soapClient  = new IF_USER_ENT002_SOAP(_EAI_WSDL_CLIENT_DIR_."/IF_USER_ENT002.wsdl", $option);
			$input       = new USER_ENT_002();
			$search_cond = new SEARCH_COND();
			
			if(count($_DATA) > 0)
			{ 
				foreach($_DATA as $k=>$v)
				{
					$search_cond->{$k} = $v;
				}
			}
			
			$input->SEARCH_COND = $search_cond;

			$rst = $soapClient->receive($input);	//USER_ENT_RES_002 Object ����

		}
		else if( _EAI_TARGET_AGENT_ == '2' )
		{
			include_once _EAI_COMMON_DIR_.'/class.IF_USER_ENT002_SOAP_SSL.inc';

			$input      = new USER_ENT_002( new SEARCH_COND($_DATA['INTEG_ID_HASH']) );
			$soapClient = new SoapClient(_EAI_WSDL_CLIENT_DIR_."/IF_USER_ENT002.wsdl",$option);
			$rst        = $soapClient->USER_ENT_002($input);
		}
		else
		{
			$rst = null;
		}


		//debug
		if( $_REQUEST['debug'] == '1' )
		{
			soapDebug($soapClient);
			die();
		} 
		
		echo "<pre>";
		print_r($rst);
		echo "</pre>";
	}


}catch(SoapFault $e){
	if($_MODE=="api"){
		log_message( 'error', array(			
			'title' => 'EAI client if_user_ent002',
			'msg' => $e->getMessage(),
			'exception'=>$e->getMessage(),				
			'date' => date("Y/m/d H:i:s")			
		) );
		die(json_encode(array("data"=>array(
				"data"=>""
				,"soap_exception"=>$e->getMessage()
				,"rsltYn"=>"N"
				,"msg"=>iconv("EUC-KR","UTF-8","���� ��ſ� ������ �߻��Ͽ����ϴ�. ����ڿ��� �����Ͽ� �ֽñ� �ٶ��ϴ�.")
		))));
	} else {
		echo "<pre>";
		var_dump($e);
		echo  "<br/>".$e->getMessage()."<br/>";
	} 
}catch(Exception $e){

	if($_MODE=="api"){
		die(json_encode(array("data"=>array(
				"data"=>""
				,"exception"=>$e->getMessage()
				,"rsltYn"=>"N"
				,"msg"=>iconv("EUC-KR","UTF-8","���� ��ſ� ������ �߻��Ͽ����ϴ�. ����ڿ��� �����Ͽ� �ֽñ� �ٶ��ϴ�.")
		))));
	} else {
		echo "<pre>";
		var_dump($e);
		echo  "<br/>".$e->getMessage()."<br/>";
	} 


}

