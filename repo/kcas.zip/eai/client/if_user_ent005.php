<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/eai/conf/config.inc';
include_once _EAI_COMMON_DIR_.'/class.IF_USER_ENT005_SOAP.inc';

$soapOptions = ( isset($soapOptions) ) ? $soapOptions : $_SOAP_OPTIONS;

try{

	if(isset($_MODE) && $_MODE=="api"){
		
		$soapClient = new IF_USER_ENT005_SOAP(_EAI_WSDL_CLIENT_DIR_."/IF_USER_ENT005.wsdl",$soapOptions);
				
		$input			= new USER_ENT_005();
		$search_cond	= new SEARCH_COND();
		
		
		if(count($_DATA) > 0){ foreach($_DATA as $k=>$v){
			$search_cond->{$k} = $v;
		}}
		
		$input->SEARCH_COND = $search_cond;
		
		$rst = $soapClient->receive($input);	//USER_ENT_RES_005 Object ����
		
		$_RETURN = $rst;
	} else {
		
		//$soapClient = new IF_USER_ENT005_SOAP(_EAI_WSDL_CLIENT_DIR_."/IF_USER_ENT005.wsdl",$option);
		$soapClient = new IF_USER_ENT005_SOAP(_EAI_WSDL_SERVER_DIR_."/IF_USER_ENT005.wsdl",$soapOptions);
		
		$input			= new USER_ENT_005();
		$search_cond	= new SEARCH_COND();
		
		
		$search_cond->NAME			= iconv( "EUC-KR", "UTF-8", '�׽�Ʈx' );	//NAME
		$search_cond->BRDY_YYMMDD	= '19800414';		//BRDY_YYMMDD
		$search_cond->EMAIL			= 'test@uway.com';	//EMAIL
		
		$input->SEARCH_COND = $search_cond;
		
		$rst = $soapClient->receive($input);	//USER_ENT_RES_005 Object ����
		
		//debug
		if( $_REQUEST['debug'] == '1' )
		{
			soapDebug($soapClient);
			die();
		} 
		
		echo "<pre>";
		print_r($rst);
		echo "</pre>";
	}

}catch(SoapFault $e){
	if($_MODE=="api"){
		log_message( 'error', array(			
			'title' => 'EAI client if_user_ent005',
			'msg' => $e->getMessage(),
			'exception'=>$e->getMessage(),				
			'date' => date("Y/m/d H:i:s")			
		) );

		die(json_encode(array("data"=>array(
				"data"=>""
				,"exception"=>$e->getMessage()
				,"rsltYn"=>"N"
				,"msg"=>iconv("EUC-KR","UTF-8","���� ��ſ� ������ �߻��Ͽ����ϴ�. ����ڿ��� �����Ͽ� �ֽñ� �ٶ��ϴ�.")
		))));
	} else {
		echo "<pre>";
		var_dump($e);
		echo  "<br/>".$e->getMessage()."<br/>";
	} 
}

