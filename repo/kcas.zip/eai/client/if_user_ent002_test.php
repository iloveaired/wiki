<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/eai/conf/config.inc';

ini_set("soap.wsdl_cache_enabled", "0");   




try{
	echo "<xmp>";

	$options = array(
			'uri'=>'http://schemas.xmlsoap.org/soap/envelope/',
			'style'=>SOAP_RPC,
			'use'=>SOAP_ENCODED,
			'soap_version'=>SOAP_1_1,
			'cache_wsdl'=>WSDL_CACHE_NONE,
			'connection_timeout'=>15,
			'trace'=>true,
			'encoding'=>'UTF-8',
			'exceptions'=>true,
		);
	$soap = new SoapClient('https://cwtransu.jinhakapply.com/UwayLinkService.asmx?WSDL', $options);
	$user_ent_002 = array(
			'SEARCH_COND' => new SoapVar( 
				new SoapVar(array('INTEGE_ID_HASH'=>'iloveaired'), SOAP_ENC_OBJECT),
			SOAP_ENC_OBJECT)	
	);

	$rst = $soap->USER_ENT_002($user_ent_002);

var_dump($rst);
soapDebug($soap);

die();


	

$data = $soap->USER_ENT_002($search_cond);
var_dump($soap);
soapDebug($soap);
//var_dump($data);




die();

		$_RETURN = $rst;

		soapDebug($soapClient);

		var_dump($_RETURN);
	
}catch(SoapFault $e){
	if($_MODE=="api"){
		log_message( 'error', array(			
			'title' => 'EAI client if_user_ent002',
			'msg' => $e->getMessage(),
			'exception'=>$e->getMessage(),				
			'date' => date("Y/m/d H:i:s")			
		) );
		die(json_encode(array("data"=>array(
				"data"=>""
				,"soap_exception"=>$e->getMessage()
				,"rsltYn"=>"N"
				,"msg"=>iconv("EUC-KR","UTF-8","���� ��ſ� ������ �߻��Ͽ����ϴ�. ����ڿ��� �����Ͽ� �ֽñ� �ٶ��ϴ�.")
		))));
	} else {
		echo "<pre>";
		var_dump($e);
		echo  "<br/>".$e->getMessage()."<br/>";
	} 
}catch(Exception $e){

	if($_MODE=="api"){
		die(json_encode(array("data"=>array(
				"data"=>""
				,"exception"=>$e->getMessage()
				,"rsltYn"=>"N"
				,"msg"=>iconv("EUC-KR","UTF-8","���� ��ſ� ������ �߻��Ͽ����ϴ�. ����ڿ��� �����Ͽ� �ֽñ� �ٶ��ϴ�.")
		))));
	} else {
		echo "<pre>";
		var_dump($e);
		echo  "<br/>".$e->getMessage()."<br/>";
	} 


}

