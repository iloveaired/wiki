<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/eai/conf/config.inc';
include_once _EAI_COMMON_DIR_.'/class.IF_SELF_ENT001_SOAP.inc';

$soapOptions = ( isset($soapOptions) ) ? $soapOptions : $_SOAP_OPTIONS;

try{
	if(isset($_MODE) && $_MODE=="api"){
		
		$soapClient = new IF_SELF_ENT001_SOAP(_EAI_WSDL_CLIENT_DIR_."/IF_SELF_ENT001.wsdl",$soapOptions);
		
		$input			= new SELF_ENT_001();
		$search_cond	= new SEARCH_COND();
		
		if(count($_DATA) > 0){ foreach($_DATA as $k=>$v){
			$search_cond->{$k} = $v;
		}}
		
		$input->SEARCH_COND = $search_cond;
		
		$rst = $soapClient->receive($input);	//SELF_ENT_RES_001 Object ����
		
		$_RETURN = $rst;
	} else {

		//$soapClient = new IF_SELF_ENT001_SOAP(_EAI_WSDL_CLIENT_DIR_."/IF_SELF_ENT001.wsdl",$option);
		$soapClient = new IF_SELF_ENT001_SOAP(_EAI_WSDL_SERVER_DIR_."/IF_SELF_ENT001.wsdl",$soapOptions);
		
		$input			= new SELF_ENT_001();
		$search_cond	= new SEARCH_COND();
	
		$search_cond->INTEG_ID = 'test0623101712730';										//üũ���̵�
		
		$input->SEARCH_COND = $search_cond;
		
		$rst = $soapClient->receive($input);	//SELF_ENT_RES_001 Object ����

		//debug
		if( $_REQUEST['debug'] == '1' )
		{
			soapDebug($soapClient);
			die();
		} 

		echo "<pre>";
		print_r($rst);
		echo "</pre>";
	}

}catch(SoapFault $e){
	if($_MODE=="api"){
		log_message( 'error', array(			
			'title' => 'EAI client if_self_ent001',
			'msg' => $e->getMessage(),
			'exception'=>$e->getMessage(),				
			'date' => date("Y/m/d H:i:s")			
		) );
		die(json_encode(array("data"=>array(
				"data"=>""
				,"exception"=>$e->getMessage()
				,"rsltYn"=>"N"
				,"msg"=>iconv("EUC-KR","UTF-8","���� ��ſ� ������ �߻��Ͽ����ϴ�. ����ڿ��� �����Ͽ� �ֽñ� �ٶ��ϴ�.")
		))));
	} else {
		echo "<pre>";
		var_dump($e);
		echo  "<br/>".$e->getMessage()."<br/>";
	} 
}
