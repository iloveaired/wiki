<?php
include_once $_SERVER['DOCUMENT_ROOT'].'/eai/conf/config.inc';
include_once _EAI_COMMON_DIR_.'/class.IF_COMMON_ENT001_SOAP.inc';

$soapOptions = ( isset($soapOptions) ) ? $soapOptions : $_SOAP_OPTIONS;

try{

	//json api ����
	if(isset($_MODE) && $_MODE=="api"){
		$milliseconds = round(microtime(true) * 1000)/1000;
		
		$soapClient = new IF_COMMON_ENT001_SOAP(_EAI_WSDL_CLIENT_DIR_."/IF_COMMON_ENT001.wsdl", $soapOptions);
		
		
		$input		= new COMMON_ENT_001();
		$search_cond= new SEARCH_COND();
		
		if(count($_DATA) > 0){ foreach($_DATA as $k=>$v){
			$search_cond->{$k} = $v;
		}}
		
		$input->SEARCH_COND = $search_cond;
		$rst = $soapClient->receive($input);	//COMMON_ENT_RES_001 Object ����
		if(is_array($rst->SEARCH_RSLT->RRNO_UPDATE_YN)) { // FIXME BUG
			$rst->SEARCH_RSLT->RRNO_UPDATE_YN = $rst->SEARCH_RSLT->RRNO_UPDATE_YN[1];
			log_message( 'debug', array(			
				'title' => 'FIXME',
				'msg' => 'RRNO_UPDATE_YN array : '.	print_r($rst->SEARCH_RSLT->RRNO_UPDATE_YN,true),		
				'date' => date("Y/m/d H:i:s")
			) );
		}

		$_RETURN = $rst;
	} else {
		//$options = array('trace' => 1);
 		$soapOptions = array('trace' => 1);
		$soapClient = new IF_COMMON_ENT001_SOAP(_EAI_ROOT_.'/wsdl/client'."/IF_COMMON_ENT001.wsdl", $soapOptions);
		//$soapClient = new IF_COMMON_ENT001_SOAP(_EAI_WSDL_CLIENT_DIR_."/IF_COMMON_ENT001.wsdl", $soapOptions);
		//$soapClient = new IF_COMMON_ENT001_SOAP(_EAI_WSDL_SERVER_DIR_."/IF_COMMON_ENT001.wsdl");


		$input		= new COMMON_ENT_001();
		$search_cond= new SEARCH_COND();
		
		$search_cond->INTEG_ID = $_REQUEST['integ_id'];								//üũ���̵�
		
		$input->SEARCH_COND = $search_cond;
		$rst = $soapClient->receive($input);	//COMMON_ENT_RES_001 Object ����

		var_dump($rst->SEARCH_RSLT->RRNO_UPDATE_YN);
		if(is_array($rst->SEARCH_RSLT->RRNO_UPDATE_YN)) { // FIXME BUG
			$rst->SEARCH_RSLT->RRNO_UPDATE_YN = $rst->SEARCH_RSLT->RRNO_UPDATE_YN[1];
			log_message( 'debug', array(			
				'title' => 'FIXME',
				'msg' => 'RRNO_UPDATE_YN array : '.	print_r($rst->SEARCH_RSLT->RRNO_UPDATE_YN,true),		
				'date' => date("Y/m/d H:i:s")
			) );
		}
		
		//debug
		if( $_REQUEST['debug'] == '1' )
		{
			soapDebug($soapClient);
			die();
		} 
		
		echo "<pre>";
		print_r($rst);
		echo "</pre>";


	}


}catch(SoapFault $e){
	if($_MODE=="api"){
		log_message( 'error', array(			
			'title' => 'EAI client if_common_ent001',
			'msg' => $e->getMessage(),
			'exception'=>$e->getMessage(),				
			'date' => date("Y/m/d H:i:s")			
		) );
		die(json_encode(array("data"=>array(
				"data"=>""
				,"exception"=>$e->getMessage()
				,"rsltYn"=>"N"
				,"msg"=>iconv("EUC-KR","UTF-8","���� [������� �ҷ�����] ������ ������ ��Ȱ���� �ʽ��ϴ�. ��� �� �ٽ� �õ��� �ֽñ� �ٶ��ϴ�.")
		))));
	} else {
		echo "<pre>";
		var_dump($e);
		echo  "<br/>".$e->getMessage()."<br/>";
	} 
}
