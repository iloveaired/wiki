<? 
ini_set('allow_url_fopen', 'On');

include $_SERVER['DOCUMENT_ROOT']."/eai/conf/config.inc";
require(dirname(__FILE__).'/../common/class.EAIApi.php');

$_DATA = array();
$_RETURN = array();

if(get_magic_quotes_gpc()){
	$_POST['data'] = json_decode(stripslashes($_POST['data']),true);
} else {
	$_POST['data'] = json_decode($_POST['data'],true);
}




$eai = new EAIApi();
if(_IS_DEV_){
	$eai->actionURL = "http://ucashdev.uwayapply.com/server/json_ucash.php";
} else {
	$eai->actionURL = "http://ucash.uwayapply.com/server/json_ucash.php";
}

$result = $eai->eaiApi($_POST['mode'],$_POST['data']);




die(json_encode(array("data"=>array(
		"data"=>$result['data']
		,"rsltYn"=>$result['rsltYn']
		,"msg"=>iconv("EUC-KR","UTF-8",$result['msg'])
))));


