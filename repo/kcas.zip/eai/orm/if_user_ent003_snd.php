<?
include_once $_SERVER['DOCUMENT_ROOT'].'/eai/conf/config.inc';


class IF_USER_ENT003_SND_COLS{
	public $INTEG_ID_HASH;
	//public $SEQ;
	public $WORK_DATE;
	public $OUT_DATE;
	public $OUT_REASON;
	public $OUT_YN;
	public $WORK_GUBN;
	public $CUD_GUBN;
	//public $IF_ID;
	public $IF_STATUS;
	//public $IF_TIME;
	public $IF_MESSG;
		
}

class IF_USER_ENT003_SND extends ORM{
	var $oci = null;
	function IF_USER_ENT003_SND(& $oci){
		$this->oci = $oci;
		parent::ORM($oci);
	}

	function insert($row){
		$filtered_row = $this->filter_by_columns($row); //filter_by_columns($row)
		return parent::insert($filtered_row);
	}

}



$milliseconds = round(microtime(true) * 1000)/1000;

$oci = connectKcasidsDB();
$ku = new KcasUser($oci);

log_message( 'info', array(
	'title' => 'ȸ������ ���� �������� API',
	'msg' => " Altibase ȸ�� DB���� ����",
	'idx1' => myhash_fetch($_DATA, 'INTEG_ID_HASH'),
	'idx2' => $_REQUEST_KEY,
	'idx3' => $_POST['mode'],
	'data' => serialize($_POST['data']),
	'milliseconds' => getMilliSeconds($milliseconds,round(microtime(true) * 1000)/1000)
) );

$milliseconds = round(microtime(true) * 1000)/1000;

//json api ����
if(isset($_MODE) && $_MODE=="api"){
	
	/*
	
	$sh = array();
	$sh['INTEG_ID_HASH'] = $_DATA['INTEG_ID_HASH'];
	//$sh['CMF_UID'] = $search_rslt->CMF_UID;
	$rows = $ku->pull($sh);
	$row = $rows[0];
	
	log_message( 'info', array(
		'title' => 'ȸ������ ���� �������� API',
		'msg' => " Altibase ȸ�� ������ �������� ����",
		'idx1' => $_REQUEST_KEY,
		'idx2' => $_POST['mode'],
		'data' => serialize($_POST['data']),
		'milliseconds' => getMilliSeconds($milliseconds,round(microtime(true) * 1000)/1000)
	) );
	
	$milliseconds = round(microtime(true) * 1000)/1000;
	
	
	if(!getCompareListTime($row['UWAY_UPDATEDATE'])){
		
		sleep(1);
		
		
		$rows = $ku->pull($sh);
		$row = $rows[0];
		
		log_message( 'info', array(
			'title' => 'ȸ������ ���� �������� API',
			'msg' => "UWAY_UPDATEDATE ���� ����ð��� �޶� ������ �ٽ� ������",
			'idx1' => $_REQUEST_KEY,
			'idx2' => $_POST['mode'],
			'date' => "Now : ".date("YmdHis").", UWAY_UPDATEDATE : ".$row['UWAY_UPDATEDATE'],
			'data' => serialize($_POST['data']),
			'milliseconds' => getMilliSeconds($milliseconds,round(microtime(true) * 1000)/1000)
		) );
		
		$milliseconds = round(microtime(true) * 1000)/1000;
	} else {
		log_message( 'info', array(
			'title' => 'ȸ������ ���� �������� API',
			'msg' => "UWAY_UPDATEDATE ���� �ֱٰ����� ����",
			'idx1' => $_REQUEST_KEY,
			'idx2' => $_POST['mode'],
			'date' => "Now : ".date("YmdHis").", UWAY_UPDATEDATE : ".$row['UWAY_UPDATEDATE'],
			'data' => serialize($_POST['data']),
			'milliseconds' => getMilliSeconds($milliseconds,round(microtime(true) * 1000)/1000)
		) );
		
		$milliseconds = round(microtime(true) * 1000)/1000;
	}
	
	*/
	
} else {
	/*
	$sh = array();
	$sh['INTEG_ID_HASH'] = $_REQUEST['INTEG_ID_HASH'];
	//$sh['CMF_UID'] = $search_rslt->CMF_UID;
	
	$rows = $ku->pull($sh);
	$row = $rows[0];
	print_r($row);
	*/
}

/*
if(empty($row)){
	
	log_message( 'error', array(
		'title' => 'ȸ������ ���� �������� API',
		'msg' => "IF_USER_ENT003_SND Altibase ȸ�� ������ ����",
		'idx1' => $_REQUEST_KEY,
		'idx2' => $_POST['mode'],
		'send_msg' => "���̵� : '".$_DATA['INTEG_ID']."' �ش� ȸ���� �������� �ʽ��ϴ�.",
		'data' => serialize($_POST['data']),
		'milliseconds' => getMilliSeconds($milliseconds,round(microtime(true) * 1000)/1000)
	) );
	
	$milliseconds = round(microtime(true) * 1000)/1000;
	
	die(json_encode(array("data"=>array(
			"data"=>""
			,"rsltYn"=>"N"
			,"msg"=>iconv("EUC-KR","UTF-8","���̵� : '".$_DATA['INTEG_ID']."' �ش� ȸ���� �������� �ʽ��ϴ�.")
	))));
} else {
	$row['OUT_DATE'] = date("Y-m-d H:i:s");
	$row['OUT_REASON'] = iconv("UTF-8","EUC-KR",$_DATA['OUT_REASON']);
	$row['IF_STATUS'] = 'R';
	$row['OUT_YN'] = 'Y';
	$row['WORK_GUBN'] = 'D';
	$row['WORK_DATE'] = date("Ymd");
}
*/

$row['INTEG_ID_HASH'] = $_DATA['INTEG_ID_HASH'];
$row['OUT_DATE'] = date("Y-m-d H:i:s");
$row['OUT_REASON'] = iconv("UTF-8","EUC-KR",$_DATA['OUT_REASON']);
$row['IF_STATUS'] = 'R';
$row['OUT_YN'] = 'Y';
$row['WORK_GUBN'] = 'D';
$row['WORK_DATE'] = date("Ymd");

$row_log = array();
$row_log['INTEG_ID_HASH'] = $_DATA['INTEG_ID_HASH'];
$row_log['OUT_DATE'] = date("Y-m-d H:i:s");
$row_log['OUT_REASON'] = $_DATA['OUT_REASON'];
$row_log['IF_STATUS'] = 'R';
$row_log['OUT_YN'] = 'Y';
$row_log['WORK_GUBN'] = 'D';
$row_log['WORK_DATE'] = date("Ymd");


log_message( 'debug', array(
'title' => 'IF_USER_ENT003_SND',
'msg' => "BACKUP",
'idx1' => $_DATA['INTEG_ID_HASH'],
'data' => serialize($row)
) );


$ormOci = connectOrmDB();
$if_user_ent003_snd = new IF_USER_ENT003_SND($ormOci);

log_message( 'info', array(
	'title' => 'ȸ������ ���� �������� API',
	'msg' => " DB���� ����",
	'idx1' => myhash_fetch($_DATA, 'INTEG_ID_HASH'),
	'idx2' => $_REQUEST_KEY,
	'idx3' => $_POST['mode'],
	'data' => serialize($_POST['data']),
	'milliseconds' => getMilliSeconds($milliseconds,round(microtime(true) * 1000)/1000)
) );

// 1. insert
//$data = array('INTEG_ID' => 'test2', 'NM'=> "dfdfdfdf",'IF_STATUS' => 'R', 'xxx'=> "dfdf");
$if_user_ent003_snd->insert($row);
//echo $ku->error;

log_message( 'info', array(
	'title' => 'ȸ������ ���� �������� API',
	'msg' => "IF_USER_ENT003_SND ������ Insert ����",
	'idx1' => myhash_fetch($_DATA, 'INTEG_ID_HASH'),
	'idx2' => $_REQUEST_KEY,
	'idx3' => $_POST['mode'],
	'insert_data' => serialize($row_log),
	'milliseconds' => getMilliSeconds($milliseconds,round(microtime(true) * 1000)/1000)
) );

$milliseconds = round(microtime(true) * 1000)/1000;

$_RETURN = true;

