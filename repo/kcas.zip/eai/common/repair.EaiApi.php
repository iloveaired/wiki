<?
/**
* Pull/Push Ŭ���̾�Ʈ
* ���� : PHP 5.0 �̻� �ʼ�! cURL ���� �ʼ�!
*/

die('�������');
//include $_SERVER['DOCUMENT_ROOT']."/eai/conf/config.inc";


require(dirname(__FILE__).'/class.EAIApi.php');

header("Content-Type: text/plain;charset=ms949");

//-- ����ȸ��


$eai = new EAIApi();

$eai->actionURL = "http://kcas.uwayapply.com/eai/api/json_server.php";


if(false){
	
	$insert_arr = array(
 '99tmdqor','dk05007','dunky159','leesungwoo99','sanga0720','zipizigy96'
	);
	
	$cnt = 0;
	foreach($insert_arr as $v){
		$result = $eai->eaiApi($method = "if_user_ent001_snd",$params = array("INTEG_ID"=>$v,"INTEG_GUBN"=>"MJ"));
	}
	
}



if(false){

	$update_arr = array(
			'8e3b65564fe73551c517ea160d6033bf72920116262275d5fd205df6469532d8'
	);

	$cnt = 0;
	foreach($update_arr as $v){
		$result = $eai->eaiApi($method = "if_user_ent003_snd",$params = array("INTEG_ID_HASH"=>$v,"OUT_REASON"=>"��Ÿ"));
	}

}




if(false){

	$update_arr = array(
'anstmdcks12','audwls2811','cavin980113','chaeri1116','chldbs1957','dadada9807','dahae0811','dhskrud98','diddmswn3496','dlawldk123','dlduswls98','dlwhdfud','dlwldbs9311','dong1127','elliot05','fijiwolf','gksehddnr','golddong98','hsjin0323','ja30121','jaeho3001','jchan6931','jhjh2514','jhwo98','jmd62','jwjw0327','kasu5314','kwonsp98','ljk990','lung4536','marvelwill99','pinkjw97','soohan98','ssen16','tjdgus0821','wnehfdl98','xiah4526','yywing2','zipizigy96'
	);

	$cnt = 0;
	foreach($update_arr as $v){
		$result = $eai->eaiApi($method = "if_user_ent001_snd",$params = array("INTEG_ID"=>$v,"INTEG_GUBN"=>"MM"));
		//$result = $eai->eaiApi($method = "if_user_ent001_snd",$params = array("INTEG_ID"=>$v,"INTEG_GUBN"=>"PM"));
	}

}


if(false){

	$update_arr = array(
'tlwlsrhaehf','atoz1030','cmj1215','tjqlalf','sooha102','sj12499'
	);

	$cnt = 0;
	foreach($update_arr as $v){
		$result = $eai->eaiApi($method = "if_user_ent001_snd",$params = array("INTEG_ID"=>$v,"INTEG_GUBN"=>"PC"));
		//$result = $eai->eaiApi($method = "if_user_ent001_snd",$params = array("INTEG_ID"=>$v,"INTEG_GUBN"=>"PM"));
	}

}



if(false){

	$update_arr = array(
			'ahnsorin12'
	);

	$cnt = 0;
	foreach($update_arr as $v){
		$result = $eai->eaiApi($method = "if_self_ent002_snd",$params = array("INTEG_ID"=>$v));
	}

}




if(false){

	$update_arr = array(
			'wlswo4182',
'wjstjdud77',
'seunggi1533',
'psm916',
'phj200',
'jiyongp',
'jhqmuni',
'hc980507',
'gpals98',
'dm1998',
'dltngks7408',
'dldhks789456',
'dl22guddk',
'dhtjrdud925',
'clsh59',
'beaksumin',
'annie0320',
'4355alfud'
			
	);

	$cnt = 0;
	foreach($update_arr as $v){
		$result = $eai->eaiApi($method = "if_common_ent002_snd",$params = array("INTEG_ID"=>$v));
	}

}





