<?
header("Content-Type: application/json;charset=utf-8");

require_once($_SERVER['DOCUMENT_ROOT']."/eai/conf/config.inc");



	$oci = connectKcasidsDB();

	$ku = new KcasUser($oci);
	//$ku->debug = true;
	//$search_cond->NAME			= iconv('EUC-KR', 'UTF-8', '�׽�ƮX');	//NAME
	//$search_cond->BRDY_YYMMDD	= '19800414';		//BRDY_YYMMDD
	//$search_cond->CRAL_TEL		= '010-1111-1111';	//CRAL_TEL
	$sh = array();
	$sh['NAME'] = "�׽�Ʈx";
	$sh['BRDY_YYMMDD'] = '19800414';
	$sh['CRAL_TEL'] = '010-1111-1111';
	$rows = $ku->pull($sh);
	
	$resdata['data'] = $rows;
	
	$resdata['data'] = ms949ToUtf8($resdata['data']);
	
	print_r($resdata['data']);
	
	
	
	die();


	class SEARCH_RSLT {
		public $INTEG_ID; // string
		public $CMF_UID; // string
		public $PERS_US_AGRM_YN; // string
		public $UNIQ_US_AGRM_YN; // string
		public $PERS_CONS_AGRM_YN; // string
		public $PERS_THREE_AGRM_YN; // string
		public $VLTN_GDNC_AGRM_YN; // string
		
	}
	
	
	
	$search_rslt	= new SEARCH_RSLT();
	
	$oci = connectKcasDB();
	$ka = new KcasApply($oci);
	
	$sh = array();
	$sh['INTEG_ID'] = "xTEST01";
	$sh['CMF_UID'] = "knbgv3joJYInl8nqAJK134Nf8wGBGePHXY3CtXBl5hg=";
	$rows = $ka->pull($sh);
	$row = $rows[0];
	
	print_r($row);
	
	print_r(array_keys(get_object_vars($search_rslt)));
	
	foreach(array_keys(get_object_vars($search_rslt)) as $v){
		echo $v;
		if(!empty($row[$v])){
			$search_rslt->{$v} = $row[$v];
		} else {
			$search_rslt->{$v} = "";
		}
	}
	
	
	
	$oci = connectKcasDB();
	$ks = new KcasSelfintroduction($oci);
	
	$sh = array();
	$sh['INTEG_ID'] = $search_rslt->INTEG_ID;
	
	$rows = $ks->pull($sh);
	$row = $rows[0];
	
	print_r($row);
?>