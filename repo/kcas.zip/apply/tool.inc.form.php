<!-- ==================================================================================================== -->
	<!-- ������ ����� FORM -->
	<form id="frm" name="frm" method="post" action="?">
		<input type="hidden" name='CMN_APLC_SNO' id='CMN_APLC_SNO' size="10" value="<?=$CMN_APLC_SNO?>"/>
		<input type="hidden" name="HASH_KEY" id="HASH_KEY" />
		<input type="hidden" name="CMF_UID" id="CMF_UID" />
		<input type="hidden" name="PERS_US_AGRM_YN" id="PERS_US_AGRM_YN" />
		<input type="hidden" name="UNIQ_US_AGRM_YN" id="UNIQ_US_AGRM_YN" />
		<input type="hidden" name="PERS_CONS_AGRM_YN" id="PERS_CONS_AGRM_YN" />
		<input type="hidden" name="PERS_THREE_AGRM_YN" id="PERS_THREE_AGRM_YN" />
		<input type="hidden" name="VLTN_GDNC_AGRM_YN" id="VLTN_GDNC_AGRM_YN" />
		<input type="hidden" name="ONSL_QLFC_DT_AGRM_YN" id="ONSL_QLFC_DT_AGRM_YN" />
		<input type="hidden" name="FLSH_QLFC_PVNT_AGRM_YN" id="FLSH_QLFC_PVNT_AGRM_YN" />
		<input type="hidden" name="NM" id="NM" />
		<input type="hidden" name="LNM" id="LNM" />
		<input type="hidden" name="FNM" id="FNM" />
		<input type="hidden" name="MMBR_CD" id="MMBR_CD" />
		<input type="hidden" name="RRNO" id="RRNO" />
		<input type="hidden" name="GNDR" id="GNDR" />
		<input type="hidden" name="BRDY" id="BRDY" />
		<input type="hidden" name="PERS_ID" id="PERS_ID" />
		<input type="hidden" name="CNTY_CD" id="CNTY_CD" />
		<input type="hidden" name="NAT" id="NAT" />
		<input type="hidden" name="BSIS_ZONE" id="BSIS_ZONE" />
		<input type="hidden" name="ADD_SEQ" id="ADD_SEQ" />
		<input type="hidden" name="PSNO" id="PSNO" />
		<input type="hidden" name="DTL_ADD" id="DTL_ADD" />
		<input type="hidden" name="ROAD_ADD_BLDG_NO" id="ROAD_ADD_BLDG_NO" />
		<input type="hidden" name="ROAD_DTL_ADD" id="ROAD_DTL_ADD" />
		<input type="hidden" name="DONGCODE" id="DONGCODE" />
		<input type="hidden" name="SIDO" id="SIDO" />
		<input type="hidden" name="SIGUNGU" id="SIGUNGU" />
		<input type="hidden" name="DONG" id="DONG" />
		<input type="hidden" name="RI" id="RI" />
		<input type="hidden" name="ISMOUNTAIN" id="ISMOUNTAIN" />
		<input type="hidden" name="JIBUN1" id="JIBUN1" />
		<input type="hidden" name="JIBUN2" id="JIBUN2" />
		<input type="hidden" name="STREETCODE" id="STREETCODE" />
		<input type="hidden" name="STREET" id="STREET" />
		<input type="hidden" name="ISUNDER" id="ISUNDER" />
		<input type="hidden" name="BUILDINGNUM1" id="BUILDINGNUM1" />
		<input type="hidden" name="BUILDINGNUM2" id="BUILDINGNUM2" />
		<input type="hidden" name="BUILDING" id="BUILDING" />
		<input type="hidden" name="BUILDINGDETAIL" id="BUILDINGDETAIL" />
		<input type="hidden" name="BUILDINGCODE" id="BUILDINGCODE" />
		<input type="hidden" name="DONGSEQ" id="DONGSEQ" />
		<input type="hidden" name="HANGDONGCODE" id="HANGDONGCODE" />
		<input type="hidden" name="HANGDONG" id="HANGDONG" />
		<input type="hidden" name="ZIPSEQ" id="ZIPSEQ" />
		<input type="hidden" name="MASSDESTINATION" id="MASSDESTINATION" />
		<input type="hidden" name="MODEREASONCODE" id="MODEREASONCODE" />
		<input type="hidden" name="CHANGEDATE" id="CHANGEDATE" />
		<input type="hidden" name="OLDSTREET" id="OLDSTREET" />
		<input type="hidden" name="SIGUNGUBUILDING" id="SIGUNGUBUILDING" />
		<input type="hidden" name="ISAPARTMENT" id="ISAPARTMENT" />
		<input type="hidden" name="CRAL_TEL" id="CRAL_TEL" />
		<input type="hidden" name="TEL_ANO" id="TEL_ANO" />
		<input type="hidden" name="TEL1" id="TEL1" />
		<input type="hidden" name="TEL2" id="TEL2" />
		<input type="hidden" name="EMAIL" id="EMAIL" />
		<input type="hidden" name="ADIT1_TEL_ANO" id="ADIT1_TEL_ANO" />
		<input type="hidden" name="ADIT1_TEL1" id="ADIT1_TEL1" />
		<input type="hidden" name="ADIT1_TEL2" id="ADIT1_TEL2" />
		<input type="hidden" name="ADIT2_TEL_ANO" id="ADIT2_TEL_ANO" />
		<input type="hidden" name="ADIT2_TEL1" id="ADIT2_TEL1" />
		<input type="hidden" name="ADIT2_TEL2" id="ADIT2_TEL2" />
		<input type="hidden" name="ADIT3_TEL_ANO" id="ADIT3_TEL_ANO" />
		<input type="hidden" name="ADIT3_TEL1" id="ADIT3_TEL1" />
		<input type="hidden" name="ADIT3_TEL2" id="ADIT3_TEL2" />
		<input type="hidden" name="ADIT4_TEL_ANO" id="ADIT4_TEL_ANO" />
		<input type="hidden" name="ADIT4_TEL1" id="ADIT4_TEL1" />
		<input type="hidden" name="ADIT4_TEL2" id="ADIT4_TEL2" />
		<input type="hidden" name="ADIT5_TEL_ANO" id="ADIT5_TEL_ANO" />
		<input type="hidden" name="ADIT5_TEL1" id="ADIT5_TEL1" />
		<input type="hidden" name="ADIT5_TEL2" id="ADIT5_TEL2" />
		<input type="hidden" name="FRGN_CNTY_NO" id="FRGN_CNTY_NO" />
		<input type="hidden" name="FRGN_TEL" id="FRGN_TEL" />
		<input type="hidden" name="FRGN_ADIT1_CNTY_NO" id="FRGN_ADIT1_CNTY_NO" />
		<input type="hidden" name="FRGN_ADIT1_TEL" id="FRGN_ADIT1_TEL" />
		<input type="hidden" name="FRGN_ADIT2_CNTY_NO" id="FRGN_ADIT2_CNTY_NO" />
		<input type="hidden" name="FRGN_ADIT2_TEL" id="FRGN_ADIT2_TEL" />
		<input type="hidden" name="FRGN_ADIT3_CNTY_NO" id="FRGN_ADIT3_CNTY_NO" />
		<input type="hidden" name="FRGN_ADIT3_TEL" id="FRGN_ADIT3_TEL" />
		<input type="hidden" name="FRGN_ADIT4_CNTY_NO" id="FRGN_ADIT4_CNTY_NO" />
		<input type="hidden" name="FRGN_ADIT4_TEL" id="FRGN_ADIT4_TEL" />
		<input type="hidden" name="FRGN_ADIT5_CNTY_NO" id="FRGN_ADIT5_CNTY_NO" />
		<input type="hidden" name="FRGN_ADIT5_TEL" id="FRGN_ADIT5_TEL" />
		<input type="hidden" name="LAST_ACAR_CD" id="LAST_ACAR_CD" />
		<input type="hidden" name="LAST_ACAR_NM" id="LAST_ACAR_NM" />
		<input type="hidden" name="HGSC_CD" id="HGSC_CD" />
		<input type="hidden" name="HGSC_NM" id="HGSC_NM" />
		<input type="hidden" name="HGSC_CS_CD" id="HGSC_CS_CD" />
		<input type="hidden" name="HGSC_CS_NM" id="HGSC_CS_NM" />
		<input type="hidden" name="HGSC_LCTP_CD" id="HGSC_LCTP_CD" />
		<input type="hidden" name="HGSC_LCTP_NM" id="HGSC_LCTP_NM" />
		<input type="hidden" name="HGSC_TEL_ANO" id="HGSC_TEL_ANO" />
		<input type="hidden" name="HGSC_TEL1" id="HGSC_TEL1" />
		<input type="hidden" name="HGSC_TEL2" id="HGSC_TEL2" />
		<input type="hidden" name="HGSC_FAX_ANO" id="HGSC_FAX_ANO" />
		<input type="hidden" name="HGSC_FAX1" id="HGSC_FAX1" />
		<input type="hidden" name="HGSC_FAX2" id="HGSC_FAX2" />
		<input type="hidden" name="HGSC_PSNO" id="HGSC_PSNO" />
		<input type="hidden" name="HGSC_ADD" id="HGSC_ADD" />
		<input type="hidden" name="HGSC_TP_CD" id="HGSC_TP_CD" />
		<input type="hidden" name="HGSC_TP_NM" id="HGSC_TP_NM" />
		<input type="hidden" name="GRDT_PRNG_YY" id="GRDT_PRNG_YY" />
		<input type="hidden" name="GRDT_PRNG_MCNT" id="GRDT_PRNG_MCNT" />
		<input type="hidden" name="GED_PSXA_AREA_CD" id="GED_PSXA_AREA_CD" />
		<input type="hidden" name="GED_PSXA_AREA_NM" id="GED_PSXA_AREA_NM" />
		<input type="hidden" name="GED_PSXA_YY" id="GED_PSXA_YY" />
		<input type="hidden" name="GED_PSXA_MCNT" id="GED_PSXA_MCNT" />
		<input type="hidden" name="GED_PSXA_DD" id="GED_PSXA_DD" />
		<input type="hidden" name="GED_ONLN_OFR_AGRM_YN" id="GED_ONLN_OFR_AGRM_YN" />
		<input type="hidden" name="GED_OFR_AGRM_CFRM_NO" id="GED_OFR_AGRM_CFRM_NO" />
		<input type="hidden" name="PRPORT_RFND_MTHD" id="PRPORT_RFND_MTHD" />
		<input type="hidden" name="BNK_CD" id="BNK_CD" />
		<input type="hidden" name="BNK_NM" id="BNK_NM" />
		<input type="hidden" name="ACHL" id="ACHL" />
		<input type="hidden" name="ACNO" id="ACNO" />

		<!-- uway �߰� -->
		<input type="hidden" name='mode' size="10" value="<?=htmlspecialchars($mode)?>"/>
		<!-- //uway �߰� -->


	</form>
	<!-- //������ ����� FORM -->
	<div style=";">
		<!-- ������� IFRAME (CSS ���� �ʿ�) -->
		<div style="border:5px solid red; width:933px">
			
			<iframe frameborder='0' scrolling='auto'  name='view' id='view'></iframe>
		</div>
		<!-- //������� IFRAME -->
	</div>