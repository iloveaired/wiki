function uway_lib_init(){ 
	var input_POPUP_YN = document.getElementById('POPUP_YN');
	if(input_POPUP_YN){
		//-- POPUP_YN 자동처리. 넘겨주는게 바보 같아서 이걸 만든다.
		var POPUP_YN = 'N';
		if(window.opener){
			POPUP_YN = 'Y'
		}
		
		input_POPUP_YN.defaultValue = POPUP_YN;
		input_POPUP_YN.value = POPUP_YN;
	}

}


function uway_lib_kfn_setBaseKey(ctrl){ 
	if(window.opener && window.opener.kfn_setBaseKey){ //소스에 예외처리가 없어서 이걸 만든다.
		window.opener.kfn_setBaseKey(ctrl);
		return true;
	}else{
		console?console.log('ERROR : uway_ctrl_kfn_setBaseKey()'):alert('ERROR : uway_ctrl_kfn_setBaseKey()');
		return false;
	}
}


//--- 자동실행용
$(
	function(){
		uway_lib_init();
	}
);