<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
	<script type="text/javascript" src="/kcuenexa/SettingForClient/CQWebCommon.js"></script>
	<script type="text/javascript" src="/kcuenexa/js/kcueUtil.js"></script>
	<script>
		cqFn_setBrowser()
		var r = cfn_clearKey(); //������� ��� Ű�� ����
		alert('Ű Ŭ����');
		if(document.referrer.length>0){
			document.location.replace(document.referrer);
		}
	</script>
</head>
<body>

</body>
</html>