<?
header('Content-Type: text/html;charset=utf-8');

require_once('inc.conf.php');

// IP접근 가능여부 확인
$ip = isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'';
$allowd = checkAllowIp($_conf['apply_pp']['allowIpList'],$ip);

if(!$allowd){
	exit('Not Allow IP. [YOUR IP : '.$ip.']');
}


$fields = array('INTEG_ID' => 1, //아이디
			'CMF_UID' => 0, //CMF_UID
			
			'PERS_US_AGRM_YN' => 0, //개인정보 수집 및 이용에 대한 동의
			'UNIQ_US_AGRM_YN' => 0, //고유식별정보 수집 및 이용에 한 동의
			'PERS_CONS_AGRM_YN' => 0, //개인정보 취급 위탁에 대한 동의
			'PERS_THREE_AGRM_YN' => 0, //개인정보 제3자 제공에 대한 동의
			'VLTN_GDNC_AGRM_YN' => 0, //대입 지원 위반 안내 확인 동의
			'ONSL_QLFC_DT_AGRM_YN' => 0, //본인 확인 및 지원 자격, 전형일자 확인 동의
			'FLSH_QLFC_PVNT_AGRM_YN' => 0, //대입 허위지원 방지와 지원 자격 조작 방지에 관한 확인 동의

			'NM' => 0, //이름
			'LNM' => 0, //이름-영문성
			'FNM' => 0, //이름-영문이름
			'MMBR_CD' => 0, //구분
			'RRNO' => 0, //주민등록번호
			'GNDR' => 0, //성별
			'BRDY' => 0, //생년월일
			'PERS_ID' => 0, //개인고유식별정보
			'CNTY_CD' => 0, //국가코드
			'NAT' => 0, //국적
			'BSIS_ZONE' => 0, //기초구역번호
			'ADD_SEQ' => 0, //주소일련번호(지번)
			'PSNO' => 0, //우편번호
			'DTL_ADD' => 0, //주소
			'ROAD_ADD_BLDG_NO' => 0, //도로명주소건물번호
			'ROAD_DTL_ADD' => 0, //도로명주소상세주소
			'DONGCODE' => 0, //법정동코드[10자리]
			'SIDO' => 0, //시도
			'SIGUNGU' => 0, //시군구
			'DONG' => 0, //법정읍면동명
			'RI' => 0, //법정리명
			'ISMOUNTAIN' => 0, //산여부
			'JIBUN1' => 0, //관련지번본번
			'JIBUN2' => 0, //관련지번부번
			'STREETCODE' => 0, //도로명코드
			'STREET' => 0, //도로명
			'ISUNDER' => 0, //지하여부
			'BUILDINGNUM1' => 0, //건물본번
			'BUILDINGNUM2' => 0, //건물부번
			'BUILDING' => 0, //건축물대장 건물명
			'BUILDINGDETAIL' => 0, //상세건물명
			'BUILDINGCODE' => 0, //건물관리번호
			'DONGSEQ' => 0, //읍면동일련번호
			'HANGDONGCODE' => 0, //행정동코드
			'HANGDONG' => 0, //행정동명
			'ZIPSEQ' => 0, //우편일련번호
			'MASSDESTINATION' => 0, //다량배달처명
			'MODEREASONCODE' => 0, //이동사유코드
			'CHANGEDATE' => 0, //변경일자
			'OLDSTREET' => 0, //변경전도로명주소
			'SIGUNGUBUILDING' => 0, //시군구용 건물명(참고용)
			'ISAPARTMENT' => 0, //공동주택여부
			'CRAL_TEL' => 0, //지원자 휴대전화
			'TEL_ANO' => 0, //집전화번호 국번
			'TEL1' => 0, //집전화번호1
			'TEL2' => 0, //집전화번호2
			'EMAIL' => 0, //지원자 이메일
			'ADIT1_TEL_ANO' => 0, //추가 전화번호(1) 국번
			'ADIT1_TEL1' => 0, //추가 전화번호(1) 1
			'ADIT1_TEL2' => 0, //추가 전화번호(1) 2
			'ADIT2_TEL_ANO' => 0, //추가 전화번호(2) 국번
			'ADIT2_TEL1' => 0, //추가 전화번호(2) 1
			'ADIT2_TEL2' => 0, //추가 전화번호(2) 2
			'ADIT3_TEL_ANO' => 0, //추가 전화번호(3) 국번
			'ADIT3_TEL1' => 0, //추가 전화번호(3) 1
			'ADIT3_TEL2' => 0, //추가 전화번호(3) 2
			'ADIT4_TEL_ANO' => 0, //추가 전화번호(4) 국번
			'ADIT4_TEL1' => 0, //추가 전화번호(4) 1
			'ADIT4_TEL2' => 0, //추가 전화번호(4) 2
			'ADIT5_TEL_ANO' => 0, //추가 전화번호(5) 국번
			'ADIT5_TEL1' => 0, //추가 전화번호(5) 1
			'ADIT5_TEL2' => 0, //추가 전화번호(5) 2
			'FRGN_ADD' => 0, //외국인 집주소
			'FRGN_TEL' => 0, //외국인 집전화번호
			'FRGN_ADIT1_TEL' => 0, //외국인 추가 전화번호(1)
			'FRGN_ADIT2_TEL' => 0, //외국인 추가 전화번호(2)
			'FRGN_ADIT3_TEL' => 0, //외국인 추가 국가번호(3)
			'FRGN_ADIT4_TEL' => 0, //외국인 추가 전화번호(4)
			'FRGN_ADIT5_TEL' => 0, //외국인 추가 전화번호(5)
			'LAST_ACAR_CD' => 0, //최종학력구분
			'LAST_ACAR_NM' => 0, //최종학력구분명
			'HGSC_CD' => 0, //재학/출신고교코드
			'HGSC_NM' => 0, //재학/출신고교명
			'HGSC_CS_CD' => 0, //CS코드
			'HGSC_CS_NM' => 0, //이전고교명
			'HGSC_LCTP_CD' => 0, //고교소재지코드
			'HGSC_LCTP_NM' => 0, //고교소재지명
			'HGSC_TEL_ANO' => 0, //고교 대표 전화번호 국번
			'HGSC_TEL1' => 0, //고교 대표 전화번호 1
			'HGSC_TEL2' => 0, //고교 대표 전화번호 2
			'HGSC_FAX_ANO' => 0, //고교 대표 FAX번호 국번
			'HGSC_FAX1' => 0, //고교 대표 FAX번호 1
			'HGSC_FAX2' => 0, //고교 대표 FAX번호 2
			'HGSC_PSNO' => 0, //고교우편번호
			'HGSC_ADD' => 0, //고교주소
			'HGSC_TP_CD' => 0, //고교유형
			'HGSC_TP_NM' => 0, //고교유형명
			'GRDT_PRNG_YY' => 0, //졸업(예정년도)
			'GRDT_PRNG_MCNT' => 0, //졸업(예정월)
			'GED_PSXA_AREA_CD' => 0, //검정고시합격지구 코드
			'GED_PSXA_AREA_NM' => 0, //검정고시합격지구 명
			'GED_PSXA_YY' => 0, //검정고시합격(년도)
			'GED_PSXA_MCNT' => 0, //검정고시합격(월)
			'GED_PSXA_DD' => 0, //검정고시합격(일)
			'GED_ONLN_OFR_AGRM_YN' => 0, //검정고시 온라인 제공동의 여부
			'GED_OFR_AGRM_CFRM_NO' => 0, //검정고시 제공동의 확인번호
			'PRPORT_RFND_MTHD' => 0, //전형료 비례환불 방법
			'BNK_CD' => 0, //은행코드
			'BNK_NM' => 0, //은행명
			'ACHL' => 0, //예금주
			'ACNO' => 0, //계좌번호
			'FRGN_NO_YN' => 0, //외국인등록번호유무
			'RRNO_UPDATE_YN' => 0,//주민등록수정 가능 여부-콜센터 주민드록수정 가능 여부 업데이트 용
			'ONLN_OFR_SYS_IST'=>0, //온라인제공시스템설치
);




?><!doctype html>
<html lang="ko">
<head>
<title>test.apply.pushpull.html</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script>
function getJsonString(){
	var f = document.formData;
	var els = f.elements;
	var obj = {};
	for(var i=0,m=els.length;i<m;i++){
		var el = els[i];
		if(el.value.length<1){continue;}
		obj[el.name] = el.value
	}
	return JSON.stringify(obj);
}


</script>
</head>
<body>
<fieldset>
	<legend>주의</legend>
	<div>
		외부 업체와의 연계용으로 만들었기 때문에, UTF-8기준으로 페이지가 동작해야한다!
	</div>
	<div>
		접속환경 : <?=_IS_DEV_?'개발':'운영'?> (사용 DB는 소스 상태에 따라서 다를 수 있습니다.)
	</div>
</fieldset>
<fieldset>
	<legend>PULL/PUSH</legend>
	<form action="apply_pp.php" method="post" onsubmit="">
		<ul>
			<li><label><input type="submit" value="동작"></label></li>
			<li>mode : 
				<label><input name="mode" type="radio" value="pull" checked="checked">pull</label>
				/
				<label><input name="mode" type="radio" value="push">push</label>
			</li>
			<li><label>datatype : <input name="datatype" type="text" value="json" disabled="disabled"></label>(사용하지말라, 어떻게할지 정해지지 않았음)</li>
			<li><label>charset : <input name="charset" type="text" value="euc-kr" disabled="disabled"></label>(사용하지말라, 어떻게할지 정해지지 않았음)</li>
			<li>data :<textarea name="data" rows="10" cols="10" style="width:500px; height:10em"></textarea></li>
			<li><label><input type="button" value="data Json으로 채우기" onclick="this.form.data.value=getJsonString();"></label></li>
			
		</ul>
	</form>
</fieldset>
<fieldset>
	<legend>DATA FIELDS</legend>
	<form name="formData">
		<ul>
		<? foreach($fields  as $k=>$v){?>
			<li><label><?=$v>0?'*':''?> <?=htmlspecialchars($k)?> : <input name="<?=htmlspecialchars($k)?>" type="text" value="" ></label></li>
		<? } ?>
		</ul>
	</form>
</fieldset>
</body>
</html>