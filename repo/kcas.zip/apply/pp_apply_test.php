<?
header("Content-Type: application/json;charset=utf-8");

require_once('inc.conf.php');
require_once(_SITE_ROOT_.'/lib/class.KcasApply.php');




// IP���� ���ɿ��� Ȯ��
$ip = isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'';
$allowd = checkAllowIp($_conf['apply_pp']['allowIpList'],$ip);

$mode = isset($_REQUEST['mode'][0])?$_REQUEST['mode']:'';
$data = isset($_POST['data'][0])?$_POST['data']:'{}'; //JSON String
if(get_magic_quotes_gpc()){
	$decdata = json_decode(stripslashes($data),true); //�ѱ۵ \�� ���� �� �־ ���� ������. ���� ����.
}else{
	$decdata = json_decode($data,true);
}
$decdata = utf8ToMs949($decdata); //convert utf-8 => ms949

$decdata_log = $decdata;


foreach($decdata_log as $k=>$v){
	if(strlen($v) > 100){
		$decdata_log[$k] = substr($v,0,100)."...";
	}
}



//== ����� ������
$resdata = array();
$resdata['mode'] = $mode;
$resdata['data'] = null;
$resdata['error'] = null;

if(!$allowd){
	$resdata['error'] = 'Not Allow IP. [YOUR IP : '.$ip.']';
}else{
	$oci = connectDB();

	$ka = new KcasApply($oci);



	//var_dump($data);
	//var_dump($decdata);
	//echo json_last_error();
	//$decdata['CMF_UID']="text";


	switch($mode){
		case 'pull':
			$rows = $ka->pull($decdata);
			if($rows === false){
				$resdata['error'] = $ka->error;
				$loglevel = 'ERROR';
			}else{
				$loglevel = 'INFO';
			}
			$resdata['data'] = $rows;
			
			log_message( $loglevel, array(
			'title' => 'KCAS_APPLY SYNC PULL',
			'log_line' => __LINE__,
			'msg' => 'PULL',
			'idx1' => $decdata['INTEG_ID'],
			//'post' =>  file_get_contents('php://input'),
			'decdata_log' => serialize( $decdata_log )
			//'resdata' => serialize( $resdata )
			) );

			break;
		case 'push':
			
			//CMF_UID���� ��������� ����� �ʴ´�.
			if(empty($decdata['CMF_UID'])){
				unset($decdata['CMF_UID']);
			}
			
			$r = $ka->push($decdata);
			if($r === false){
				$resdata['error'] = $ka->error;
				$loglevel = 'ERROR';
			}else{
				$loglevel = 'INFO';
			}
			$resdata['data'] = $r;

			log_message( $loglevel , array(
			'title' => 'KCAS_APPLY SYNC PUSH',
			'log_line' => __LINE__,
			'msg' => 'PUSH',
			'idx1' => $decdata['INTEG_ID'],
			//'post' =>  file_get_contents('php://input'),
			'decdata_log' => serialize( $decdata_log )
			//'resdata' => serialize( $resdata )
			) );

			break;
		default:
			$resdata['error'] = '�߸��� mode';

			$loglevel = 'ERROR';
			log_message( $loglevel , array(
			'title' => 'KCAS_APPLY SYNC PUSH',
			'log_line' => __LINE__,
			'msg' => 'PUSH',
			'idx1' => $decdata['INTEG_ID'],
			'post' =>  file_get_contents('php://input'),
			'decdata_log' => serialize( $decdata_log )
			//'resdata' => serialize( $resdata )
			) );

			break;
	}
	
	//echo memory_get_usage().'<br>';
	$oci->disconnect();
	//$oci->free();
	//echo memory_get_usage().'<br>';
}
//���� ������� ����ص� ����� ������, PHP 5.2.x���� json_encode�� ����ϸ� �ѱ��� \ud55c\uae00 ó�� ��ȯ�Ǽ� ���´�. array2json�� �ѱ۷� �ٷ� ����.
echo json_encode(ms949ToUtf8($resdata));
//echo array2json(ms949ToUtf8($resdata));


?>