<?
header('Content-Type: text/html;charset=utf-8');

require_once('inc.conf.php');

// IP접근 가능여부 확인
$ip = isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'';
$allowd = checkAllowIp($_conf['apply_pp']['allowIpList'],$ip);

if(!$allowd){
	exit('Not Allow IP. [YOUR IP : '.$ip.']');
}

?><!doctype html>
<html lang="ko">
<head>
<title>test.apply.pushpull.html</title>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<script>
function getJsonString(){
	var f = document.formData;
	var els = f.elements;
	var obj = {};
	for(var i=0,m=els.length;i<m;i++){
		var el = els[i];
		if(el.value.length<1){continue;}
		obj[el.name] = el.value
	}
	return JSON.stringify(obj);
}


</script>
</head>
<body>
<fieldset>
	<legend>주의</legend>
	<div>
		외부 업체와의 연계용으로 만들었기 때문에, UTF-8기준으로 페이지가 동작해야한다!
	</div>
	<div>
		접속환경 : <?=_IS_DEV_?'개발':'운영'?> (사용 DB는 소스 상태에 따라서 다를 수 있습니다.)
	</div>
</fieldset>
<fieldset>
	<legend>PULL/PUSH</legend>
	<form action="selfintro_pp.php" method="post" onsubmit="">
		<ul>
			<li><label><input type="submit" value="동작"></label></li>
			<li>mode : 
				<label><input name="mode" type="radio" value="pull" checked="checked">pull</label>
				/
				<label><input name="mode" type="radio" value="push">push</label>
			</li>
			<li><label>datatype : <input name="datatype" type="text" value="json" disabled="disabled"></label>(사용하지말라, 어떻게할지 정해지지 않았음)</li>
			<li><label>charset : <input name="charset" type="text" value="euc-kr" disabled="disabled"></label>(사용하지말라, 어떻게할지 정해지지 않았음)</li>
			<li>data :<textarea name="data" rows="10" cols="10" style="width:500px; height:10em"></textarea></li>
			<li><label><input type="button" value="data Json으로 채우기" onclick="this.form.data.value=getJsonString();"></label></li>
			
		</ul>
	</form>
</fieldset>
<fieldset>
	<legend>DATA FIELDS</legend>
	<form name="formData">
		<ul>
			<li><label>* UID (CMF_UID) : <input name="CMF_UID" type="text" value="" ></label></li>
			<li><label>대학코드 (UNVR_CD) : <input name="UNVR_CD" type="text" value="" ></label></li>
			<li><label>고유식별정보 수집 및 이용에 한 동의 (UNIQ_US_AGRM_YN) : <input name="UNIQ_US_AGRM_YN" type="text" value="" ></label></li>
			<li><label>작성시간 (WRT_HR) : <input name="WRT_HR" type="text" value="" ></label></li>
			<li><label>작성시 유의사항 안내서 (WRT_ATENT_GDBK) : <input name="WRT_ATENT_GDBK" type="text" value="" ></label></li>
			<li><label>대입 지원 위반 안내 확인 동의 (WRT_ATENT_AGRM_YN) : <input name="WRT_ATENT_AGRM_YN" type="text" value="" ></label></li>
			<li><label>공통문항1 답변 (QESITM1_ASWR) : <input name="QESITM1_ASWR" type="text" value="" ></label></li>
			<li><label>공통문항2 답변 (QESITM2_ASWR) : <input name="QESITM2_ASWR" type="text" value="" ></label></li>
			<li><label>공통문항3 답변 (QESITM3_ASWR) : <input name="QESITM3_ASWR" type="text" value="" ></label></li>
			<li><label>대학별 유의사항 안내서 (UNVR_ATENT_GDBK) : <input name="UNVR_ATENT_GDBK" type="text" value="" ></label></li>
			<li><label>대학별 자율문항 (UNVR_QESITM) : <input name="UNVR_QESITM" type="text" value="" ></label></li>
			<li><label>대학별 자율문항 답변 (UNVR_QESITM_ASWR) : <input name="UNVR_QESITM_ASWR" type="text" value="" ></label></li>
			<li><label>자율문항 여부 (UNVR_QESITM_YN) : <input name="UNVR_QESITM_YN" type="text" value="" ></label></li>
			<li><label>공통문항1입력글자수 (QESITM1_INP_NOLT) : <input name="QESITM1_INP_NOLT" type="text" value="" ></label></li>
			<li><label>공통문항2입력글자수 (QESITM2_INP_NOLT) : <input name="QESITM2_INP_NOLT" type="text" value="" ></label></li>
			<li><label>공통문항3입력글자수 (QESITM3_INP_NOLT) : <input name="QESITM3_INP_NOLT" type="text" value="" ></label></li>
			<li><label>대학별 자율문항입력글자수 (UNVR_QESITM_INP_NOLT) : <input name="UNVR_QESITM_INP_NOLT" type="text" value="" ></label></li>		
		</ul>
	</form>
</fieldset>
</body>
</html>