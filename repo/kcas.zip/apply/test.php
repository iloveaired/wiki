<?
//echo utf8_decode('%uAD8C');
echo json_decode('\\uAD8C');

$a = "\\uAD8C";
$x =  json_decode($a);
var_dump($x);
?>