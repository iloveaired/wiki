<!-- ==================================================================================================== -->

	<!-- ������� IFRAME (CSS ���� �ʿ�) -->
	<div style="border:5px solid red;">
		
	<iframe frameborder='1' scrolling='auto'  name='view' id='view'></iframe>
	</div>
	<!-- //������� IFRAME (CSS ���� �ʿ�) -->

	<!-- ������ ����� FORM -->
	<form id="frm" name="frm" method="post">
		�����������&nbsp;<input type="text" name="CMN_APLC_SNO" id="CMN_APLC_SNO" value="30"/><br>
		CMF_UID&nbsp;<input type="text" name="CMF_UID" id="CMF_UID" value="IBBPsL6aBC771dTeNg0Lg/iATIM="/><br>
		ȸ��&nbsp;<input type="text" name="ID" id="ID" value="sugi11122233"/><br><br>	
		<input type="hidden" name="HASH_KEY" id="HASH_KEY" />
		<input type="hidden" name="SIN_UID" id="SIN_UID" />
		<input type="hidden" name="WRT_HR" id="WRT_HR" />
		<input type="hidden" name="WRT_ATENT_GDBK" id="WRT_ATENT_GDBK" />
		<input type="hidden" name="WRT_ATENT_AGRM_YN" id="WRT_ATENT_AGRM_YN" />
		<input type="hidden" name="QESITM1_ASWR" id="QESITM1_ASWR" />
		<input type="hidden" name="QESITM2_ASWR" id="QESITM2_ASWR" />
		<input type="hidden" name="QESITM3_ASWR" id="QESITM3_ASWR" />
		<input type="hidden" name="UNVR_ATENT_GDBK" id="UNVR_ATENT_GDBK" />
		<input type="hidden" name="UNVR_QESITM" id="UNVR_QESITM" />
		<input type="hidden" name="UNVR_QESITM_ASWR" id="UNVR_QESITM_ASWR" />
		<input type="hidden" name="UNVR_QESITM_NOLT" id="UNVR_QESITM_NOLT" />
		<input type="hidden" name="UNVR_QESITM_YN" id="UNVR_QESITM_YN" />
		<input type="hidden" name="QESITM1_INP_NOLT" id="QESITM1_INP_NOLT" />
		<input type="hidden" name="QESITM2_INP_NOLT" id="QESITM2_INP_NOLT" />
		<input type="hidden" name="QESITM3_INP_NOLT" id="QESITM3_INP_NOLT" />
		<input type="hidden" name="UNVR_QESITM_INP_NOLT" id="UNVR_QESITM_INP_NOLT" />

		<!-- uway �߰� -->
		<!-- <input type="hidden" name='mode' size="10" value="<?=htmlspecialchars($mode)?>"/> -->
		<!-- //uway �߰� -->
	</form>
	<!-- // ������ ����� FORM -->
