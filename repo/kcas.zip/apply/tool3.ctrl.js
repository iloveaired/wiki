
//nexacro���� application.userNotify(1, "msg"); ������ ȣ���ϸ� �Ʒ� �̺�Ʈ�� ȣ���
function notified(obj, e) 
{
	var ctrl = e.message; //��ȸ����
	
    if(e.notifyid == "complete_adl"){ 
		var data = '<'+'?xml version="1.0" encoding="utf-8"?><%=strRsXml%>';
		document.getElementById("doc").value = data;
	}else if(e.notifyid == "complete_mainApp"){ 
		setInitQesitm1trgt();
		setInitQesitm1brkd();
		setInitQesitm2brkd();
		setInitRefer();
	}
}

//������� �������� �ʱⰪ �����ϱ�-�ʱ⿡ �Ѱ��� ������ ����
function setInitRefer()
{
	document.getElementById("frm").reset();
	var cmfXml = fn_json2XmlString($("form").serializeFormJSON());
	$("#doc").val(cmfXml);
	KcueCmn.callFunction("setRefer", cmfXml);
}

function setInitQesitm1trgt()
{
	var data = '<'+'?xml version="1.0" encoding="utf-8" ?>';
	data += '<root>';
	data += '<row><CD><![CDATA[0]]></CD><CD_NM><![CDATA[����]]></CD_NM></row>';
	data += '<row><CD><![CDATA[1]]></CD><CD_NM><![CDATA[3�г���ü]]></CD_NM></row>';
	data += '<row><CD><![CDATA[2]]></CD><CD_NM><![CDATA[�б���ü]]></CD_NM></row>';
	data += '<row><CD><![CDATA[3]]></CD><CD_NM><![CDATA[�迭��ü]]></CD_NM></row>';
	data += '</root>';
	KcueCmn.callFunction("setQesitm1trgt", data, 2, 4);
}

function setInitQesitm1brkd()
{
	var data = '<'+'?xml version="1.0" encoding="utf-8" ?>';
	data += '<root>';
	data += '<row><CD><![CDATA[1]]></CD><CD_NM><![CDATA[�ſ�����]]></CD_NM></row>';
	data += '<row><CD><![CDATA[2]]></CD><CD_NM><![CDATA[�����]]></CD_NM></row>';
	data += '<row><CD><![CDATA[3]]></CD><CD_NM><![CDATA[����]]></CD_NM></row>';
	data += '<row><CD><![CDATA[4]]></CD><CD_NM><![CDATA[����]]></CD_NM></row>';
	data += '<row><CD><![CDATA[5]]></CD><CD_NM><![CDATA[�򰡺Ұ�]]></CD_NM></row>';
	data += '</root>';
	KcueCmn.callFunction("setQesitm1brkd", data, 2, 4);
}

function setInitQesitm2brkd()
{
	var data = '<'+'?xml version="1.0" encoding="utf-8" ?>';
	data += '<root>';
	data += '<row><CD><![CDATA[1]]></CD><CD_NM><![CDATA[�ſ�����]]></CD_NM></row>';
	data += '<row><CD><![CDATA[2]]></CD><CD_NM><![CDATA[�����]]></CD_NM></row>';
	data += '<row><CD><![CDATA[3]]></CD><CD_NM><![CDATA[����]]></CD_NM></row>';
	data += '<row><CD><![CDATA[4]]></CD><CD_NM><![CDATA[����]]></CD_NM></row>';
	data += '<row><CD><![CDATA[5]]></CD><CD_NM><![CDATA[�򰡺Ұ�]]></CD_NM></row>';
	data += '</root>';
	KcueCmn.callFunction("setQesitm2brkd", data, 2, 4);
}
  
//������� �������� �� �����ϱ�
function setRefer()
{

	var data = document.getElementById("doc").value;
	
	KcueCmn.callFunction("setRefer", data);
}
  
// nexacro ������ �ε�
function fn_onload() 
{
	var conf = {width:'930', height:'970', iframeid:'view',iframeSrc:'/kcuenexa/KcueStdCmmFrmNexa/scfTreEidtEach.html', usernotify:notified};
	KcueCmn.init(conf);

	if(KcueCmn.resultCode == "error") alert(KcueCmn.message);
	
	//��ư Ȱ��ȭ
	$('#btnSave').bind('click', btnSave_click);
	$('#btnSearch').bind('click', btnSearch_click);
	//$('#btnInit').bind('click', btnInit_click);	 //�Լ��� ����.

	window.history.forward(0);
	
	
	
	
}

//��ȸ
function btnSearch_click(){
	$.post("/scf/treEidtEach/view.do",$("form").serialize(),function(data){	 
		if(data.resultVO.resultCode == "SUCCESS"){
			var strXml = fn_json2XmlString(data.result);
			$("#doc").val(strXml);
			setRefer();
		}else{
			alert(data.resultVO.resultMessage);
		}
	}, "json");
}

//����� ���������� ����
function btnSave_click(){
	var strTreInfo = KcueCmn.callFunction("getRefer");
	
	if(strTreInfo != false){
		makeInsertData(strTreInfo);
		
		$.post("/scf/treEidtEach/save.do",$("#frm").serialize(),function(data){	 
			if(data.resultVO.resultCode == "SUCCESS"){
				var strXml = fn_json2XmlString(data.result);
				$("#doc").val(strXml);
				alert("����Ǿ����ϴ�.");
				//btnSearch_click();
			}else{
				alert(data.resultVO.resultMessage);
			}
		}, "json");
	}
}

function makeInsertData(strTreInfo){

	 document.getElementById("doc").value = strTreInfo;
	 var objJson = fn_Xml2Json(fn_makeXml(strTreInfo));

	 $("#UNV_TREC_SNO").val(objJson[0].UNV_TREC_SNO);
	 $("#ID").val(objJson[0].ID);
	 $("#TRE_UID").val(objJson[0].TRE_UID);
	 $("#CMF_UID").val(objJson[0].CMF_UID);
	 $("#UNVR_CD").val(objJson[0].UNVR_CD);
	 $("#WRT_HR").val(objJson[0].WRT_HR);
	 $("#UNVR_ATENT_GDBK").val(objJson[0].UNVR_ATENT_GDBK);
	 $("#RCOG_ATENT_GDBK").val(objJson[0].RCOG_ATENT_GDBK);
	 $("#RCOG_ATENT_AGRM_YN").val(objJson[0].RCOG_ATENT_AGRM_YN);
	 $("#UNVR_NM").val(objJson[0].UNVR_NM);
	 $("#UNVR_DEPA").val(objJson[0].UNVR_DEPA);
	 $("#EXMT_NO").val(objJson[0].EXMT_NO);
	 $("#NM").val(objJson[0].NM);
	 $("#HGSC_CD").val(objJson[0].HGSC_CD);
	 $("#HGSC_NM").val(objJson[0].HGSC_NM);
	 $("#BRDY").val(objJson[0].BRDY);
	 $("#EV_QESITM1_TRGT1").val(objJson[0].EV_QESITM1_TRGT1);
	 $("#EV_QESITM1_BRKD1").val(objJson[0].EV_QESITM1_BRKD1);
	 $("#EV_QESITM1_TRGT2").val(objJson[0].EV_QESITM1_TRGT2);
	 $("#EV_QESITM1_BRKD2").val(objJson[0].EV_QESITM1_BRKD2);
	 $("#EV_QESITM1_TRGT3").val(objJson[0].EV_QESITM1_TRGT3);
	 $("#EV_QESITM1_BRKD3").val(objJson[0].EV_QESITM1_BRKD3);
	 $("#EV_QESITM1_CASE").val(objJson[0].EV_QESITM1_CASE);
	 $("#EV_QESITM2_BRKD1").val(objJson[0].EV_QESITM2_BRKD1);
	 $("#EV_QESITM2_BRKD2").val(objJson[0].EV_QESITM2_BRKD2);
	 $("#EV_QESITM2_BRKD3").val(objJson[0].EV_QESITM2_BRKD3);
	 $("#EV_QESITM2_BRKD4").val(objJson[0].EV_QESITM2_BRKD4);
	 $("#EV_QESITM2_BRKD5").val(objJson[0].EV_QESITM2_BRKD5);
	 $("#EV_QESITM2_CASE").val(objJson[0].EV_QESITM2_CASE);
	 $("#EV_QESITM3_CASE").val(objJson[0].EV_QESITM3_CASE);
	 $("#EV1_INP_NOLT").val(objJson[0].EV1_INP_NOLT);
	 $("#EV2_INP_NOLT").val(objJson[0].EV2_INP_NOLT);
	 $("#EV3_INP_NOLT").val(objJson[0].EV3_INP_NOLT);
	 $("#UNVR_CRTI_KEY").val(objJson[0].UNVR_CRTI_KEY);
	 $("#HGSC_CRTI_KEY").val(objJson[0].HGSC_CRTI_KEY);
}

function fn_makeXml(strXml)
{
	var xmlDoc;
	if(! window.DOMParser)
 	{
		xmlDoc = new ActiveXObject("Microsoft.XMLDOM");
		xmlDoc.async = false;
		xmlDoc.loadXML(strXml);
 	}else{
		var parser = new DOMParser();
		xmlDoc = parser.parseFromString(strXml,"text/xml");
 	}
 	return xmlDoc;
}

function fn_json2XmlString(json){
	 var strXml = '<'+'?xml version="1.0" encoding="utf-8" ?><root>';
	 
	 if(json instanceof Array){
		 for(var i = 0; i < json.length; i++){
			 var jsonRow = json[i];
			 strXml += fn_json2MakeRow(jsonRow);
		 }
	 }
	 else if(typeof(json) == "object"){
		 strXml += fn_json2MakeRow(json);
	 }
	 strXml += "</root>";
	 return strXml;
}

function fn_json2MakeRow(json){
	var pros = Object.getOwnPropertyNames(json);
	var strXml = "";
	 if(pros.length > 0){
		 strXml += "<row>";			 
		 for(var i = 0; i < pros.length; i++){
			 strXml += "<" + pros[i] + "><![CDATA[" + eval("json."+pros[i]) + "]]></" + pros[i] + ">";
		 }
		 strXml += "</row>";
	 }
	 
	 return strXml;
}

function fn_getNodes(xmlDoc, tagName)
{
	return xmlDoc.getElementsByTagName(tagName);
}

function fn_Xml2Json(xmlDoc)
{
	//var objs = xmlDoc.getElementsByTagName("row");
	var objs = fn_getNodes(xmlDoc, "row");
	var json = '[';
	for(var i=0; i< objs.length; i++)
	{
		var nObjs = objs[i].childNodes;
		json += '{';
		
		for(var j =0; j < nObjs.length; j++)
		{
			var tagNm = nObjs[j].nodeName;
			var tagValue = nObjs[j].firstChild.nodeValue;
			
			json += '"' + tagNm + '" :"' + tagValue + '"';
			
			if(j < (nObjs.length - 1))
			{
				json += ',';
			}
			
		}
		
		json += '}';
		
		if(i < ( objs.length - 1))
		{
			json += ',';
		}
	}
	
	json += ']';
	
	return eval(json);
}
