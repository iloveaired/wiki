/**
* �����̿��� ����ϴ� �κ�
*/


/**
* ������ȣ �˻� ����
* with Jquery-JSONP
*/
function callJsonp(data,callback){
	//var data = $(f).serialize();
	$.ajax({
	//"url" : "jsonp.data.php", //���� ������
	//"url" : "http://openapidev.uway.com/zipcode/jsonp.data.php", //���߼���
	"url" : "http://openapi.uway.com/zipcode/jsonp.data.php", //�����
	"dataType" : "jsonp",
	"data" : data,
	"jsonp" : "callback",
	"success" : function(d){
		// d.key;
		alert(d);
		zipcodeCallback(d)
	}
	});
}
//== 
function zipcodeCallback(d){
	// d.key = val;
	alert(d);
	//KcueCmn.callFunction("setAdCityDetInfo", data, paging);
}
//== ���� �ּ� �˻���
function zipcodeJibunJsonp(SIDO,SIGUNGU,DONG,RI,JIBUN1,JIBUN2,page){
	var shtype = 'jibun'
	var raw = {};
	raw['shtype']=shtype;
	raw['SIDO']=SIDO;
	raw['SIGUNGU']=SIGUNGU;
	raw['DONG']=DONG;
	raw['RI']=RI;
	raw['JIBUN1']=JIBUN1;
	raw['JIBUN2']=JIBUN2;
	raw['page']=page;
	var data = jQuery.param(raw);
	callJsonp(data)
}
//== ���θ� �ּ� �˻���
function zipcodeJibunJsonp(SIDO,SIGUNGU,STREET,BUILDINGNUM1,BUILDINGNUM2,page){
	var shtype = 'street'
	var raw = {};
	raw['shtype']=shtype;
	raw['SIDO']=SIDO;
	raw['SIGUNGU']=SIGUNGU;
	raw['STREET']=STREET;
	raw['BUILDINGNUM1']=BUILDINGNUM1;
	raw['BUILDINGNUM2']=BUILDINGNUM2;
	raw['page']=page;
	var data = $.param(raw);
	callJsonp(data)
}
