<?
/*
�ڱ�Ұ�������
*/
?>
<!DOCTYPE html>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=euc-kr">
<script type="text/javascript" src="/kcuenexa/js/jquery-1.11.1.min.js"></script>
<script type="text/javascript" src="/kcuenexa/js/kcueCmn.js"></script>
<script type="text/javascript" src="tool3.ctrl.js"></script>


<script>

//====== uway�� �Լ�
window.onload = function(){
	fn_onload(); //�ʼ� iframe �ʱ�ȭ ��
}
/**
* XML�� �����ͼ� �����ش�.
*/
function apply_loadData(cmfXml){
	//$("#doc").val(cmfXml); //������
	//setRgsr();
	KcueCmn.callFunction("setRgsr", cmfXml);
}
/**
* ���� �������� �����͸� form�� ������ submit ��Ų��.
*/
function apply_saveData(){
	var strCmfInfo = KcueCmn.callFunction("getRgsr");
	//alert(strCmfInfo);

	if(strCmfInfo != false){
		makeInsertData(strCmfInfo);
		if(confirm("DB�� �����ұ��?")){
			var frm = document.frm;
			frm.action = '?';
			frm.mode.value = "push";
			frm.submit();
		}

	}
}
/**
* form�� ����� �κ��� �о�鿩�� �����ش�.
*/
function apply_loadForm(){
	alert("DB���� �ε� �� CMF_UID:"+$("#CMF_UID").val());
	if(! $("#CMF_UID").val().length){
		return false;
	}

	var cmfXml = fn_json2XmlString($("#frm").serializeFormJSON());
	apply_loadData(cmfXml);
	return true;
}

/**
* DB���� ���� ���� form�� �ִ´�.(PHP�� ����)
*/
function apply_loadDb(){
	<?
	//-- ������ �����ͷ� �⺻ form�� �����
	if(isset($resdata['data'][0]) && is_array($resdata['data'][0])){
	foreach($resdata['data'][0] as $k=>$v){
		
		?>
			$("#<?=$k?>").val("<?=$v?>"); //<?="{$k}:{$v}"?>;
		<?
	}
	}
	?>
}


</script>

</head>
<body >
	<form id="frm" name="frm" method="post">
		<input type="text" name="UNV_TREC_SNO" id="UNV_TREC_SNO" />
		<input type="text" name="ID" id="ID" />
		<input type="text" name="TRE_UID" id="TRE_UID" />
		<input type="text" name="CMF_UID" id="CMF_UID" />
		<input type="text" name="UNVR_CD" id="UNVR_CD" />
		<input type="text" name="WRT_HR" id="WRT_HR" />
		<input type="text" name="UNVR_ATENT_GDBK" id="UNVR_ATENT_GDBK" />
		<input type="text" name="RCOG_ATENT_GDBK" id="RCOG_ATENT_GDBK" />
		<input type="text" name="RCOG_ATENT_AGRM_YN" id="RCOG_ATENT_AGRM_YN" />
		<input type="text" name="UNVR_NM" id="UNVR_NM" />
		<input type="text" name="UNVR_DEPA" id="UNVR_DEPA" />
		<input type="text" name="EXMT_NO" id="EXMT_NO" />
		<input type="text" name="NM" id="NM" />
		<input type="text" name="HGSC_CD" id="HGSC_CD" />
		<input type="text" name="HGSC_NM" id="HGSC_NM" />
		<input type="text" name="BRDY" id="BRDY" />
		<input type="text" name="EV_QESITM1_TRGT1" id="EV_QESITM1_TRGT1" />
		<input type="text" name="EV_QESITM1_BRKD1" id="EV_QESITM1_BRKD1" />
		<input type="text" name="EV_QESITM1_TRGT2" id="EV_QESITM1_TRGT2" />
		<input type="text" name="EV_QESITM1_BRKD2" id="EV_QESITM1_BRKD2" />
		<input type="text" name="EV_QESITM1_TRGT3" id="EV_QESITM1_TRGT3" />
		<input type="text" name="EV_QESITM1_BRKD3" id="EV_QESITM1_BRKD3" />
		<input type="text" name="EV_QESITM1_CASE"  id="EV_QESITM1_CASE" />
		<input type="text" name="EV_QESITM2_BRKD1" id="EV_QESITM2_BRKD1" />
		<input type="text" name="EV_QESITM2_BRKD2" id="EV_QESITM2_BRKD2" />
		<input type="text" name="EV_QESITM2_BRKD3" id="EV_QESITM2_BRKD3" />
		<input type="text" name="EV_QESITM2_BRKD4" id="EV_QESITM2_BRKD4" />
		<input type="text" name="EV_QESITM2_BRKD5" id="EV_QESITM2_BRKD5" />
		<input type="text" name="EV_QESITM2_CASE"  id="EV_QESITM2_CASE" />
		<input type="text" name="EV_QESITM3_CASE"  id="EV_QESITM3_CASE" />
		<input type="text" name="EV1_INP_NOLT"     id="EV1_INP_NOLT" />
		<input type="text" name="EV2_INP_NOLT"     id="EV2_INP_NOLT" />
		<input type="text" name="EV3_INP_NOLT"     id="EV3_INP_NOLT" />
		<input type="text" name="HGSC_CRTI_KEY"     id="HGSC_CRTI_KEY" />
		<input type="text" name="UNVR_CRTI_KEY"     id="UNVR_CRTI_KEY" />
	</form>
	<div style="float:left;">
		<div style="border:5px solid red;">
			<iframe frameborder='1' scrolling='auto'  name='view' id='view'></iframe>
		</div>
		<div style="width: 700px;text-align: center;">
			<button id="btnInit">�ʱ�ȭ</button><button id="btnSearch">��ȸ</button> <button id="btnSave">����</button>
		</div>
	</div>
	<div style="border:1px solid blue;float:left;">
	����� : <textarea id="doc" rows="20" cols="100" ></textarea>
	</div>
</body>
</html>