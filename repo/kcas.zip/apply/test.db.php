<?
/**
* TEST
*/

require_once('inc.conf.php');
require_once(_SITE_ROOT_.'/lib/class.KcasApply.php');


function resetdata(){
	global $oci;
	$sql = "delete from kcas_apply where CMF_UID LIKE 'xTEST%'";
	$oci->parse($sql);

	/*
	foreach($binds as $k=>$v){
		$oci->->bindByName(':'.$k,$binds[$k]);
	}
	*/
	$r = $oci->exec();
	$oci->commit();
}


$oci = connectDB();



$ka = new KcasApply($oci);
$ka->debug = 1;

resetdata(); //insert�� �ش� �����Ͱ� ������ ������. ������

$row = array();
$row['CMF_UID'] = 'xTEST01';
$row['NM'] = 'NM�ѱ�'.time();
$r = $ka->push($row);
if(!assert($r==1)){
	echo $ka->error;
}

$sh = array();
$sh['CMF_UID'] = $row['CMF_UID'];
$rows = $ka->pull($sh);

if(!assert(isset($rows[0]) && $rows[0]['NM'] == $row['NM'])){
	echo $ka->error;
}

resetdata();




/*
testDB($oci);
testDB2($oci);
*/
/*
$dsn = 'kcas';
$user = 'kcas';
$password = 'kcas';
$dsn = 'kcas';

$conn = odbc_connect($dsn , $user , $password );
$stmt    = odbc_prepare($conn, 'SELECT * FROM V$NLS_PARAMETERS;');
$success = odbc_execute($stmt);
$row = odbc_fetch_array ( $stmt );
print_r($row);
*/

?>