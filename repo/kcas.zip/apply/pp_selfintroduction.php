<?
header("Content-Type: application/json;charset=utf-8");

require_once('inc.conf.php');
require_once(_SITE_ROOT_.'/lib/class.KcasSelfintroduction.php');




// IP���� ���ɿ��� Ȯ��
$ip = isset($_SERVER['REMOTE_ADDR'])?$_SERVER['REMOTE_ADDR']:'';
$allowd = checkAllowIp($_conf['apply_pp']['allowIpList'],$ip);

$mode = isset($_REQUEST['mode'][0])?$_REQUEST['mode']:'';
$data = isset($_POST['data'][0])?$_POST['data']:'{}'; //JSON String
if(get_magic_quotes_gpc()){
	$decdata = json_decode(stripslashes($data),true); //�ѱ۵ \�� ���� �� �־ ���� ������. ���� ����.
}else{
	$decdata = json_decode($data,true);
}
$decdata = utf8ToMs949($decdata); //convert utf-8 => ms949

//== ����� ������
$resdata = array();
$resdata['mode'] = $mode;
$resdata['data'] = null;
$resdata['error'] = null;




if(!$allowd){
	$resdata['error'] = 'Not Allow IP. [YOUR IP : '.$ip.']';
}else{
	$oci = connectDB();

	$ka = new KcasSelfintroduction($oci);


	
	

	//var_dump($data);
	//var_dump($decdata);
	//echo json_last_error();
	//$decdata['CMF_UID']="text";


	switch($mode){
		case 'pull':
			$rows = $ka->pull($decdata);
			if($rows === false){
				$resdata['error'] = $ka->error;
				$loglevel = 'ERROR';
			}else{
				$loglevel = 'INFO';
			}
			$resdata['data'] = $rows;
			
			log_message( $loglevel, array(
			'title' => 'KCAS_APPLY SYNC PULL',
			'log_line' => __LINE__,
			'msg' => 'PULL',
			'idx1' => $decdata['INTEG_ID'],
			'post' =>  file_get_contents('php://input'),
			'decdata' => serialize( $decdata )
			//'resdata' => serialize( $resdata )
			) );

			break;
		case 'push':
			$r = $ka->push($decdata);
			if($r === false){
				$resdata['error'] = $ka->error;
				$loglevel = 'ERROR';
			}else{
				$loglevel = 'INFO';
			}
			$resdata['data'] = $r;

			log_message( $loglevel , array(
			'title' => 'KCAS_APPLY SYNC PUSH',
			'log_line' => __LINE__,
			'msg' => 'PUSH',
			'idx1' => $decdata['INTEG_ID'],
			'post' =>  file_get_contents('php://input'),
			'decdata' => serialize( $decdata )
			//'resdata' => serialize( $resdata )
			) );

			break;
		default:
			$resdata['error'] = '�߸��� mode';

			$loglevel = 'ERROR';
			log_message( $loglevel , array(
			'title' => 'KCAS_APPLY SYNC ERROR',
			'log_line' => __LINE__,
			'msg' => 'PUSH',
			'post' =>  file_get_contents('php://input'),
			'decdata' => serialize( $decdata )
			//'resdata' => serialize( $resdata )
			) );

			break;
	}
}
if(strpos($_SERVER['REMOTE_ADDR'],'210.92.76.20')!==false){
	$resdata['svr'] = $_SERVER['SERVER_ADDR'];
}
//���� ������� ����ص� ����� ������, PHP 5.2.x���� json_encode�� ����ϸ� �ѱ��� \ud55c\uae00 ó�� ��ȯ�Ǽ� ���´�. array2json�� �ѱ۷� �ٷ� ����.
//echo json_encode(ms949ToUtf8($resdata));
echo array2json(ms949ToUtf8($resdata));


?>