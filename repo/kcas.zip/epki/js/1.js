///////////////////////////////////////////////////////////////////////////////////////////////////////////////////
// EPKI Center EPKI Client(EPKIWCtl / npEPKIPI) Toolkit Common Script v1.0
//
// Version | Date | Comment
// v1.1 | 2009.08.31 | Ubikey 휴대폰 인증서 서비스 관련 설정 추가
// v1.2 | 2010.01.15 | 멀티브라우저 지원을 위한 관련 설정 수정
// v2.2 | 2014.02.17 | Java 1.7 보안성 강화로 인한 모듈 패치 수정
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////

var USER_OS;
var USER_BROWSER;

var MICROSOFT_WINDOWS = 0;
var UNSUPPORTED_OS = 1;

var MICROSOFT_IE = 10;
var MOZILLA_FF3 = 11;
var APPLE_SAFARI = 12;
var GOOGLE_CHROME = 13;
var OPERASOFTWARE_OPERA = 14;
var UNSUPPORTED_FF = 20;
var UNSUPPORTED_SAFARI = 21;
var UNSUPPORTED_BROWSER = 22;

// EPKI Client Toolkit Version 
var EPKIWCJTL_Ver 			= '2.0.2.3';
var EPKIWCJTL_Res_Ver 		= '2.0.1.0';
var JcoasVer 				= '1.4.4.10';

// EPKI Client Toolkit 설치파일 경로
var codebaseurl = "http://kepkidev.uwayapply.com:8080"; 
var rootDir = '/EPKI'; 
var libDir = '/lib_2_2';

var EPKIWCJTL_Jar 	= 'EPKIWCJTL-'+EPKIWCJTL_Ver+'.jar';
var EPKIWCJTL_applet 	= 'applet.jar';
var EPKIWCJTL_epki 	= 'EPKIWcJTl.jar';
var EPKIWCJTL_crypto= 'crypto.jar';
var EPKIWCJTL_Jar 	= 'EPKIWCJTL-'+EPKIWCJTL_Ver+'.jar';
var EPKIWCJTL_Res_Jar	= 'EPKIWCJTLRes-'+EPKIWCJTL_Res_Ver+'.jar';
var charSet = 'EUC-KR'; // UTF-8, EUC-KR

//수동설치 파일
var EPKIWCTL_EXE_URL = "http://10.20.20.88:8080/EPKIDemo_Ref/lib/EPKICliSetUp 2.0.exe";  

//윈도우 98/ME용 JRE 별도 배포 위치
var WIN_JRE_FOR_98ME_URL = "http://123.456.789.123:80/EPKIDemo_Ref/lib/jre-1_5_0_22-windows-i586-p.exe";

// 키보드 보안 설정
var KeyboardSecValue	= "none";	// 키보드보안 설정
											// - none : 사용안함 
											// - softforum : 소프트포럼
											// - ezkeytec  : 스페이스인터네셔널

// 휴대폰 인증서 이동 서비스
//var MobilePhoneValue	= "infovine; "; 	// - infovine 또는 인포바인 : 인포바인 휴대폰 서비스
										    // - signgate 또는 정보인증 : 정보인증 모바일키 휴대폰 서비스
var MobilePhoneValue	= "";
													
var InfovineInfoValue			= "";//"CHANNELNAME:NTS_HTS;CERT_COMPANY:DREAMSECURITY;"; 	//인포바인일 경우 사용하는 정보

var nextCheck = false;
var installJRECheck = false;

// EPKI Client Toolkit Install & Check Function

// 사용자의 운영체제를 확인합니다.
function DetectedOS()
{
	var strUserAgent;
	var strPatternWindows = /windows/i; 

	strUserAgent = navigator.userAgent.toLowerCase();
	if(strPatternWindows.test(strUserAgent) == true)
	{
		return MICROSOFT_WINDOWS;
	}
	else
	{
		return UNSUPPORTED_OS;
	}
}

// 사용자의 브라우저를 확인합니다.
// added by jhun75, 20131115
function API_isIE11(){
	
	// ie11 : user-agent
	//var ua  = 'Mozilla/5.0 (Windows NT 6.3; Trident/7.0; rv:11.0) like Gecko';
	var ua = navigator.userAgent;
	
	// case.1, match trident + rv
	var strAppName = navigator.appName.toLowerCase();
	if(strAppName == "netscape") {
		if(ua.match(/trident.+rv:11/i)){
			//console.log("It's IE11!");
			return true;
		}
	}

	// case.2 
	// case2. version check 
	/*
	//var isIE11 = !!(navigator.userAgent.match(/Trident/) && navigator.userAgent.match(/rv 11/));	
	//alert("---------------------4: " + isIE11);
	//if(isIE11) return MICROSOFT_IE;
	// end: added
	if(strAppName == "netscape") {
		var re  = new RegExp("Trident/.*rv:([0-9]{1,}[\.0-9]{0,})");
		if (re.exec(ua) != null) rv = parseFloat( RegExp.$1 );
		if(rv == 11) {
			return true;
		}
	}
	*/
	
	return false;

	// Windows8.1、
	//if(ua.match(/nt.*6\.3.*trident.+rv:11/i)){
	//	console.log("It's Win8.1 and IE11!");
	//}
}
// end: added

// 사용자의 브라우저를 확인합니다.
function DetectedBrowser()
{
	var strAppName = navigator.appName.toLowerCase();
	if(strAppName == "netscape")
	{
		var strUserAgent;
		var strPatternFireFox = /firefox/i;
		var strPatternFireFox3 = /firefox\/3/i;
		var strPatternAppleWebKit = /safari/i;
		var strPatternChrome = /chrome/i;
		var strPatternSafari4 = /Version\/4/i;
		
		strUserAgent = navigator.userAgent.toLowerCase();
		
		// added by jhun75, 20131115
		if(API_isIE11()) return MICROSOFT_IE;
		// end: added

		if(strPatternFireFox.test(strUserAgent) == true)
		{
			if(strPatternFireFox3.test(strUserAgent) == true)
			{
				return MOZILLA_FF3;
			}
			else
			{
				return UNSUPPORTED_FF;
			}
		}
		else if(strPatternAppleWebKit.test(strUserAgent) == true)
		{
			if(strPatternChrome.test(strUserAgent) == true)
			{
				return GOOGLE_CHROME;
			}
			else if(strPatternSafari4.test(strUserAgent) == true)
			{
				return APPLE_SAFARI;
			}
			else
			{
				return UNSUPPORTED_SAFARI;
			}
		}
		else
		{
			return UNSUPPORTED_BROWSER;
		}
	}
	else if(strAppName == "opera")
	{
		return OPERASOFTWARE_OPERA;
	}
	else
	{
		return MICROSOFT_IE;
	}		
}

// EPKIWCtl의 정상 설치 유무를 확인합니다.
function CheckEPKIWcJTl()
{
	var browser =	deployJava.browserName2;
	if(browser == 'Opera'){
		if(typeof(document.ObjEWC) == "undefined" || document.ObjEWC == null ){
			return false;	
			
		}
	}else{	
		if(typeof(document.ObjEWC) == "undefined" || document.ObjEWC == null || document.ObjEWC.object == null){
	
			return false;
		}
	}		
	
	return true;
}

// npEPKIPI의 정상 설치 유무를 확인합니다.
function CheckObjEPI()
{
	
}

// EPKI Client Toolkit 을 사용하기 위한 Object 를 설정합니다.
function SetupObjECT(objCheckmode)
{
	if(!installJRE()){
	
		var strUserAgent = navigator.userAgent.toLowerCase();
		var browser = strUserAgent;
	
//		if( browser.indexOf('firefox')>-1){
//			
//			document.write("<div>"+getInstallJRETag('netscape')+"</div>");
//		}else{
		{
			var strPatternWin98 = /windows 98/i;
			var strPatternWinME = /Windows ME/i;
			
			var strUserAgent = navigator.userAgent.toLowerCase();
	
			if(strPatternWin98.test(strUserAgent) || strPatternWinME.test(strUserAgent)){
//	 			현재 페이지를 자바 설치 페이지로 이동 			
//				location.href = WIN_JRE_FOR_98ME_URL;
				
				var msg = "교과부 암호 모듈을 사용하기 위해서는 \n";
				msg +=  "Sun MicroSytem에서 제공하는 Java 프로그램을  설치하셔야 합니다. \n";
				msg +=  "\n기존에 설치되어 있는 JAVA 가 설치되어 있었어도 \n";
				msg +=  "교과부 암호 모듈이 제대로 작동하지 않을 경우에는, \n";
				msg +=  "\n연결되는 자바 설치 페이지에서 최신 버전을 설치해 주시기 바랍니다. \n";
				msg += "자바 설치 후 다시 접속해 주시기 바랍니다.";
				alert(msg);									


//				팝업에 의한 자바설치 페이지 이동
				window.open(WIN_JRE_FOR_98ME_URL,'Download');

			}else{
//	 			현재 페이지를 자바 설치 페이지로 이동 
//				location.href = 'http://www.java.com';
				
				var msg = "교과부 암호 모듈을 사용하기 위해서는 \n";
				msg +=  "Sun MicroSytem에서 제공하는 Java 프로그램을  설치하셔야 합니다. \n";
				msg +=  "\n기존에 설치되어 있는 JAVA 가 설치되어 있었어도 \n";
				msg +=  "교과부 암호 모듈이 제대로 작동하지 않을 경우에는, \n";
				msg +=  "\n연결되는 자바 설치 페이지에서 최신 버전을 설치해 주시기 바랍니다. \n";
				msg += "자바 설치 후 다시 접속해 주시기 바랍니다.";
				alert(msg);		
				
//				팝업에 의한 자바설치 페이지 이동
				window.open('http://www.java.com');
			}
		}
		return;
		
	}
//	installJRE();
		
	var DebugModeValue		= "true";   // EPKI debug Log state
	//- false : 사용안함
	//- true : 사용함
	var TabValue			= "ALL";// 인증서 선택창의 탭 관리 설정
		// - ALL : 일반/관리 탭을 사용함
		// - General : 관리탭을 사용하지 않음 (Default)
		// - Management : 일반탭을 사용하지 않음

	var StorageTypeValue 	= "Disk;RemovableDisk;SmartCard;PKCS11Token";    // 저장매체 타입 설정  복수개의 저장매체 선택시 ';' 으로 구분
		// - Disk : 하드 디스크(시스템 디스크 - Windows 의 경우 C 드라이브)
		// - RemovableDisk : 이동식 디스크
		// - SmartCard : 저장토큰(스마트카드)
		// - PKCS11Token : 보안토큰(PKCS#11)
	var DomainValue		= "ALL";   	// 인증 도메인 설정  복수개의 인증 도메인 선택시 ';' 으로 구분
		// - ALL : 모든 도메인 설정 (즉 NPKI;GPKI)  (Default)
		// - NPKI : NPKI 도메인 설정
		// - GPKI : GPKI 도메인 설정
	var CANameValue		= "ALL";   	// 인증기관 설정  복수개의 인증기관 선택시 ';' 으로 구분
		// - ALL : 모든 인증기관 설정  (Default)
		// [NPKI]
		// - YESSIGN : 금융결제원
		// - SIGNKOREA : 코스콤
		// - TRADESIGN : 한국무역정보통신
		// - KICA : 한국정보인증(SIGNGATE)
		// - CROSSCERT : 한국전자인증
		// - NCASIGN : 한국전산원
		// [GPKI]
		// - MOPAS : 행정안전부 (인증 도메인 설정시 GPKI 가 설정된 경우 Default)
	var CertPolicyValue	= "ALL";  
		// 인증서 정책 OID 설정  복수개의 인증서 정책 OID 선택시 ';' 으로 구분
		// - ALL : 모든 인증서 정책 OID 수용  (Default)
		// - 기타 세부 OID 는 각 인증 도메인별 규격을 참고
	var KeyUsageValue		= "SIGN;";	// 키사용 용도(KeyUsage) 설정 복수개의 키사용 용도 선택시 ';' 으로 구분
		// - ALL : 모든 키사용 용도 설정 (Default)
		// - SIGN : 서명용 인증서
		// - KM : 암호용 인증서

	var Site				= "@EPKI/CLIENT";    // EPKI Site


	var installprocess = '';
	var sessionId = '' ;

	var CipherProductVer 			= '1.0.3.11';
	var CipherProductResVer 		= '1.0.1.3';
	var TrustedRootCertVer			= '1.0.1.0';
	var UbiKeyVer 					= '1.0.1.3';

	var libPath = rootDir+libDir;		
	var sitebase = codebaseurl+rootDir+"/";//"http://"+host+":"+port+"/EPKIDemo_Ref/";
	var downPath = libPath;

	// 암호 모듈 제조사 라이브러리 정보
	var CipherProductJar 				= 'MagicLine-'+CipherProductVer+'.jar';
	var CipherProductResJar 			= 'MagicLineRes-'+CipherProductResVer+'.jar';
	var TrustedRootCertJar 				= 'MagicLineTrustedRootCert-'+TrustedRootCertVer+'.jar';
	var JcoasJar 					= 'jcaos-'+JcoasVer+'.jar';
	var UbiKeyJar 					= 'ubikey-'+UbiKeyVer+'.jar'



	// 매직라인 설치 조건
	// defalt  : 설치 체크 없이 자동 설치
	// check   : 사용자 매직라인 미설치, 및 업그레이드 일 경우 javascript:goMagicLineProgressCheck() 실행
//	           index page 및 로그인 페이지에서 사용
//	           ex)javascript:goMagicLineProgressCheck() -> 설치 페이지로 이동
	// install : 설치 페이지에서 적용
//	           ex)javascript:goMagicLineProgressFinish() -> 설치 페이지에서 업무 페이지로 이동
	var InstallProgressValue = installprocess;
	//var UserBrowserValue			= browser;
	var SessionIDValue				= sessionId;
	var EPKIWCJLHTML = '';
	
	var isMsie = DetectedBrowser()==MICROSOFT_IE?true:false;
	var isOpera = DetectedBrowser()==OPERASOFTWARE_OPERA?true:false;
	
	var isWin50 = navigator.userAgent.indexOf("NT 5") != -1;
	var isWin60 = navigator.userAgent.indexOf("NT 6") != -1;
	
	if(!isMsie)
		MobilePhoneValue	= "infovine;";

	if(isMsie ){
		EPKIWCJLHTML += ' <object id="ObjEWC" name="EPKIWCJL" classid="clsid:8AD9C840-044E-11D1-B3E9-00805F499D93" ';
		EPKIWCJLHTML += '  codetype="application/java" type="application/x-java-applet" width="0" height="0" onfocus="objBlur(this);" alt="매직라인" >';
		EPKIWCJLHTML += ' <param name="java_code" value="kr.go.EPKI.EPKIWcJTl.class"/>';
		EPKIWCJLHTML += ' <param name="java_codebase" value="'+codebaseurl+'"/>';
		EPKIWCJLHTML += ' <param name="type" value="application/x-java-applet;jpi-version=1.5"/>';
	}else{
		EPKIWCJLHTML += '<div style="position:absolute;top:0px;left:0px;width:0px;height:0px;z-index:1;visibility:hidden;">';
		EPKIWCJLHTML += '<applet id="ObjEWC" codebase="'+codebaseurl+'"  code="kr.go.EPKI.EPKIWcJTl.class" ';
		EPKIWCJLHTML += 'width=200 height=75 MAYSCRIPT >'; 
	}

	EPKIWCJLHTML += ' <param name="archive" value="'+libPath+'/'+EPKIWCJTL_applet+','+libPath+'/'+EPKIWCJTL_epki+','+libPath+'/'+EPKIWCJTL_crypto+'"/>';

	
//	if( (isWin50 || isWin60) && nextCheck){
		EPKIWCJLHTML += ' <param name="separate_jvm" value="true"/>';
//	}

	// ## MagicLine's Parameter. ##
//	EPKIWCJLHTML += ' <param name="CacheFile" value="'+CipherProductJar+';'+EPKIWCJTL_Jar+';"/>';
//	EPKIWCJLHTML += ' <param name="CacheFileVersion" value="'+CipherProductVer+';'+EPKIWCJTL_Ver+';"/>';
	EPKIWCJLHTML += ' <param name="CacheFile" value="'+CipherProductJar+';"/>';
	EPKIWCJLHTML += ' <param name="CacheFileVersion" value="'+CipherProductVer+';"/>';
	EPKIWCJLHTML += ' <param name="RemoteFilePath" value="'+downPath+'"/>';
	EPKIWCJLHTML += ' <param name="ResourceFile" value="'+CipherProductResJar+';'+EPKIWCJTL_Res_Jar+';"/>';
	EPKIWCJLHTML += ' <param name="ResoureVersion" value="'+CipherProductResVer+';'+EPKIWCJTL_Res_Ver+';"/>';
	EPKIWCJLHTML += ' <param name="CompanyProductVersion" value="'+EPKIWCJTL_Ver+'"/>';
	EPKIWCJLHTML += ' <param name="CompanyCoreClass" value="com.dreamsecurity.ui.MagicXSignRealAppletProcImpl"/>'; 
	EPKIWCJLHTML += ' <param name="TrustedRootCertFile" value="'+TrustedRootCertJar+'"/>';
	EPKIWCJLHTML += ' <param name="TrustedRootCertVersion" value="'+TrustedRootCertVer+'"/>';
	EPKIWCJLHTML += ' <param name="DebugMode" value="' + DebugModeValue + '"/>';
	EPKIWCJLHTML += ' <param name="ActiveTab" value="' + TabValue + '"/>';
	EPKIWCJLHTML += ' <param name="StorageType" value="' + StorageTypeValue + '"/>';
	EPKIWCJLHTML += ' <param name="Domain" value="' + DomainValue + '"/>';	
	EPKIWCJLHTML += ' <param name="CAName" value="' + CANameValue + '"/>';
	EPKIWCJLHTML += ' <param name="CertPolicy" value="' + CertPolicyValue + '"/>';
	EPKIWCJLHTML += ' <param name="KeyUsage" value="' + KeyUsageValue + '"/>';
	EPKIWCJLHTML += ' <param name="KeyboardSec" value="' + KeyboardSecValue + '"/>';
	EPKIWCJLHTML += ' <param name="MobilePhone" value="' + MobilePhoneValue + '"/>';
	EPKIWCJLHTML += ' <param name="InfovineInfo" value="CHANNELNAME:' + InfovineInfoValue + ';CERT_COMPANY:DREAMSECURITY;"/>';
	EPKIWCJLHTML += ' <param name="InstallProgress" value="'+InstallProgressValue+'"/>';
	EPKIWCJLHTML += ' <param name="LocalDownLoadPath" value="' + Site + '"/>';
	EPKIWCJLHTML += ' <param name="sitebase" value="' + sitebase + '"/>';
	EPKIWCJLHTML += ' <param name="SessionID" value="' + SessionIDValue + '"/>';
	EPKIWCJLHTML += ' <param name="CharSet" value="' + charSet + '"/>';
	EPKIWCJLHTML += ' <param name="codebase_lookup" value="false"/>';
	if(isMsie ){
		EPKIWCJLHTML += ' </object>';
	}else{
		EPKIWCJLHTML += '</applet>';
		EPKIWCJLHTML += '</div>';	
	}
	
	if(isMsie ){
		var epkiElement = document.createElement('div');
		epkiElement.id='EPKIElement';
		epkiElement.innerHTML = EPKIWCJLHTML;
		var ref_node =  document.getElementsByTagName("HEAD")[0];
		ref_node.parentNode.insertBefore(epkiElement, ref_node);		
	}else{		
		document.write(EPKIWCJLHTML);
	}	

}


function SetupObjError()
{
	alert("EPKI Client Toolkit의 Object 선언이 올바르지 않습니다.\n\n관리자에게 문의하여 주시기 바랍니다.");
	pageReload();
}


// EPKI Client Toolkit 에서 사용하기 위한 각종 속성값을 설정합니다.
function InitObjECT()
{	

	
}

// 클라이언트 모듈의 로딩 완료 여부를 확인합니다.
function checkLoad(){
		
	while(!document.ObjEWC.getLoadStatus()){
		setTimeout("",1);		
	}
}

// 에러 정보를 출력합니다.
// 사용 환경에 따라, 적절히 변경하여 사용합니다.
function ECTErrorInfo()
{
	alert("EPKIWCtl 모듈에서 오류가 발생하였습니다.\n오류정보 : [" + document.ObjEWC.GetErrorNum() + "] - " + document.ObjEWC.GetErrorMsg());
	pageReload();
		
}

// 원문에 대해 전사서명을 수행합니다.
// 전자서명 수행 시 v1.0에서는 inDataFlag, algID가 확장성을 위해서만 존재하는 파라미터이며, 일반적으로 다음과 같이 입력하여 사용합니다.
// 예) Sign(1, "", theForm.OrgData.value);
function Sign(inDataFlag, algID, plainData)
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	
	var nResult;
	var strReturnData;
	
	algID=="3DES"?"DESede":algID;
	strReturnData = document.ObjEWC.getSignedData(plainData,"PKCS7");
		
	if(strReturnData == 100)
		pageReload();

	return strReturnData;	
}

// 전자 서명 메시지에 대한 검증을 수행하고, 서명에 사용된 원문 메시지를 반환합니다.
// plainData는 서명 데이터에 원문이 포함되지 않은 경우에만 입력합니다.
function Verify(inDataFlag, signedData, plainData)
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var strVerifyData = "";

	strVerifyData = document.ObjEWC.getSignedDataVerify(signedData);
		
	return strVerifyData;	
}

// 선택한 알고리즘에 적합한 임의의 대칭키를 생성합니다.
function GenSymmetricKey(algID)
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var strSymKey = "";
	
	algID=(algID=="3DES"?"DESede":algID);
	var symKey = document.ObjEWC.genSessionKeyIV(algID);
	
	return symKey;
}

// 대칭키 암호화를 수행합니다.
function Encrypt(algID, symKey, data)
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var strEncryptedData = "";

	algID = (algID=="3DES"?"DESede":algID)	;
	strEncryptedData = document.ObjEWC.getEncrypt(algID, symKey, data);
	
	return strEncryptedData;
}

// 대칭키 복호화를 수행합니다.
function Decrypt(algID, symKey, data)
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var strDecryptedData = "";
		
	strDecryptedData = document.ObjEWC.getDecrypt(algID, symKey, data);
	
	return strDecryptedData;
}

// 비대칭키 암호화를 수행합니다.
function Envelop(algID, recipientCerts, data)
{	
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var strEnvelopedData = "";
	
	strEnvelopedData = document.ObjEWC.envelopedData(algID, recipientCerts[0], data);
	
	return strEnvelopedData;
}

// 비대칭키 복호화를 수행합니다.
function Develop(strEnvelopedData)
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var strDevelopedData = "";
	
	strDevelopedData = document.ObjEWC.DevelopeData(strEnvelopedData);		
		
	if(strDevelopedData == "100")
		pageReload();
		
	return strDevelopedData;
}

// 인증서 기반 사용자 인증 및 클라리언트와 서버 간 보안 채널 요청 데이터를 생성합니다.
function RequestSession(serverCert, algID, sessionID, userID)
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var strRequestData = "";	

	// 서버 kmCert 설정(Base64 인코딩 문자열)
	document.ObjEWC.SetProperty("ServerCert", serverCert);
	
	algID = ((algID=="3DES")?"DESede":algID);
	if(typeof(userID) == "undefined" || userID=="")
		strRequestData = document.ObjEWC.RequestSession(algID, sessionID);
	else
		strRequestData = document.ObjEWC.RequestSession(algID, sessionID,userID);
	
//	if(strRequestData=="100")
//		pageReload();	

			
	return strRequestData;
}



// 보안 채널이 형성된 후에 공유된 세션키를 사용하여 대칭키 암호화를 수행합니다.
function SessionEncrypt(sessionID, data)
{		
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var strSessionEncryptData ="";
	strSessionEncryptData = document.ObjEWC.SessionEncrypt(sessionID, data);
			
	return strSessionEncryptData;
}

// 보안 채널이 형성된 후에 공유된 세션키를 사용하여 대칭키 복호화를 수행합니다.
function SessionDecrypt(sessionID, encData)
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}

	var strSessionDecryptData = "";
	
	strSessionDecryptData = document.ObjEWC.SessionDecrypt(sessionID,encData);
	
	return strSessionDecryptData;
}

// 보안 채널이 형성된 후, 내부적으로 관리되는 보안 세션 정보(Key, IV 등)를 안전하게 삭제합니다.
function DestroySession(sessionID)
{	
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	return document.ObjEWC.destorySession(sessionID);
}

// 신원확인 정보를 이용한 인증서 기반, 사용자 인증을 수행합니다.
function RequestVerifyVID(serverCert, userID)
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var strRequestData = "";

	document.ObjEWC.SetProperty("ServerCert", serverCert);
	strRequestData = document.ObjEWC.RequestVerifyVID(userID);
	
	if(strRequestData == "100")
		pageReload();
	
	return strRequestData;
}

// EPKI Client Toolkit 에 설정된 속성값을 반환합니다.
function GetProperty(field)
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var nResult;
	
	nResult = document.ObjEWC.getProperty(field);
	
	return nResult;
}

// 전달 받은 메시지에 전자 서명한 인증서의 정보를 추출합니다.
function GetCertInfo(signerCert, certfield)
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var nResult;
	alert(document.ObjEWC.GetCertInfo(signerCert,'CERT_SubjectAltName'));
	nResult = document.ObjEWC.GetCertInfo(signerCert, certfield);
	
	return nResult;
}

// 인증서 관리자를 실행합니다.
function InvokeCMDlg()
{
	if(!CheckEPKIWcJTl()){
		SetupObjError();
		pageReload();
	}
	var ret = document.ObjEWC.InvokeCMDlg();
	
	if(ret == 2 ){
		ECTErrorInfo();
	}
}

function goMagicLineInstallPage(){}

function getInstallJRE98MeTag(current_browser){
	  
	  var objectTag = "";
	      objectTag = ' <OBJECT ';
	      objectTag +=' ID = "MagicXSign1"';
	      objectTag +=' classid="clsid:8AD9C840-044E-11D1-B3E9-00805F499D93"';
	      objectTag +=' width="0"';
	      objectTag +=' height="0"';
	      objectTag +=' codebase="http://java.sun.com/update/1.5.0/jinstall-1_5_0_22-windows-i586.cab#Version=6,0,2,6">';
	      objectTag +='</OBJECT> ';
	      
		var embedTag = ' <object';
		    embedTag +=' classid = "clsid:8AD9C840-044E-11D1-B3E9-00805F499D93"';
		    embedTag +=' codebase = "http://java.sun.com/update/1.5.0/jinstall-1_5_0-windows-i586.cab#Version=6,0,2,6"';
		    embedTag +=' WIDTH = "0px" HEIGHT = "0px" >';
		    embedTag +=' <PARAM NAME = CODEBASE VALUE = "http://java.sun.com/update/1.5.0/jinstall-1_5_0-windows-i586.cab" >';
		    embedTag +=' <param name = "type" value = "application/x-java-applet;jpi-version=1.6.0_07">';
		    embedTag +=' <param name = "scriptable" value = "true">';
			embedTag +=' <comment>';
			embedTag +='	 <embed';
		    embedTag +='      type = "application/x-java-applet"';
		    embedTag +='      JAVA_CODEBASE = "http://java.sun.com/update/1.5.0/jinstall-1_5_0-windows-i586.cab"';
		    embedTag +='      WIDTH = "0px"';
		    embedTag +='      HEIGHT = "0px"';
		    embedTag +='			scriptable = true';
		    embedTag +='			pluginspage = "tp://java.sun.com/update/1.5.0/jre-1_5_0_22-windows-i586.xpi">';
		    embedTag +='			<noembed>';
		    embedTag +='      </noembed>';
			embedTag +='	</embed>';
		    embedTag +=' </comment>';
			embedTag +=' </object>';      

		if(current_browser == "MSIE")
			return objectTag; 
		else if(current_browser == "Netscape Family")
			return embedTag;
		else 
			return objectTag + embedTag;
}

function getInstallJRETag(current_browser){
	  
	  var objectTag = "";
	      objectTag = ' <OBJECT ';
	      objectTag +=' ID = "MagicXSign1"';
	      objectTag +=' classid="clsid:8AD9C840-044E-11D1-B3E9-00805F499D93"';
	      objectTag +=' width="0"';
	      objectTag +=' height="0"';
	      objectTag +=' codebase="http://java.sun.com/update/1.6.0/jinstall-6u24-windows-i586.cab#Version=6,0,2,6">';
	      objectTag +='</OBJECT> ';
	      
		var embedTag = ' <object';
		    embedTag +=' classid = "clsid:8AD9C840-044E-11D1-B3E9-00805F499D93"';
		    embedTag +=' codebase = "http://java.sun.com/update/1.6.0/jinstall-6u24-windows-i586.cab#Version=6,0,2,6"';
		    embedTag +=' WIDTH = "0px" HEIGHT = "0px" >';
		    embedTag +=' <PARAM NAME = CODEBASE VALUE = "http://java.sun.com/update/1.6.0/jinstall-6-fcs-windows-i586.cab" >';
		    embedTag +=' <param name = "type" value = "application/x-java-applet;jpi-version=1.6.0_07">';
		    embedTag +=' <param name = "scriptable" value = "true">';
			embedTag +=' <comment>';
			embedTag +='	 <embed';
		    embedTag +='      type = "application/x-java-applet"';
		    embedTag +='      JAVA_CODEBASE = "http://java.sun.com/update/1.6.0/jinstall-6-fcs-windows-i586.cab"';
		    embedTag +='      WIDTH = "0px"';
		    embedTag +='      HEIGHT = "0px"';
		    embedTag +='			scriptable = true';
		    embedTag +='			pluginspage = "http://javadl.sun.com/webapps/download/GetFile/1.6.0_24-b07/windows-i586/xpiinstall.exe">';
		    embedTag +='			<noembed>';
		    embedTag +='      </noembed>';
			embedTag +='	</embed>';
		    embedTag +=' </comment>';
			embedTag +=' </object>';      

		if(current_browser == "MSIE")
			return objectTag; 
		else if(current_browser == "Netscape Family")
			return embedTag;
		else 
			return objectTag + embedTag;
}

function pageReload(){
	if(DetectedBrowser() == MOZILLA_FF3)
		document.location.back();
	else if(DetectedBrowser() == MICROSOFT_IE)	
		document.location.reload();	
	else
		document.location.refresh();
}


var deployJava={debug:null,firefoxJavaVersion:null,myInterval:null,preInstallJREList:null,returnPage:null,brand:null,locale:null,installType:null,EAInstallEnabled:false,EarlyAccessURL:null,getJavaURL:'http://java.sun.com/webapps/getjava/BrowserRedirect?host=java.com',appleRedirectPage:'http://www.apple.com/support/downloads/',oldMimeType:'application/npruntime-scriptable-plugin;DeploymentToolkit',mimeType:'application/java-deployment-toolkit',launchButtonPNG:'http://java.sun.com/products/jfc/tsc/articles/swing2d/webstart.png',browserName:null,browserName2:null,
// modified by jhun75, 20131115
//getJREs:function(){var list=new Array();if(deployJava.isPluginInstalled()){var plugin=deployJava.getPlugin();var VMs=plugin.jvms;for(var i=0;i<VMs.getLength();i++){list[i]=VMs.get(i).version;}}else{var browser=deployJava.getBrowser();if(browser=='MSIE'){if(deployJava.testUsingActiveX('1.7.0')){list[0]='1.7.0';}else if(deployJava.testUsingActiveX('1.6.0')){list[0]='1.6.0';}else if(deployJava.testUsingActiveX('1.5.0')){list[0]='1.5.0';}else if(deployJava.testUsingActiveX('1.4.2')){list[0]='1.4.2';}else if(deployJava.testForMSVM()){list[0]='1.1';}}else if(browser=='Netscape Family'){deployJava.getJPIVersionUsingMimeType();if(deployJava.firefoxJavaVersion!=null){list[0]=deployJava.firefoxJavaVersion;}else if(deployJava.testUsingMimeTypes('1.7')){list[0]='1.7.0';}else if(deployJava.testUsingMimeTypes('1.6')){list[0]='1.6.0';}else if(deployJava.testUsingMimeTypes('1.5')){list[0]='1.5.0';}else if(deployJava.testUsingMimeTypes('1.4.2')){list[0]='1.4.2';}else if(deployJava.browserName2=='Safari'){if(deployJava.testUsingPluginsArray('1.7.0')){list[0]='1.7.0';}else if(deployJava.testUsingPluginsArray('1.6')){list[0]='1.6.0';}else if(deployJava.testUsingPluginsArray('1.5')){list[0]='1.5.0';}else if(deployJava.testUsingPluginsArray('1.4.2')){list[0]='1.4.2';}}}}
//if(deployJava.debug){for(var i=0;i<list.length;++i){alert('We claim to have detected Java SE '+list[i]);}}
//return list;},
getJREs:function(){var list=new Array();if(deployJava.isPluginInstalled()){var plugin=deployJava.getPlugin();var VMs=plugin.jvms;for(var i=0;i<VMs.getLength();i++){list[i]=VMs.get(i).version;}}else{var browser=deployJava.getBrowser();if(browser=='MSIE' || API_isIE11() ){if(deployJava.testUsingActiveX('1.7.0')){list[0]='1.7.0';}else if(deployJava.testUsingActiveX('1.6.0')){list[0]='1.6.0';}else if(deployJava.testUsingActiveX('1.5.0')){list[0]='1.5.0';}else if(deployJava.testUsingActiveX('1.4.2')){list[0]='1.4.2';}else if(deployJava.testForMSVM()){list[0]='1.1';}}else if(browser=='Netscape Family'){deployJava.getJPIVersionUsingMimeType();if(deployJava.firefoxJavaVersion!=null){list[0]=deployJava.firefoxJavaVersion;}else if(deployJava.testUsingMimeTypes('1.7')){list[0]='1.7.0';}else if(deployJava.testUsingMimeTypes('1.6')){list[0]='1.6.0';}else if(deployJava.testUsingMimeTypes('1.5')){list[0]='1.5.0';}else if(deployJava.testUsingMimeTypes('1.4.2')){list[0]='1.4.2';}else if(deployJava.browserName2=='Safari'){if(deployJava.testUsingPluginsArray('1.7.0')){list[0]='1.7.0';}else if(deployJava.testUsingPluginsArray('1.6')){list[0]='1.6.0';}else if(deployJava.testUsingPluginsArray('1.5')){list[0]='1.5.0';}else if(deployJava.testUsingPluginsArray('1.4.2')){list[0]='1.4.2';}}}}
if(deployJava.debug){for(var i=0;i<list.length;++i){alert('We claim to have detected Java SE '+list[i]);}}
return list;},
// end: modified
installJRE:function(requestVersion){var ret=false;if(deployJava.isPluginInstalled()){if(deployJava.getPlugin().installJRE(requestVersion)){deployJava.refresh();if(deployJava.returnPage!=null){document.location=deployJava.returnPage;}
return true;}else{return false;}}else{return deployJava.installLatestJRE();}},installLatestJRE:function(){if(deployJava.isPluginInstalled()){if(deployJava.getPlugin().installLatestJRE()){deployJava.refresh();if(deployJava.returnPage!=null){document.location=deployJava.returnPage;}
return true;}else{return false;}}else{var browser=deployJava.getBrowser();var platform=navigator.platform.toLowerCase();if((deployJava.EAInstallEnabled=='true')&&(platform.indexOf('win')!=-1)&&(deployJava.EarlyAccessURL!=null)){deployJava.preInstallJREList=deployJava.getJREs();if(deployJava.returnPage!=null){deployJava.myInterval=setInterval("deployJava.poll()",3000);}
location.href=deployJava.EarlyAccessURL;return false;}else{if(browser=='MSIE'){return deployJava.IEInstall();}else if((browser=='Netscape Family')&&(platform.indexOf('win32')!=-1)){return deployJava.FFInstall();}else{location.href=deployJava.getJavaURL+
((deployJava.returnPage!=null)?('&returnPage='+deployJava.returnPage):'')+
((deployJava.locale!=null)?('&locale='+deployJava.locale):'')+
((deployJava.brand!=null)?('&brand='+deployJava.brand):'');}
return false;}}},runApplet:function(attributes,parameters,minimumVersion){if(minimumVersion=='undefined'||minimumVersion==null){minimumVersion='1.1';}
var regex="^(\\d+)(?:\\.(\\d+)(?:\\.(\\d+)(?:_(\\d+))?)?)?$";var matchData=minimumVersion.match(regex);if(deployJava.returnPage==null){deployJava.returnPage=document.location;}
if(matchData!=null){var browser=deployJava.getBrowser();if((browser!='?')&&('Safari'!=deployJava.browserName2)){if(deployJava.versionCheck(minimumVersion+'+')){deployJava.writeAppletTag(attributes,parameters);}else if(deployJava.installJRE(minimumVersion+'+')){deployJava.refresh();location.href=document.location;deployJava.writeAppletTag(attributes,parameters);}}else{deployJava.writeAppletTag(attributes,parameters);}}else{if(deployJava.debug){alert('Invalid minimumVersion argument to runApplet():'+
minimumVersion);}}},writeAppletTag:function(attributes,parameters){var s='<'+'applet ';var codeAttribute=false;for(var attribute in attributes){s+=(' '+attribute+'="'+attributes[attribute]+'"');if(attribute=='code'){codeAttribute=true;}}
if(!codeAttribute){s+=(' code="dummy"');}
s+='>';document.write(s);if(parameters!='undefined'&&parameters!=null){var codebaseParam=false;for(var parameter in parameters){if(parameter=='codebase_lookup'){codebaseParam=true;}
s='<param name="'+parameter+'" value="'+
parameters[parameter]+'">';document.write(s);}
if(!codebaseParam){document.write('<param name="codebase_lookup" value="false">');}}
document.write('<'+'/'+'applet'+'>');},versionCheck:function(versionPattern)
{var index=0;var regex="^(\\d+)(?:\\.(\\d+)(?:\\.(\\d+)(?:_(\\d+))?)?)?(\\*|\\+)?$";var matchData=versionPattern.match(regex);if(matchData!=null){var familyMatch=true;var patternArray=new Array();for(var i=1;i<matchData.length;++i){if((typeof matchData[i]=='string')&&(matchData[i]!='')){patternArray[index]=matchData[i];index++;}}
if(patternArray[patternArray.length-1]=='+'){familyMatch=false;patternArray.length--;}else{if(patternArray[patternArray.length-1]=='*'){patternArray.length--;}}
var list=deployJava.getJREs();for(var i=0;i<list.length;++i){if(deployJava.compareVersionToPattern(list[i],patternArray,familyMatch)){return true;}}
return false;}else{alert('Invalid versionPattern passed to versionCheck: '+
versionPattern);return false;}},isWebStartInstalled:function(minimumVersion){var browser=deployJava.getBrowser();if((browser=='?')||('Safari'==deployJava.browserName2)){return true;}
if(minimumVersion=='undefined'||minimumVersion==null){minimumVersion='1.4.2';}
var retval=false;var regex="^(\\d+)(?:\\.(\\d+)(?:\\.(\\d+)(?:_(\\d+))?)?)?$";var matchData=minimumVersion.match(regex);if(matchData!=null){retval=deployJava.versionCheck(minimumVersion+'+');}else{if(deployJava.debug){alert('Invalid minimumVersion argument to isWebStartInstalled(): '+minimumVersion);}
retval=deployJava.versionCheck('1.4.2+');}
return retval;},getJPIVersionUsingMimeType:function(){for(var i=0;i<navigator.mimeTypes.length;++i){var s=navigator.mimeTypes[i].type;var m=s.match(/^application\/x-java-applet;jpi-version=(.*)$/);if(m!=null){deployJava.firefoxJavaVersion=m[1];if('Opera'!=deployJava.browserName2){break;}}}},launchWebStartApplication:function(jnlp){return false;},createWebStartLaunchButtonEx:function(jnlp,minimumVersion){if(deployJava.returnPage==null){deployJava.returnPage=jnlp;}
var url='javascript:deployJava.launchWebStartApplication(\''+jnlp+'\');';document.write('<'+'a href="'+url+'" onMouseOver="window.status=\'\'; '+'return true;"><'+'img '+'src="'+deployJava.launchButtonPNG+'" '+'border="0" /><'+'/'+'a'+'>');},createWebStartLaunchButton:function(jnlp,minimumVersion){if(deployJava.returnPage==null){deployJava.returnPage=jnlp;}
var url='javascript:'+'if (!deployJava.isWebStartInstalled(&quot;'+
minimumVersion+'&quot;)) {'+'if (deployJava.installLatestJRE()) {'+'if (deployJava.launch(&quot;'+jnlp+'&quot;)) {}'+'}'+'} else {'+'if (deployJava.launch(&quot;'+jnlp+'&quot;)) {}'+'}';document.write('<'+'a href="'+url+'" onMouseOver="window.status=\'\'; '+'return true;"><'+'img '+'src="'+deployJava.launchButtonPNG+'" '+'border="0" /><'+'/'+'a'+'>');},launch:function(jnlp){document.location=jnlp;return true;},isPluginInstalled:function(){var plugin=deployJava.getPlugin();if(plugin&&plugin.jvms){return true;}else{return false;}},isAutoUpdateEnabled:function(){if(deployJava.isPluginInstalled()){return deployJava.getPlugin().isAutoUpdateEnabled();}
return false;},setAutoUpdateEnabled:function(){if(deployJava.isPluginInstalled()){return deployJava.getPlugin().setAutoUpdateEnabled();}
return false;},setInstallerType:function(type){deployJava.installType=type;if(deployJava.isPluginInstalled()){return deployJava.getPlugin().setInstallerType(type);}
return false;},setAdditionalPackages:function(packageList){if(deployJava.isPluginInstalled()){return deployJava.getPlugin().setAdditionalPackages(packageList);}
return false;},setEarlyAccess:function(enabled){deployJava.EAInstallEnabled=enabled;},isPlugin2:function(){if(deployJava.isPluginInstalled()){if(deployJava.versionCheck('1.6.0_10+')){try{return deployJava.getPlugin().isPlugin2();}catch(err){}}}
return false;},allowPlugin:function(){deployJava.getBrowser();var ret=('Safari'!=deployJava.browserName2&&'Opera'!=deployJava.browserName2);return ret;},getPlugin:function(){deployJava.refresh();var ret=null;if(deployJava.allowPlugin()){ret=document.getElementById('deployJavaPlugin');}
return ret;},compareVersionToPattern:function(version,patternArray,familyMatch){var regex="^(\\d+)(?:\\.(\\d+)(?:\\.(\\d+)(?:_(\\d+))?)?)?$";var matchData=version.match(regex);if(matchData!=null){var index=0;var result=new Array();for(var i=1;i<matchData.length;++i){if((typeof matchData[i]=='string')&&(matchData[i]!=''))
{result[index]=matchData[i];index++;}}
var l=Math.min(result.length,patternArray.length);if(familyMatch){for(var i=0;i<l;++i){if(result[i]!=patternArray[i])return false;}
return true;}else{for(var i=0;i<l;++i){if(result[i]<patternArray[i]){return false;}else if(result[i]>patternArray[i]){return true;}}
return true;}}else{return false;}},getBrowser:function(){if(deployJava.browserName==null){var browser=navigator.userAgent.toLowerCase();if(deployJava.debug){alert('userAgent -> '+browser);}
if(browser.indexOf('msie')!=-1){deployJava.browserName='MSIE';deployJava.browserName2='MSIE';}else if(browser.indexOf('firefox')!=-1){deployJava.browserName='Netscape Family';deployJava.browserName2='Firefox';}else if(browser.indexOf('chrome')!=-1){deployJava.browserName='Netscape Family';deployJava.browserName2='Chrome';}else if(browser.indexOf('safari')!=-1){deployJava.browserName='Netscape Family';deployJava.browserName2='Safari';}else if(browser.indexOf('mozilla')!=-1){deployJava.browserName='Netscape Family';deployJava.browserName2='Other';}else if(browser.indexOf('opera')!=-1){deployJava.browserName='Netscape Family';deployJava.browserName2='Opera';}else{deployJava.browserName='?';deployJava.browserName2='unknown';}
if(deployJava.debug){alert('Detected browser name:'+deployJava.browserName+', '+deployJava.browserName2);}}
return deployJava.browserName;},
// modified by jhun75, 20131115
//testUsingActiveX:function(version){var objectName='JavaWebStart.isInstalled.'+version+'.0';if(!ActiveXObject){if(deployJava.debug){alert('Browser claims to be IE, but no ActiveXObject object?');}
//return false;}
//try{return(new ActiveXObject(objectName)!=null);}catch(exception){return false;}},
testUsingActiveX:function(version){var objectName='JavaWebStart.isInstalled.'+version+'.0';if(API_isIE11()) {if(!typeof window.ActiveXObject=='function') return false;}else{if(!ActiveXObject){if(deployJava.debug){alert('Browser claims to be IE, but no ActiveXObject object?');}
return false;}}
try{return(new ActiveXObject(objectName)!=null);}catch(exception){return false;}},
// end: modified 
testForMSVM:function(){var clsid='{08B0E5C0-4FCB-11CF-AAA5-00401C608500}';if(typeof oClientCaps!='undefined'){var v=oClientCaps.getComponentVersion(clsid,"ComponentID");if((v=='')||(v=='5,0,5000,0')){return false;}else{return true;}}else{return false;}},testUsingMimeTypes:function(version){if(!navigator.mimeTypes){if(deployJava.debug){alert('Browser claims to be Netscape family, but no mimeTypes[] array?');}
return false;}
for(var i=0;i<navigator.mimeTypes.length;++i){s=navigator.mimeTypes[i].type;var m=s.match(/^application\/x-java-applet\x3Bversion=(1\.8|1\.7|1\.6|1\.5|1\.4\.2)$/);if(m!=null){if(deployJava.compareVersions(m[1],version)){return true;}}}
return false;},testUsingPluginsArray:function(version){if((!navigator.plugins)||(!navigator.plugins.length)){return false;}
var platform=navigator.platform.toLowerCase();for(var i=0;i<navigator.plugins.length;++i){s=navigator.plugins[i].description;if(s.search(/^Java Switchable Plug-in (Cocoa)/)!=-1){if(deployJava.compareVersions("1.5.0",version)){return true;}}else if(s.search(/^Java/)!=-1){if(platform.indexOf('win')!=-1){if(deployJava.compareVersions("1.5.0",version)||deployJava.compareVersions("1.6.0",version)){return true;}}}}
if(deployJava.compareVersions("1.5.0",version)){return true;}
return false;},IEInstall:function(){location.href=deployJava.getJavaURL+
((deployJava.returnPage!=null)?('&returnPage='+deployJava.returnPage):'')+
((deployJava.locale!=null)?('&locale='+deployJava.locale):'')+
((deployJava.brand!=null)?('&brand='+deployJava.brand):'')+
((deployJava.installType!=null)?('&type='+deployJava.installType):'');return false;},done:function(name,result){},FFInstall:function(){location.href=deployJava.getJavaURL+
((deployJava.returnPage!=null)?('&returnPage='+deployJava.returnPage):'')+
((deployJava.locale!=null)?('&locale='+deployJava.locale):'')+
((deployJava.brand!=null)?('&brand='+deployJava.brand):'')+
((deployJava.installType!=null)?('&type='+deployJava.installType):'');return false;},compareVersions:function(installed,required){var a=installed.split('.');var b=required.split('.');for(var i=0;i<a.length;++i){a[i]=Number(a[i]);}
for(var i=0;i<b.length;++i){b[i]=Number(b[i]);}
if(a.length==2){a[2]=0;}
if(a[0]>b[0])return true;if(a[0]<b[0])return false;if(a[1]>b[1])return true;if(a[1]<b[1])return false;if(a[2]>b[2])return true;if(a[2]<b[2])return false;return true;},enableAlerts:function(){deployJava.browserName=null;deployJava.debug=true;},poll:function(){deployJava.refresh();var postInstallJREList=deployJava.getJREs();if((deployJava.preInstallJREList.length==0)&&(postInstallJREList.length!=0)){clearInterval(deployJava.myInterval);if(deployJava.returnPage!=null){location.href=deployJava.returnPage;};}
if((deployJava.preInstallJREList.length!=0)&&(postInstallJREList.length!=0)&&(deployJava.preInstallJREList[0]!=postInstallJREList[0])){clearInterval(deployJava.myInterval);if(deployJava.returnPage!=null){location.href=deployJava.returnPage;}}},writePluginTag:function(){var browser=deployJava.getBrowser();if(browser=='MSIE'){document.write('<'+'object classid="clsid:CAFEEFAC-DEC7-0000-0000-ABCDEFFEDCBA" '+'id="deployJavaPlugin" width="0" height="0">'+'<'+'/'+'object'+'>');}else if(browser=='Netscape Family'&&deployJava.allowPlugin()){deployJava.writeEmbedTag();}},refresh:function(){navigator.plugins.refresh(false);var browser=deployJava.getBrowser();if(browser=='Netscape Family'&&deployJava.allowPlugin()){var plugin=document.getElementById('deployJavaPlugin');if(plugin==null){deployJava.writeEmbedTag();}}},writeEmbedTag:function(){var written=false;if(navigator.mimeTypes!=null){for(var i=0;i<navigator.mimeTypes.length;i++){if(navigator.mimeTypes[i].type==deployJava.mimeType){if(navigator.mimeTypes[i].enabledPlugin){document.write('<'+'embed id="deployJavaPlugin" type="'+
deployJava.mimeType+'" hidden="true" />');written=true;}}}
if(!written)for(var i=0;i<navigator.mimeTypes.length;i++){if(navigator.mimeTypes[i].type==deployJava.oldMimeType){if(navigator.mimeTypes[i].enabledPlugin){document.write('<'+'embed id="deployJavaPlugin" type="'+
deployJava.oldMimeType+'" hidden="true" />');}}}}},do_initialize:function(){deployJava.writePluginTag();if(deployJava.locale==null){var loc=null;if(loc==null)try{loc=navigator.userLanguage;}catch(err){}
if(loc==null)try{loc=navigator.systemLanguage;}catch(err){}
if(loc==null)try{loc=navigator.language;}catch(err){}
if(loc!=null){loc.replace("-","_")
deployJava.locale=loc;}}}};deployJava.do_initialize();

/* PluginDetect v0.6.3 [ onWindowLoaded isMinVersion getVersion onDetectionDone Java(OTF&NOTF&getInfo) ] by Eric Gerds www.pinlady.net/PluginDetect */ if(!PluginDetect)
{
    var PluginDetect=
    {
        getNum:function(b,c)
        {
            if(!this.num(b))
            {
                return null
            }
            var a;
            if(typeof c=="undefined")
            {
                a=/[\d][\d\.\_,-]*/.exec(b)
            }
            else
            {
                a=(new RegExp(c)).exec(b)
            }
            return a?a[0].replace(/[\.\_-]/g,","):null
        }
        ,hasMimeType:function(c)
        {
            if(PluginDetect.isIE)
            {
                return null
            }
            var b,a,d,e=c.constructor==String?[c]:c;
            for(d=0;d<e.length;d++)
            {
                b=navigator.mimeTypes[e[d]];
                if(b&&b.enabledPlugin)
                {
                    a=b.enabledPlugin;
                    if(a.name||a.description)
                    {
                        return b
                    }
                }
            }
            return null
        }
        ,findNavPlugin:function(g,d)
        {
            var a=g.constructor==String?g:g.join(".*"),e=d===false?"":"\\d",b,c=new RegExp(a+".*"+e+"|"+e+".*"+a,"i"),f=navigator.plugins;
            for(b=0;b<f.length;b++)
            {
                if(c.test(f[b].description)||c.test(f[b].name))
                {
                    return f[b]
                }
            }
            return null
        }
        ,AXO:window.ActiveXObject,getAXO:function(b,a)
        {
            var f=null,d,c=false;
            try
            {
                f=new this.AXO(b);
                c=true
            }
            catch(d)
            {
            }
            if(typeof a!="undefined")
            {
                delete f;
                return c
            }
            return f
        }
        ,num:function(a)
        {
            return(typeof a!="string"?false:(/\d/).test(a))
        }
        ,compareNums:function(g,e)
        {
            var d=this,c,b,a,f=window.parseInt;
            if(!d.num(g)||!d.num(e))
            {
                return 0
            }
            if(d.plugin&&d.plugin.compareNums)
            {
                return d.plugin.compareNums(g,e)
            }
            c=g.split(",");
            b=e.split(",");
            for(a=0;a<Math.min(c.length,b.length);a++)
            {
                if(f(c[a],10)>f(b[a],10))
                {
                    return 1
                }
                if(f(c[a],10)<f(b[a],10))
                {
                    return -1
                }
            }
            return 0
        }
        ,formatNum:function(b)
        {
            if(!this.num(b))
            {
                return null
            }
            var a,c=b.replace(/\s/g,"").replace(/[\.\_]/g,",").split(",").concat(["0","0","0","0"]);
            for(a=0;a<4;a++)
            {
                if(/^(0+)(.+)$/.test(c[a]))
                {
                    c[a]=RegExp.$2
                }
            }
            if(!(/\d/).test(c[0]))
            {
                c[0]="0"
            }
            return c[0]+","+c[1]+","+c[2]+","+c[3]
        }
        ,initScript:function()
        {
            var $=this,userAgent=navigator.userAgent;
            $.isIE=/*@cc_on!@*/false;
            $.IEver=$.isIE&&((/MSIE\s*(\d\.?\d*)/i).exec(userAgent))?parseFloat(RegExp.$1,10):-1;
            $.ActiveXEnabled=false;
            if($.isIE)
            {
                var x,progid=["Msxml2.XMLHTTP","Msxml2.DOMDocument","Microsoft.XMLDOM","ShockwaveFlash.ShockwaveFlash","TDCCtl.TDCCtl","Shell.UIHelper","Scripting.Dictionary","wmplayer.ocx"];
                for(x=0;x<progid.length;x++)
                {
                    if($.getAXO(progid[x],1))
                    {
                        $.ActiveXEnabled=true;
                        break
                    }
                }
                $.head=typeof document.getElementsByTagName!="undefined"?document.getElementsByTagName("head")[0]:null
            }
            $.isGecko=!$.isIE&&typeof navigator.product=="string"&&(/Gecko/i).test(navigator.product)&&(/Gecko\s*\/\s*\d/i).test(userAgent)?true:false;
            $.GeckoRV=$.isGecko?$.formatNum((/rv\s*\:\s*([\.\,\d]+)/i).test(userAgent)?RegExp.$1:"0.9"):null;
            $.isSafari=!$.isIE&&(/Safari\s*\/\s*\d/i).test(userAgent)?true:false;
            $.isChrome=(/Chrome\s*\/\s*\d/i).test(userAgent)?true:false;
            $.onWindowLoaded(0)
        }
        ,init:function(c,a)
        {
            if(typeof c!="string")
            {
                return -3
            }
            c=c.toLowerCase().replace(/\s/g,"");
            var b=this,d;
            if(typeof b[c]=="undefined")
            {
                return -3
            }
            d=b[c];
            b.plugin=d;
            if(typeof d.installed=="undefined"||a==true)
            {
                d.installed=null;
                d.version=null;
                d.version0=null;
                d.getVersionDone=null;
                d.$=b
            }
            b.garbage=false;
            if(b.isIE&&!b.ActiveXEnabled)
            {
                if(b.plugin!=b.java)
                {
                    return -2
                }
            }
            return 1
        }
        ,isMinVersion:function(g,e,c,b)
        {
            var f=PluginDetect,d=f.init(g);
            if(d<0)
            {
                return d
            }
            if(typeof e=="number")
            {
                e=e.toString()
            }
            if(typeof e!="string")
            {
                e="0"
            }
            if(!f.num(e))
            {
                return -3
            }
            e=f.formatNum(e);
            var a=-1,h=f.plugin;
            if(h.getVersionDone!=1)
            {
                h.getVersion(c,b);
                if(h.getVersionDone===null)
                {
                    h.getVersionDone=1
                }
            }
            if(h.version!==null||h.installed!==null)
            {
                if(h.installed<=0.5)
                {
                    a=h.installed
                }
                else
                {
                    a=(h.version===null?0:(f.compareNums(h.version,e)>=0?1:-1))
                }
            }
            f.cleanup();
            return a;
            return -3
        }
        ,getVersion:function(e,b,a)
        {
            var d=PluginDetect,c=d.init(e),f;
            if(c<0)
            {
                return null
            }
            f=d.plugin;
            if(f.getVersionDone!=1)
            {
                f.getVersion(b,a);
                if(f.getVersionDone===null)
                {
                    f.getVersionDone=1
                }
            }
            d.cleanup();
            return(f.version||f.version0);
            return null
        }
        ,getInfo:function(f,c,b)
        {
            var a=
            {
            };
            var e=PluginDetect,d=e.init(f),g;
            if(d<0)
            {
                return a
            }
            g=e.plugin;
            if(typeof g.getInfo!="undefined")
            {
                if(g.getVersionDone===null)
                {
                    e.getVersion(f,c,b)
                }
                a=g.getInfo()
            };
            return a
        }
        ,cleanup:function()
        {
            var a=this;
            if(a.garbage&&typeof window.CollectGarbage!="undefined")
            {
                window.CollectGarbage()
            }
        }
        ,isActiveXObject:function(b)
        {
        }
        ,codebaseSearch:function(c)
        {
            var e=this;
            if(!e.ActiveXEnabled)
            {
                return null
            }
            if(typeof c!="undefined")
            {
                return e.isActiveXObject(c)
            }
        }
        ,dummy1:0
    }
}
PluginDetect.onDetectionDone=function(g,e,d,a)
{
    var c=PluginDetect,b=c.init(g),h;
    if(b==-3)
    {
        return -1
    }
    if(c.plugin.getVersionDone!=1)
    {
        h=c.isMinVersion(g,"0",d,a);
        if(h==-3)
        {
            h=c.getVersion(g,d,a)
        }
    }
    if(c.plugin.installed!=-0.5&&c.plugin.installed!=0.5)
    {
        if(typeof e=="function")
        {
            e(c)
        }
        return 1
    }
    if(c.plugin!=c.java)
    {
        return 1
    };
    c.plugin.NOTF.SetupAppletQuery();
    if(typeof e=="function")
    {
        c.plugin.funcs[c.plugin.funcs.length]=e
    }
    return 0;
    return -1
};
PluginDetect.onWindowLoaded=function(c)
{
    var b=PluginDetect,a=window;
    if(b.EventWinLoad===true)
    {
    }
    else
    {
        b.winLoaded=false;
        b.EventWinLoad=true;
        if(typeof a.addEventListener!="undefined")
        {
            a.addEventListener("load",b.runFuncs,false)
        }
        else
        {
            if(typeof a.attachEvent!="undefined")
            {
                a.attachEvent("onload",b.runFuncs)
            }
            else
            {
                if(typeof a.onload=="function")
                {
                    b.funcs[b.funcs.length]=a.onload
                }
                a.onload=b.runFuncs
            }
        }
    }
    if(typeof c=="function")
    {
        b.funcs[b.funcs.length]=c
    }
};
PluginDetect.funcs=[0];
PluginDetect.runFuncs=function()
{
    var b=PluginDetect,a;
    b.winLoaded=true;
    for(a=0;a<b.funcs.length;a++)
    {
        if(typeof b.funcs[a]=="function")
        {
            b.funcs[a](b);
            b.funcs[a]=null
        }
    }
};
PluginDetect.java=
{
    mimeType:"application/x-java-applet",classID:"clsid:8AD9C840-044E-11D1-B3E9-00805F499D93",DTKclassID:"clsid:CAFEEFAC-DEC7-0000-0000-ABCDEFFEDCBA",DTKmimeType:"application/npruntime-scriptable-plugin;DeploymentToolkit",JavaVersions:[[1,9,2,25],[1,8,2,25],[1,7,2,25],[1,6,2,25],[1,5,2,25],[1,4,2,25],[1,3,1,25]],searchJavaPluginAXO:function()
    {
        var h=null,a=this,c=a.$,g=[],j=[1,5,0,14],i=[1,6,0,2],f=[1,3,1,0],e=[1,4,2,0],d=[1,5,0,7],b=false;
        if(!c.ActiveXEnabled)
        {
            return null
        };
        b=true;
        if(c.IEver>=a.minIEver)
        {
            g=a.searchJavaAXO(i,i,b);
            if(g.length>0&&b)
            {
                g=a.searchJavaAXO(j,j,b)
            }
        }
        else
        {
            if(b)
            {
                g=a.searchJavaAXO(d,d,true)
            };
            if(g.length==0)
            {
                g=a.searchJavaAXO(f,e,false)
            }
        }
        if(g.length>0)
        {
            h=g[0]
        }
        a.JavaPlugin_versions=[].concat(g);
        return h
    }
    ,searchJavaAXO:function(l,i,m)
    {
        var n,f,h=this.$,p,k,a,e,g,j,b,q=[];
        if(h.compareNums(l.join(","),i.join(","))>0)
        {
            i=l
        }
        i=h.formatNum(i.join(","));
        var o,d="1,4,2,0",c="JavaPlugin."+l[0]+""+l[1]+""+l[2]+""+(l[3]>0?("_"+(l[3]<10?"0":"")+l[3]):"");
        for(n=0;n<this.JavaVersions.length;n++)
        {
            f=this.JavaVersions[n];
            p="JavaPlugin."+f[0]+""+f[1];
            g=f[0]+"."+f[1]+".";
            for(a=f[2];a>=0;a--)
            {
                b="JavaWebStart.isInstalled."+g+a+".0";
                if(h.compareNums(f[0]+","+f[1]+","+a+",0",i)>=0&&!h.getAXO(b,1))
                {
                    continue
                }
                o=h.compareNums(f[0]+","+f[1]+","+a+",0",d)<0?true:false;
                for(e=f[3];e>=0;e--)
                {
                    k=a+"_"+(e<10?"0"+e:e);
                    j=p+k;
                    if(h.getAXO(j,1)&&(o||h.getAXO(b,1)))
                    {
                        q[q.length]=g+k;
                        if(!m)
                        {
                            return q
                        }
                    }
                    if(j==c)
                    {
                        return q
                    }
                }
                if(h.getAXO(p+a,1)&&(o||h.getAXO(b,1)))
                {
                    q[q.length]=g+a;
                    if(!m)
                    {
                        return q
                    }
                }
                if(p+a==c)
                {
                    return q
                }
            }
        }
        return q
    }
    ,minIEver:7,getFromMimeType:function(a)
    {
        var h,f,c=this.$,j=new RegExp(a),d,k,i=
        {
        }
        ,e=0,b,g=[""];
        for(h=0;h<navigator.mimeTypes.length;h++)
        {
            k=navigator.mimeTypes[h];
            if(j.test(k.type)&&k.enabledPlugin)
            {
                k=k.type.substring(k.type.indexOf("=")+1,k.type.length);
                d="a"+c.formatNum(k);
                if(typeof i[d]=="undefined")
                {
                    i[d]=k;
                    e++
                }
            }
        }
        for(f=0;f<e;f++)
        {
            b="0,0,0,0";
            for(h in i)
            {
                if(i[h])
                {
                    d=h.substring(1,h.length);
                    if(c.compareNums(d,b)>0)
                    {
                        b=d
                    }
                }
            }
            g[f]=i["a"+b];
            i["a"+b]=null
        }
        if(!(/windows|macintosh/i).test(navigator.userAgent))
        {
            g=[g[0]]
        }
        return g
    }
    ,queryJavaHandler:function()
    {
        var b=PluginDetect.java,a=window.java,c;
        b.hasRun=true;
        try
        {
            if(typeof a.lang!="undefined"&&typeof a.lang.System!="undefined")
            {
                b.value=[a.lang.System.getProperty("java.version")+" ",a.lang.System.getProperty("java.vendor")+" "]
            }
        }
        catch(c)
        {
        }
    }
    ,queryJava:function()
    {
        var c=this,d=c.$,b=navigator.userAgent,f;
        if(typeof window.java!="undefined"&&navigator.javaEnabled()&&!c.hasRun)
        {
            if(d.isGecko)
            {
                if(d.hasMimeType("application/x-java-vm"))
                {
                    try
                    {
                        var g=document.createElement("div"),a=document.createEvent("HTMLEvents");
                        a.initEvent("focus",false,true);
                        g.addEventListener("focus",c.queryJavaHandler,false);
                        g.dispatchEvent(a)
                    }
                    catch(f)
                    {
                    }
                    if(!c.hasRun)
                    {
                        c.queryJavaHandler()
                    }
                }
            }
            else
            {
                if((/opera.9\.(0|1)/i).test(b)&&(/mac/i).test(b))
                {
                }
                else
                {
                    if(!c.hasRun)
                    {
                        c.queryJavaHandler()
                    }
                }
            }
        }
        return c.value
    }
    ,forceVerifyTag:[],jar:[],VENDORS:["Sun Microsystems Inc.","Apple Computer, Inc."],init:function()
    {
        var a=this,b=a.$;
        if(typeof a.app!="undefined")
        {
            a.delJavaApplets(b)
        }
        a.hasRun=false;
        a.value=[null,null];
        a.useTag=[2,2,2];
        a.app=[0,0,0,0,0,0];
        a.appi=3;
        a.queryDTKresult=null;
        a.OTF=0;
        a.BridgeResult=[[null,null],[null,null],[null,null]];
        a.JavaActive=[0,0,0];
        a.All_versions=[];
        a.DeployTK_versions=[];
        a.MimeType_versions=[];
        a.JavaPlugin_versions=[];
        a.funcs=[];
        var c=a.NOTF;
        if(c)
        {
            c.$=b;
            if(c.javaInterval)
            {
                clearInterval(c.javaInterval)
            }
            c.EventJavaReady=null;
            c.javaInterval=null;
            c.count=0;
            c.intervalLength=250;
            c.countMax=40
        }
        a.lateDetection=b.winLoaded;
        if(!a.lateDetection)
        {
            b.onWindowLoaded(a.delJavaApplets)
        }
    }
    ,getVersion:function(f,l)
    {
        var h,d=this,g=d.$,j=null,n=null,e=null,c=navigator.javaEnabled();
        if(d.getVersionDone===null)
        {
            d.init()
        }
        var k;
        if(typeof l!="undefined"&&l.constructor==Array)
        {
            for(k=0;k<d.useTag.length;k++)
            {
                if(typeof l[k]=="number")
                {
                    d.useTag[k]=l[k]
                }
            }
        }
        for(k=0;k<d.forceVerifyTag.length;k++)
        {
            d.useTag[k]=d.forceVerifyTag[k]
        }
        if(typeof f!="undefined")
        {
            d.jar[d.jar.length]=f
        }
        if(d.getVersionDone==0)
        {
            if(!d.version||d.useAnyTag())
            {
                h=d.queryExternalApplet(f);
                if(h[0])
                {
                    e=h[0];
                    n=h[1]
                }
            }
            d.EndGetVersion(e,n);
            return
        }
        var i=d.queryDeploymentToolKit();
        if(typeof i=="string"&&i.length>0)
        {
            j=i;
            n=d.VENDORS[0]
        }
        if(!g.isIE)
        {
            var q,m,b,o,a;
            a=g.hasMimeType(d.mimeType);
            o=(a&&c)?true:false;
            if(d.MimeType_versions.length==0&&a)
            {
                h=d.getFromMimeType("application/x-java-applet.*jpi-version.*=");
                if(h[0]!="")
                {
                    if(!j)
                    {
                        j=h[0]
                    }
                    d.MimeType_versions=h
                }
            }
            if(!j&&a)
            {
                h="Java[^\\d]*Plug-in";
                b=g.findNavPlugin(h);
                if(b)
                {
                    h=new RegExp(h,"i");
                    q=h.test(b.description)?g.getNum(b.description):null;
                    m=h.test(b.name)?g.getNum(b.name):null;
                    if(q&&m)
                    {
                        j=(g.compareNums(g.formatNum(q),g.formatNum(m))>=0)?q:m
                    }
                    else
                    {
                        j=q||m
                    }
                }
            }
            if(!j&&a&&(/macintosh.*safari/i).test(navigator.userAgent))
            {
                b=g.findNavPlugin("Java.*\\d.*Plug-in.*Cocoa",false);
                if(b)
                {
                    q=g.getNum(b.description);
                    if(q)
                    {
                        j=q
                    }
                }
            }
            if(j)
            {
                d.version0=j;
                if(c)
                {
                    e=j
                }
            }
            if(!e||d.useAnyTag())
            {
                b=d.queryExternalApplet(f);
                if(b[0])
                {
                    e=b[0];
                    n=b[1]
                }
            }
            if(!e)
            {
                b=d.queryJava();
                if(b[0])
                {
                    d.version0=b[0];
                    e=b[0];
                    n=b[1];
                    if(d.installed==-0.5)
                    {
                        d.installed=0.5
                    }
                }
            }
            if(d.installed===null&&!e&&o&&!(/macintosh.*ppc/i).test(navigator.userAgent))
            {
                h=d.getFromMimeType("application/x-java-applet.*version.*=");
                if(h[0]!="")
                {
                    e=h[0]
                }
            }
            if(!e&&o)
            {
                if(/macintosh.*safari/i.test(navigator.userAgent))
                {
                    if(d.installed===null)
                    {
                        d.installed=0
                    }
                    else
                    {
                        if(d.installed==-0.5)
                        {
                            d.installed=0.5
                        }
                    }
                }
            }
        }
        else
        {
            if(!j&&i!=-1)
            {
                j=d.searchJavaPluginAXO();
                if(j)
                {
                    n=d.VENDORS[0]
                }
            }
            if(!j)
            {
                d.JavaFix()
            }
            if(j)
            {
                d.version0=j;
                if(c&&g.ActiveXEnabled)
                {
                    e=j
                }
            }
            if(!e||d.useAnyTag())
            {
                h=d.queryExternalApplet(f);
                if(h[0])
                {
                    e=h[0];
                    n=h[1]
                }
            }
        }
        if(d.installed===null)
        {
            d.installed=e?1:(j?-0.2:-1)
        }
        d.EndGetVersion(e,n)
    }
    ,EndGetVersion:function(b,d)
    {
        var a=this,c=a.$;
        if(a.version0)
        {
            a.version0=c.formatNum(c.getNum(a.version0))
        }
        if(b)
        {
            a.version=c.formatNum(c.getNum(b));
            a.vendor=(typeof d=="string"?d:"")
        }
        if(a.getVersionDone!=1)
        {
            a.getVersionDone=0
        }
    }
    ,queryDeploymentToolKit:function()
    {
        var d=this,g=d.$,i,b,h=null,a=null;
        if((g.isGecko&&g.compareNums(g.GeckoRV,g.formatNum("1.6"))<=0)||g.isSafari||(g.isIE&&!g.ActiveXEnabled))
        {
            d.queryDTKresult=0
        }
        if(d.queryDTKresult!==null)
        {
            return d.queryDTKresult
        }
        if(g.isIE&&g.IEver>=6)
        {
            d.app[0]=g.instantiate("object",[],[]);
            h=g.getObject(d.app[0])
        }
        else
        {
            if(!g.isIE&&g.hasMimeType(d.DTKmimeType))
            {
                d.app[0]=g.instantiate("object",["type",d.DTKmimeType],[]);
                h=g.getObject(d.app[0])
            }
        }
        if(h)
        {
            if(g.isIE&&g.IEver>=6)
            {
                try
                {
                    h.classid=d.DTKclassID
                }
                catch(i)
                {
                }
            }
            try
            {
                var c,f=h.jvms;
                if(f)
                {
                    a=f.getLength();
                    if(typeof a=="number")
                    {
                        for(b=0;b<a;b++)
                        {
                            c=f.get(a-1-b);
                            if(c)
                            {
                                c=c.version;
                                if(g.getNum(c))
                                {
                                    d.DeployTK_versions[b]=c
                                }
                            }
                        }
                    }
                }
            }
            catch(i)
            {
            }
        }
        g.hideObject(h);
        d.queryDTKresult=d.DeployTK_versions.length>0?d.DeployTK_versions[0]:(a==0?-1:0);
        return d.queryDTKresult
    }
    ,queryExternalApplet:function(d)
    {
        var c=this,e=c.$,h=c.BridgeResult,b=c.app,g=c.appi,a="&nbsp;&nbsp;&nbsp;&nbsp;";
        if(typeof d!="string"||!(/\.jar\s*$/).test(d))
        {
            return[null,null]
        }
        if(c.OTF<1)
        {
            c.OTF=1
        }
        if(!e.isIE)
        {
            if((e.isGecko||e.isChrome)&&!e.hasMimeType(c.mimeType)&&!c.queryJava()[0])
            {
                return[null,null]
            }
        }
        if(c.OTF<2)
        {
            c.OTF=2
        }
        if(!b[g]&&c.canUseObjectTag()&&c.canUseThisTag(0))
        {
            b[1]=e.instantiate("object",[],[],a);
            b[g]=e.isIE?e.instantiate("object",["archive",d,"code","A.class","type",c.mimeType],["archive",d,"code","A.class","mayscript","true","scriptable","true"],a):e.instantiate("object",["archive",d,"classid","java:A.class","type",c.mimeType],["archive",d,"mayscript","true","scriptable","true"],a);
            h[0]=[0,0];
            c.query1Applet(g)
        }
        if(!b[g+1]&&c.canUseAppletTag()&&c.canUseThisTag(1))
        {
            b[g+1]=e.instantiate("applet",["archive",d,"code","A.class","alt",a,"mayscript","true"],["mayscript","true"],a);
            h[1]=[0,0];
            c.query1Applet(g+1)
        }
        if(e.isIE&&!b[g+2]&&c.canUseObjectTag()&&c.canUseThisTag(2))
        {
            b[g+2]=e.instantiate("object",["classid",c.classID],["archive",d,"code","A.class","mayscript","true","scriptable","true"],a);
            h[2]=[0,0];
            c.query1Applet(g+2)
        };
        if(c.OTF<3&&((b[g]&&!h[0][0])||(b[g+1]&&!h[1][0])||(b[g+2]&&!h[2][0])))
        {
            var i=c.NOTF.isJavaActive();
            if(i>=0)
            {
                c.OTF=3;
                c.installed=i==1?0.5:-0.5;
                c.NOTF.SetupAppletQuery()
            }
        };
        var j,f=0;
        for(j=0;j<h.length;j++)
        {
            if(b[g+j]||c.canUseThisTag(j))
            {
                f++
            }
            else
            {
                break
            }
        }
        if(f==h.length)
        {
            c.getVersionDone=1;
            if(c.forceVerifyTag.length>0)
            {
                c.getVersionDone=0
            }
        }
        return c.getBR()
    }
    ,canUseAppletTag:function()
    {
        return((!this.$.isIE||navigator.javaEnabled())?true:false)
    }
    ,canUseObjectTag:function()
    {
        return((!this.$.isIE||this.$.ActiveXEnabled)?true:false)
    }
    ,useAnyTag:function()
    {
        var b=this,a;
        for(a=0;a<b.useTag.length;a++)
        {
            if(b.canUseThisTag(a))
            {
                return true
            }
        }
        return false
    }
    ,canUseThisTag:function(c)
    {
        var a=this,b=a.$;
        if(a.useTag[c]==3)
        {
            return true
        }
        if(!a.version0||!navigator.javaEnabled()||(b.isIE&&!b.ActiveXEnabled))
        {
            if(a.useTag[c]==2)
            {
                return true
            }
            if(a.useTag[c]==1&&!a.getBR()[0])
            {
                return true
            }
        }
        return false
    }
    ,getBR:function()
    {
        var b=this.BridgeResult,a;
        for(a=0;a<b.length;a++)
        {
            if(b[a][0])
            {
                return[b[a][0],b[a][1]]
            }
        }
        return[b[0][0],b[0][1]]
    }
    ,delJavaApplets:function(b)
    {
        var c=b.java.app,a;
        for(a=c.length-1;a>=0;a--)
        {
            b.uninstantiate(c[a])
        }
    }
    ,query1Applet:function(g)
    {
        var f,c=this,d=c.$,a=null,h=null,b=d.getObject(c.app[g],true);
        try
        {
            if(b)
            {
                a=b.getVersion()+" ";
                h=b.getVendor()+" ";
                if(d.num(a))
                {
                    c.BridgeResult[g-c.appi]=[a,h];
                    d.hideObject(c.app[g])
                }
                if(d.isIE&&a&&b.readyState!=4)
                {
                    d.garbage=true;
                    d.uninstantiate(c.app[g])
                }
            }
        }
        catch(f)
        {
        }
    }
    ,NOTF:
    {
        isJavaActive:function()
        {
            var e=this,c=e.$.java,a,b,d=-9;
            for(a=c.appi;a<c.app.length;a++)
            {
                b=e.isJavaActive_x_(a);
                if(b==1)
                {
                    c.JavaActive[a-c.appi]=1
                }
                if(b>d)
                {
                    d=b
                }
            }
            return d
        }
        ,isJavaActive_x_:function(g)
        {
            var h=this,d=h.$,c=d.java,f,b=d.getObject(c.app[g]),a=h.status(g);
            if(a==-2)
            {
                return -2
            }
            if(h.status(1)>=0)
            {
                return 0
            }
            try
            {
                if(d.isIE&&d.IEver>=c.minIEver&&b.object)
                {
                    return 1
                }
            }
            catch(f)
            {
            }
            if(a==1&&(d.isIE||c.version0))
            {
                return 1
            }
            if(a<0)
            {
                return -1
            }
            return 0
        }
        ,status:function(g)
        {
            var d=this.$,b=d.java,f,a=d.getObject(b.app[g]),c=d.getContainer(b.app[g]),h=null;
            if(!a||!c)
            {
                return -2
            }
            h=c.scrollWidth||c.offsetWidth;
            try
            {
                if(typeof h=="number")
                {
                    if(d.isIE&&a.nodeType==3&&h>d.pluginSize)
                    {
                        return -1
                    }
                    if(!d.isIE&&h>d.pluginSize)
                    {
                        return -1
                    }
                    if(d.winLoaded&&h==d.pluginSize&&(!d.isIE||a.readyState==4))
                    {
                        return 1
                    }
                }
            }
            catch(f)
            {
            }
            return 0
        }
        ,SetupAppletQuery:function()
        {
            var b=this,a=b.$;
            if(b.EventJavaReady===true)
            {
            }
            else
            {
                b.EventJavaReady=true;
                if(typeof setInterval!="undefined")
                {
                    b.javaInterval=setInterval(b.onIntervalQuery,b.intervalLength)
                }
                a.funcs[0]=b.winOnLoadQuery
            }
        }
        ,winOnLoadQuery:function(c)
        {
            var b=c.java,d=b.NOTF,a;
            if(b.OTF==3)
            {
                a=d.AppletQuery();
                d.queryCleanup(a[1],a[2])
            }
        }
        ,onIntervalQuery:function()
        {
            var c=PluginDetect,b=c.java,d=b.NOTF,a;
            if(b.OTF==3)
            {
                a=d.AppletQuery();
                if(a[0]||(c.winLoaded&&d.count>d.countMax))
                {
                    d.queryCleanup(a[1],a[2])
                }
            }
            d.count++
        }
        ,AppletQuery:function()
        {
            var f=this,e=f.$,d=e.java,b,a,c;
            for(b=0;b<d.BridgeResult.length;b++)
            {
                d.query1Applet(b+d.appi)
            }
            a=d.getBR();
            c=(a[0]||f.isJavaActive()<0)?true:false;
            return[c,a[0],a[1]]
        }
        ,queryCleanup:function(d,g)
        {
            var f=this,e=f.$,c=e.java,a;
            if(c.OTF==4)
            {
                return
            }
            c.OTF=4;
            var b=f.isJavaActive()==1?true:false;
            if(d)
            {
                c.installed=1
            }
            else
            {
                if(b)
                {
                    if(c.version0)
                    {
                        c.installed=1;
                        d=c.version0
                    }
                    else
                    {
                        c.installed=0
                    }
                }
                else
                {
                    if(c.installed==0.5)
                    {
                        c.installed=0
                    }
                    else
                    {
                        if(c.version0)
                        {
                            c.installed=-0.2
                        }
                        else
                        {
                            c.installed=-1
                        }
                    }
                }
            }
            c.EndGetVersion(d,g);
            if(f.javaInterval)
            {
                clearInterval(f.javaInterval)
            }
            for(a=0;a<c.funcs.length;a++)
            {
                if(typeof c.funcs[a]=="function")
                {
                    c.funcs[a](e);
                    c.funcs[a]=null
                }
            }
        }
    }
    ,append:function(e,d)
    {
        for(var c=0;c<d.length;c++)
        {
            e[e.length]=d[c]
        }
    }
    ,getInfo:function()
    {
        var m=
        {
        };
        var a=this,d=a.$,h,l=a.installed;
        m=
        {
            All_versions:[],DeployTK_versions:[],MimeType_versions:[],DeploymentToolkitPlugin:(a.queryDTKresult==0?false:true),vendor:(typeof a.vendor=="string"?a.vendor:""),OTF:(a.OTF<3?0:(a.OTF==3?1:2))
        };
        var g=[null,null,null];
        for(h=0;h<a.BridgeResult.length;h++)
        {
            g[h]=a.BridgeResult[h][0]?1:(a.JavaActive[h]==1?0:(a.useTag[h]>=1&&a.OTF>=1&&a.OTF!=3&&!(h==2&&!d.isIE)&&(a.BridgeResult[h][0]!==null||(h==1&&!a.canUseAppletTag())||(h!=1&&!a.canUseObjectTag())||l==-0.2||l==-1)?-1:null))
        }
        m.objectTag=g[0];
        m.appletTag=g[1];
        m.objectTagActiveX=g[2];
        var c=m.All_versions,k=m.DeployTK_versions,f=m.MimeType_versions,b=a.JavaPlugin_versions;
        a.append(k,a.DeployTK_versions);
        a.append(f,a.MimeType_versions);
        a.append(c,(k.length>0?k:(f.length>0?f:(b.length>0?b:(typeof a.version=="string"?[a.version]:[])))));
        for(h=0;h<c.length;h++)
        {
            c[h]=d.formatNum(d.getNum(c[h]))
        }
        var i,e=null;
        if(!d.isIE)
        {
            i=f.length>0?d.hasMimeType(a.mimeType+";jpi-version="+f[0]):d.hasMimeType(a.mimeType);
            if(i)
            {
                e=i.enabledPlugin
            }
        }
        m.name=e?e.name:"";
        m.description=e?e.description:"";
        var j=null;
        if((l==0||l==1)&&m.vendor=="")
        {
            if(/macintosh/i.test(navigator.userAgent))
            {
                j=a.VENDORS[1]
            }
            else
            {
                if(!d.isIE&&(/windows/i).test(navigator.userAgent))
                {
                    j=a.VENDORS[0]
                }
                else
                {
                    if(/linux/i.test(navigator.userAgent))
                    {
                        j=a.VENDORS[0]
                    }
                }
            }
            if(j)
            {
                m.vendor=j
            }
        };
        return m
    }
    ,JavaFix:function()
    {
    }
};
PluginDetect.div=null;
PluginDetect.pluginSize=1;
PluginDetect.DOMbody=null;
PluginDetect.uninstantiate=function(a)
{
    var c,b=this;
    if(!a)
    {
        return
    }
    try
    {
        if(a[0]&&a[0].firstChild)
        {
            a[0].removeChild(a[0].firstChild)
        }
        if(a[0]&&b.div)
        {
            b.div.removeChild(a[0])
        }
        if(b.div&&b.div.childNodes.length==0)
        {
            b.div.parentNode.removeChild(b.div);
            b.div=null;
            if(b.DOMbody&&b.DOMbody.parentNode)
            {
                b.DOMbody.parentNode.removeChild(b.DOMbody)
            }
            b.DOMbody=null
        }
        a[0]=null
    }
    catch(c)
    {
    }
};
PluginDetect.getObject=function(b,a)
{
    var f,c=this,d=null;
    try
    {
        if(b&&b[0]&&b[0].firstChild)
        {
            d=b[0].firstChild
        }
    }
    catch(f)
    {
    }
    try
    {
        if(a&&d&&typeof d.focus!="undefined"&&typeof document.hasFocus!="undefined"&&!document.hasFocus())
        {
            d.focus()
        }
    }
    catch(f)
    {
    }
    return d
};
PluginDetect.getContainer=function(a)
{
    var c,b=null;
    if(a&&a[0])
    {
        b=a[0]
    }
    return b
};
PluginDetect.hideObject=function(a)
{
    var b=this.getObject(a);
    if(b&&b.style)
    {
        b.style.height="0"
    }
};
PluginDetect.instantiate=function(h,b,c,a)
{
    var j=function(d)
    {
        var e=d.style;
        if(!e)
        {
            return
        }
        e.border="0px";
        e.padding="0px";
        e.margin="0px";
        e.fontSize=(g.pluginSize+3)+"px";
        e.height=(g.pluginSize+3)+"px";
        e.visibility="visible";
        if(d.tagName&&d.tagName.toLowerCase()=="div")
        {
            e.width="100%";
            e.display="block"
        }
        else
        {
            if(d.tagName&&d.tagName.toLowerCase()=="span")
            {
                e.width=g.pluginSize+"px";
                e.display="inline"
            }
        }
    };
    var k,l=document,g=this,p,i=(l.getElementsByTagName("body")[0]||l.body),o=l.createElement("span"),n,f,m="/";
    if(typeof a=="undefined")
    {
        a=""
    }
    p="<"+h+' width="'+g.pluginSize+'" height="'+g.pluginSize+'" ';
    for(n=0;n<b.length;n=n+2)
    {
        p+=b[n]+'="'+b[n+1]+'" '
    }
    p+=">";
    for(n=0;n<c.length;n=n+2)
    {
        p+='<param name="'+c[n]+'" value="'+c[n+1]+'" />'
    }
    p+=a+"<"+m+h+">";
    if(!g.div)
    {
        g.div=l.createElement("div");
        f=l.getElementById("plugindetect");
        if(f)
        {
            j(f);
            f.appendChild(g.div)
        }
        else
        {
            if(i)
            {
                try
                {
                    if(i.firstChild&&typeof i.insertBefore!="undefined")
                    {
                        i.insertBefore(g.div,i.firstChild)
                    }
                    else
                    {
                        i.appendChild(g.div)
                    }
                }
                catch(k)
                {
                }
            }
            else
            {
                try
                {
                    l.write('<div id="pd33993399">o<'+m+"div>");
                    i=(l.getElementsByTagName("body")[0]||l.body);
                    i.appendChild(g.div);
                    i.removeChild(l.getElementById("pd33993399"))
                }
                catch(k)
                {
                    try
                    {
                        g.DOMbody=l.createElement("body");
                        l.getElementsByTagName("html")[0].appendChild(g.DOMbody);
                        g.DOMbody.appendChild(g.div)
                    }
                    catch(k)
                    {
                    }
                }
            }
        }
        j(g.div)
    }
    if(g.div&&g.div.parentNode&&g.div.parentNode.parentNode)
    {
        g.div.appendChild(o);
        try
        {
            o.innerHTML=p
        }
        catch(k)
        {
        }
        j(o);
        return[o]
    }
    return[null]
};
PluginDetect.initScript();

function returnPage(page){
	location.href = page;
}
/**
 * installJRE() : java 설치 페이지에서 사용
 * installProgressJRE()에서 java 설치요건이 충족되지 못한경우
 * 이 함수를 사용하고 혹 도중에 충족이 되었을경우 index 페이지로 이동함.
 * @return
 */
function installJRE(){
	
	browser =	deployJava.browserName2;
	
	var installTag = "";
	var detailBrowser = getOSInfoStr();
	if(detailBrowser.indexOf('Windows 98')>-1 || detailBrowser.indexOf('Windows Me')>-1){
		installTag = getInstallJRE98MeTag(browser);
		
	}
	else{
		installTag = getInstallJRETag(browser);
	}
		
	if(browser == 'MSIE' || API_isIE11()){
		var detailName = getOSInfoStr();
		
		if(!java16VersionMSIECheck()){
			//document.getElementById('MagicLineDiv').innerHTML= getInstallJRETag(browser);
					
//			document.createElement('MagicLineDiv').innerHTML= getInstallJRETag(browser);			
//			document.write(installTag);
	
			return false;
		}else{
			installJRECheck = true;
			return true;
			//returnPage(returnIndexPage);
		}
	}else if(browser == 'Safari' || browser == 'Opera'){
		if(!java16VersionSafariCheck()){
			//document.createElement('MagicLineDiv').innerHTML= getInstallJRETag(browser);
			return false;
			//document.getElementById('MagicLineDiv').innerHTML= getInstallJRETag(browser);
			//document.write(getInstallJRETag(browser));
		}else{
			//returnPage(returnIndexPage);
			installJRECheck = true;
			return true;
		}
	}else{
		if(!java16VersionCheck()){
			//document.createElement('MagicLineDiv').innerHTML= getInstallJRETag(browser);
			return false;
			//document.getElementById('MagicLineDiv').innerHTML= getInstallJRETag(browser);
			//document.write(getInstallJRETag(browser));
		}else{	
			//returnPage(returnIndexPage);
			installJRECheck = true;
			return true;
			
		}
	}
}


function java16VersionMSIECheck(){
	var jres = deployJava.getJREs();

	var strUserAgent;
	var strPatternWindows98 = /windows 98/i;
	var strPatternWindowsME = /windows 98/i;
	var strPatternVista2008 = /nt 6.0/i;
	var strPatternIE9 = /msie 9/i;

	strUserAgent = navigator.userAgent.toLowerCase();
	
	if(deployJava.versionCheck('1.6.0_22+') ){
		return true;
	}else if(deployJava.versionCheck('1.5.0_22+') ){		
		for(var i=0; i< jres.length; i++){
			
				
			if(jres[i].indexOf('1.6.0') >-1){
				
				if(strPatternVista2008.test(strUserAgent) && strPatternIE9.test(strUserAgent) && deployJava.versionCheck('1.6.0_24+')){
					nextCheck = true;
					return true;				
				}else if((!strPatternVista2008.test(strUserAgent) || !strPatternIE9.test(strUserAgent))&&deployJava.versionCheck('1.6.0_18+')){
					nextCheck = true;
					return	true;					
				}else{			
					return false;
				}
			}else 	if(jres[i].indexOf('1.7.')>-1){
				return true;
			}else{}
		}
		
		if(strPatternWindows98.test(strUserAgent) || strPatternWindowsME.test(strUserAgent))
			return true;
		
		return false;		
	}else{		
		for(var i=0; i< jres.length; i++){
			
			if(jres[i].indexOf('_')==-1 && jres[i].indexOf('1.5.0')>-1){				
				return true;
			}
			if(jres[i].indexOf('_')==-1 && jres[i].indexOf('1.6.0')>-1){
				return true;
			}
		}
		return false;
	}
}


//Netscape Family JRE Version Check!!
function java16VersionCheck(){
	var isMac = (window.navigator.platform =='Mac68K')||(window.navigator.platform == 'MacPPC') || (window.navigator.platform == 'MacIntel') || (window.navigator.platform.indexOf("Mac") > -1 ) ;
	if(isMac){
		Java0StatusS = PluginDetect.isMinVersion('Java', '1.5.0+', codebaseurl+rootDir+libDir+'/getJavaInfo.jar');
		if(Java0StatusS == 1){
			return true;
		}else{
			return false;
		}
	}else{
		if(java16VersionMSIECheck())
			return true;
	}
	return false;
}

// Safari JRE Version Check!!
function java16VersionSafariCheck(){
	var isMac = (window.navigator.platform =='Mac68K')||(window.navigator.platform == 'MacPPC') || (window.navigator.platform == 'MacIntel') || (window.navigator.platform.indexOf("Mac") > -1 ) ;
	var JavaVersionS = "";
	var Java0StatusS;
	//alert('hello');
	
	if(isMac){
		JavaVersionS = PluginDetect.getVersion('Java', codebaseurl+rootDir+libDir+'/getJavaInfo.jar');
	    Java0StatusS = PluginDetect.isMinVersion('Java', '1.5.0', codebaseurl+rootDir+libDir+'/getJavaInfo.jar');
	    
		 if(JavaVersionS.indexOf('1,5')>-1)
			 return true;
		 else if(JavaVersionS.indexOf('1,6')>-1)
			 return true;
		 else if(JavaVersionS.indexOf('1,7')>-1)
			 return true;
		 else 
			 return false;
	}else{
		
		JavaVersionS = PluginDetect.getVersion('Java', codebaseurl+rootDir+libDir+'/getJavaInfo.jar');
	    Java0StatusS = PluginDetect.isMinVersion('Java', '1.6.0', codebaseurl+rootDir+libDir+'/getJavaInfo.jar');
	    if(JavaVersionS.indexOf('1,5,0')>-1){		
			
	    	if((JavaVersionS.split(",").length >3 ) && (JavaVersionS.split(",")[3] > 21))
			 	return true;
			 else
			 	return false;
		 }
	    
		 if(JavaVersionS.indexOf('1,6,0')>-1){					
			 if((JavaVersionS.split(",").length >3 ) && (JavaVersionS.split(",")[3] > 16))
			 	return true;
			 else
			 	return false;
		 }
		 else if(JavaVersionS.indexOf('1,7')>-1)
			 return true;
		 else 
			 return false;
	}
}

function getOSInfoStr()
{
    var ua = navigator.userAgent;
 
    if(ua.indexOf("NT 6.0") != -1) return "Windows Vista/Server 2008";
    else if(ua.indexOf("NT 5.2") != -1) return "Windows Server 2003";
    else if(ua.indexOf("NT 5.1") != -1) return "Windows XP";
    else if(ua.indexOf("NT 5.0") != -1) return "Windows 2000";
    else if(ua.indexOf("NT") != -1) return "Windows NT";
    else if(ua.indexOf("9x 4.90") != -1) return "Windows Me";
    else if(ua.indexOf("98") != -1) return "Windows 98";
    else if(ua.indexOf("95") != -1) return "Windows 95";
    else if(ua.indexOf("Win16") != -1) return "Windows 3.x";
    else if(ua.indexOf("Windows") != -1) return "Windows";
    else if(ua.indexOf("Linux") != -1) return "Linux";
    else if(ua.indexOf("Macintosh") != -1) return "Macintosh";
    else return "";
}
