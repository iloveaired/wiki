// EPKI Client Toolkit 을 사용하기 위한 Object 를 설정합니다.
function SetupObjECT_uway(objCheckmode,cfg)
{
	if(!cfg){
		cfg = {}
	}
	if(!installJRE()){
	
		var strUserAgent = navigator.userAgent.toLowerCase();
		var browser = strUserAgent;
	
//		if( browser.indexOf('firefox')>-1){
//			
//			document.write("<div>"+getInstallJRETag('netscape')+"</div>");
//		}else{
		{
			var strPatternWin98 = /windows 98/i;
			var strPatternWinME = /Windows ME/i;
			
			var strUserAgent = navigator.userAgent.toLowerCase();
	
			if(strPatternWin98.test(strUserAgent) || strPatternWinME.test(strUserAgent)){
//	 			현재 페이지를 자바 설치 페이지로 이동 			
//				location.href = WIN_JRE_FOR_98ME_URL;
				
				var msg = "교과부 암호 모듈을 사용하기 위해서는 \n";
				msg +=  "Sun MicroSytem에서 제공하는 Java 프로그램을  설치하셔야 합니다. \n";
				msg +=  "\n기존에 설치되어 있는 JAVA 가 설치되어 있었어도 \n";
				msg +=  "교과부 암호 모듈이 제대로 작동하지 않을 경우에는, \n";
				msg +=  "\n연결되는 자바 설치 페이지에서 최신 버전을 설치해 주시기 바랍니다. \n";
				msg += "자바 설치 후 다시 접속해 주시기 바랍니다.";
				alert(msg);									


//				팝업에 의한 자바설치 페이지 이동
				window.open(WIN_JRE_FOR_98ME_URL,'Download');

			}else{
//	 			현재 페이지를 자바 설치 페이지로 이동 
//				location.href = 'http://www.java.com';
				
				var msg = "교과부 암호 모듈을 사용하기 위해서는 \n";
				msg +=  "Sun MicroSytem에서 제공하는 Java 프로그램을  설치하셔야 합니다. \n";
				msg +=  "\n기존에 설치되어 있는 JAVA 가 설치되어 있었어도 \n";
				msg +=  "교과부 암호 모듈이 제대로 작동하지 않을 경우에는, \n";
				msg +=  "\n연결되는 자바 설치 페이지에서 최신 버전을 설치해 주시기 바랍니다. \n";
				msg += "자바 설치 후 다시 접속해 주시기 바랍니다.";
				alert(msg);		
				
//				팝업에 의한 자바설치 페이지 이동
				window.open('http://www.java.com');
			}
		}
		return;
		
	}
//	installJRE();
		
	var DebugModeValue		= "true";   // EPKI debug Log state
	//- false : 사용안함
	//- true : 사용함
	var TabValue			= "ALL";// 인증서 선택창의 탭 관리 설정
		// - ALL : 일반/관리 탭을 사용함
		// - General : 관리탭을 사용하지 않음 (Default)
		// - Management : 일반탭을 사용하지 않음

	var StorageTypeValue 	= "Disk;RemovableDisk;SmartCard;PKCS11Token";    // 저장매체 타입 설정  복수개의 저장매체 선택시 ';' 으로 구분
		// - Disk : 하드 디스크(시스템 디스크 - Windows 의 경우 C 드라이브)
		// - RemovableDisk : 이동식 디스크
		// - SmartCard : 저장토큰(스마트카드)
		// - PKCS11Token : 보안토큰(PKCS#11)
	var DomainValue		= cfg['DomainValue']?cfg['DomainValue']:"GPKI";   	// 인증 도메인 설정  복수개의 인증 도메인 선택시 ';' 으로 구분
		// - ALL : 모든 도메인 설정 (즉 NPKI;GPKI)  (Default)
		// - NPKI : NPKI 도메인 설정
		// - GPKI : GPKI 도메인 설정
	var CANameValue		= cfg['CANameValue']?cfg['CANameValue']:"ALL";   	// 인증기관 설정  복수개의 인증기관 선택시 ';' 으로 구분
		// - ALL : 모든 인증기관 설정  (Default)
		// [NPKI]
		// - YESSIGN : 금융결제원
		// - SIGNKOREA : 코스콤
		// - TRADESIGN : 한국무역정보통신
		// - KICA : 한국정보인증(SIGNGATE)
		// - CROSSCERT : 한국전자인증
		// - NCASIGN : 한국전산원
		// [GPKI]
		// - MOPAS : 행정안전부 (인증 도메인 설정시 GPKI 가 설정된 경우 Default)
	var CertPolicyValue	= cfg['CertPolicyValue']?cfg['CertPolicyValue']:"ALL";;  
		// 인증서 정책 OID 설정  복수개의 인증서 정책 OID 선택시 ';' 으로 구분
		// - ALL : 모든 인증서 정책 OID 수용  (Default)
		// - 기타 세부 OID 는 각 인증 도메인별 규격을 참고
	var KeyUsageValue		= "SIGN;";	// 키사용 용도(KeyUsage) 설정 복수개의 키사용 용도 선택시 ';' 으로 구분
		// - ALL : 모든 키사용 용도 설정 (Default)
		// - SIGN : 서명용 인증서
		// - KM : 암호용 인증서

	var Site				= "@EPKI/CLIENT";    // EPKI Site


	var installprocess = '';
	var sessionId = '' ;

	var CipherProductVer 			= '1.0.3.11';
	var CipherProductResVer 		= '1.0.1.3';
	var TrustedRootCertVer			= '1.0.1.0';
	var UbiKeyVer 					= '1.0.1.3';

	var libPath = rootDir+libDir;		
	var sitebase = codebaseurl+rootDir+"/";//"http://"+host+":"+port+"/EPKIDemo_Ref/";
	var downPath = libPath;

	// 암호 모듈 제조사 라이브러리 정보
	var CipherProductJar 				= 'MagicLine-'+CipherProductVer+'.jar';
	var CipherProductResJar 			= 'MagicLineRes-'+CipherProductResVer+'.jar';
	var TrustedRootCertJar 				= 'MagicLineTrustedRootCert-'+TrustedRootCertVer+'.jar';
	var JcoasJar 					= 'jcaos-'+JcoasVer+'.jar';
	var UbiKeyJar 					= 'ubikey-'+UbiKeyVer+'.jar'



	// 매직라인 설치 조건
	// defalt  : 설치 체크 없이 자동 설치
	// check   : 사용자 매직라인 미설치, 및 업그레이드 일 경우 javascript:goMagicLineProgressCheck() 실행
//	           index page 및 로그인 페이지에서 사용
//	           ex)javascript:goMagicLineProgressCheck() -> 설치 페이지로 이동
	// install : 설치 페이지에서 적용
//	           ex)javascript:goMagicLineProgressFinish() -> 설치 페이지에서 업무 페이지로 이동
	var InstallProgressValue = installprocess;
	//var UserBrowserValue			= browser;
	var SessionIDValue				= sessionId;
	var EPKIWCJLHTML = '';
	
	var isMsie = DetectedBrowser()==MICROSOFT_IE?true:false;
	var isOpera = DetectedBrowser()==OPERASOFTWARE_OPERA?true:false;
	
	var isWin50 = navigator.userAgent.indexOf("NT 5") != -1;
	var isWin60 = navigator.userAgent.indexOf("NT 6") != -1;
	
	if(!isMsie)
		MobilePhoneValue	= "infovine;";

	if(isMsie ){
		EPKIWCJLHTML += ' <object id="ObjEWC" name="EPKIWCJL" classid="clsid:8AD9C840-044E-11D1-B3E9-00805F499D93" ';
		EPKIWCJLHTML += '  codetype="application/java" type="application/x-java-applet" width="0" height="0" onfocus="objBlur(this);" alt="매직라인" >';
		EPKIWCJLHTML += ' <param name="java_code" value="kr.go.EPKI.EPKIWcJTl.class"/>';
		EPKIWCJLHTML += ' <param name="java_codebase" value="'+codebaseurl+'"/>';
		EPKIWCJLHTML += ' <param name="type" value="application/x-java-applet;jpi-version=1.5"/>';
	}else{
		EPKIWCJLHTML += '<div style="position:absolute;top:0px;left:0px;width:0px;height:0px;z-index:1;visibility:hidden;">';
		EPKIWCJLHTML += '<applet id="ObjEWC" codebase="'+codebaseurl+'"  code="kr.go.EPKI.EPKIWcJTl.class" ';
		EPKIWCJLHTML += 'width=200 height=75 MAYSCRIPT >'; 
	}

	EPKIWCJLHTML += ' <param name="archive" value="'+libPath+'/'+EPKIWCJTL_applet+','+libPath+'/'+EPKIWCJTL_epki+','+libPath+'/'+EPKIWCJTL_crypto+'"/>';

	
//	if( (isWin50 || isWin60) && nextCheck){
		EPKIWCJLHTML += ' <param name="separate_jvm" value="true"/>';
//	}

	// ## MagicLine's Parameter. ##
//	EPKIWCJLHTML += ' <param name="CacheFile" value="'+CipherProductJar+';'+EPKIWCJTL_Jar+';"/>';
//	EPKIWCJLHTML += ' <param name="CacheFileVersion" value="'+CipherProductVer+';'+EPKIWCJTL_Ver+';"/>';
	EPKIWCJLHTML += ' <param name="CacheFile" value="'+CipherProductJar+';"/>';
	EPKIWCJLHTML += ' <param name="CacheFileVersion" value="'+CipherProductVer+';"/>';
	EPKIWCJLHTML += ' <param name="RemoteFilePath" value="'+downPath+'"/>';
	EPKIWCJLHTML += ' <param name="ResourceFile" value="'+CipherProductResJar+';'+EPKIWCJTL_Res_Jar+';"/>';
	EPKIWCJLHTML += ' <param name="ResoureVersion" value="'+CipherProductResVer+';'+EPKIWCJTL_Res_Ver+';"/>';
	EPKIWCJLHTML += ' <param name="CompanyProductVersion" value="'+EPKIWCJTL_Ver+'"/>';
	EPKIWCJLHTML += ' <param name="CompanyCoreClass" value="com.dreamsecurity.ui.MagicXSignRealAppletProcImpl"/>'; 
	EPKIWCJLHTML += ' <param name="TrustedRootCertFile" value="'+TrustedRootCertJar+'"/>';
	EPKIWCJLHTML += ' <param name="TrustedRootCertVersion" value="'+TrustedRootCertVer+'"/>';
	EPKIWCJLHTML += ' <param name="DebugMode" value="' + DebugModeValue + '"/>';
	EPKIWCJLHTML += ' <param name="ActiveTab" value="' + TabValue + '"/>';
	EPKIWCJLHTML += ' <param name="StorageType" value="' + StorageTypeValue + '"/>';
	EPKIWCJLHTML += ' <param name="Domain" value="' + DomainValue + '"/>';	
	EPKIWCJLHTML += ' <param name="CAName" value="' + CANameValue + '"/>';
	EPKIWCJLHTML += ' <param name="CertPolicy" value="' + CertPolicyValue + '"/>';
	EPKIWCJLHTML += ' <param name="KeyUsage" value="' + KeyUsageValue + '"/>';
	EPKIWCJLHTML += ' <param name="KeyboardSec" value="' + KeyboardSecValue + '"/>';
	EPKIWCJLHTML += ' <param name="MobilePhone" value="' + MobilePhoneValue + '"/>';
	EPKIWCJLHTML += ' <param name="InfovineInfo" value="CHANNELNAME:' + InfovineInfoValue + ';CERT_COMPANY:DREAMSECURITY;"/>';
	EPKIWCJLHTML += ' <param name="InstallProgress" value="'+InstallProgressValue+'"/>';
	EPKIWCJLHTML += ' <param name="LocalDownLoadPath" value="' + Site + '"/>';
	EPKIWCJLHTML += ' <param name="sitebase" value="' + sitebase + '"/>';
	EPKIWCJLHTML += ' <param name="SessionID" value="' + SessionIDValue + '"/>';
	EPKIWCJLHTML += ' <param name="CharSet" value="' + charSet + '"/>';
	EPKIWCJLHTML += ' <param name="codebase_lookup" value="false"/>';
	if(isMsie ){
		EPKIWCJLHTML += ' </object>';
	}else{
		EPKIWCJLHTML += '</applet>';
		EPKIWCJLHTML += '</div>';	
	}
	
	if(isMsie ){
		var epkiElement = document.createElement('div');
		epkiElement.id='EPKIElement';
		epkiElement.innerHTML = EPKIWCJLHTML;
		var ref_node =  document.getElementsByTagName("HEAD")[0];
		ref_node.parentNode.insertBefore(epkiElement, ref_node);		
	}else{		
		document.write(EPKIWCJLHTML);
	}	

}