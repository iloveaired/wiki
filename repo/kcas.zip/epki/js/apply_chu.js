	var $j = jQuery.noConflict();
	var POP_SMS;
	var POP_IPIN;

	// 인증방법 선택하기
	function chk_type(authtype)
	{
		if( POP_SMS ) POP_SMS.close();
		if( POP_IPIN ) POP_IPIN.close();

		if( authtype == '04' ) // 비밀번호 인증
		{
			document.getElementById('div_authBtn').style.display = 'none'; // 인증안내 및 인증하기 버튼 안 보여주기
			document.getElementById('tr_pwdcomment').style.display = 'none'; // 비밀번호 설명 보여주기
			document.getElementById('tr_pwd').style.display = 'table-row'; // 비밀번호 보여주기
			document.getElementById('tr_pwdchk').style.display = 'none'; // 비밀번호 확인 보여주기
			document.getElementById('div_joinBtn').style.display = 'none'; // 비밀번호 등록 보여주기
			document.getElementById('div_joinBtn2').style.display = 'block'; // 비밀번호 등록 보여주기
		}
		else
		{
			if( document.form1.AUTHFLAG.value && authtype != document.form1.AUTHTYPE.value )
			{
				if( ! confirm('인증방법을 변경하시면 다시 인증하셔야 합니다. 계속 진행하시겠습니까?') )
				{
					document.getElementById('auth'+document.form1.AUTHTYPE.value).checked = true;
					return;
				}
			}
			document.getElementById('div_authBtn').style.display = 'block'; // 인증안내 및 인증하기 버튼 안 보여주기
			document.getElementById('tr_pwdcomment').style.display = 'none'; // 비밀번호 설명 보여주기
			document.getElementById('tr_pwd').style.display = 'none'; // 비밀번호 보여주기
			document.getElementById('tr_pwdchk').style.display = 'none'; // 비밀번호 확인 보여주기
			document.getElementById('div_joinBtn').style.display = 'none'; // 비밀번호 등록 보여주기
			document.getElementById('div_joinBtn2').style.display = 'none'; // 비밀번호 등록 보여주기
			document.form1.AUTHFLAG.value = '';
			document.form1.AUTHTYPE.value = authtype;
		}
	}

	function chk_agree()
	{
		if( POP_SMS ) POP_SMS.close();
		if( POP_IPIN ) POP_IPIN.close();
	}

	// 인증하기
	function fn_auth(svr)
	{
		var svr = svr || '';

		document.form1.AUTHFLAG.value = '';
		var authtype = document.form1.AUTHTYPE.value;

		if( authtype == '04' )
		{
			alert('비밀번호 인증');
		}
		else
		{
			if( authtype == '' )
			{
				alert('인증방법을 선택해 주십시오.');
				return;
			}
//			else if( ! document.getElementById('agree01').checked )
//			{
//				alert('개인정보의 수집 및 이용에 동의하셔야 인증이 가능합니다.');
//				return;
//			}

			if( authtype == '01' ) // 공인인증서
			{
				getUserDN_NOEPKI();
			}
			else if( authtype == '02' ) // 휴대폰
			{
				popup_web_auth();
			}
			else if( authtype == '03' ) // 아이핀
			{
				popup_ipin(svr);
			}
			else if( authtype == '04' ) // 비밀번호 인증
			{
				fn_join();
			}
			else if( authtype == '10' ) // epki 인증 (주민등록번호 없이)
			{
				getUserDN_EPKI();
			}
		}
	}

	function go_epki()
	{
		var frm = document.form_epki;
		SignData(frm);
	}

	// 공인인증서 인증
	function getUserDN_EPKI()
	{
		var userDN = Certificate.getUserDN_EPKI();
		if( userDN == null || userDN == '' )
		{
//			alert("DN확인이 취소되었습니다.");
		}
		else
		{
			var chk = userDN.split('='+document.form1.NAMEKOR.value);
			if( chk.length > 1 )
			{
				auth_success();
			}
			else
			{
				alert('인증서 정보가 맞지 않습니다.');
				return;
			}
		}
	}
	
	function getUserDN_NOEPKI()
	{
		var userDN = Certificate.getUserDN_NOEPKI();
		if( userDN == null || userDN == '' )
		{
//			alert("DN확인이 취소되었습니다.");
		}
		else
		{
			var chk = userDN.split('='+document.form1.NAMEKOR.value);
			if( chk.length > 1 )
			{
				auth_success();
			}
			else
			{
				alert('인증서 정보가 맞지 않습니다.');
				return;
			}
		}
	}
	
	// 휴대폰 인증
	function popup_web_auth()
	{
		POP_SMS = window.open('/common/assign_sms/uas/Ready.php','popup_web_auth','width=470,height=620');
	}

	// 휴대폰 인증 완료
	function confirm_web_auth(name,iden,htel)
	{
		// 이름 생년월일이 일치할 경우
		if( name == document.form1.NAMEKOR.value && iden.substring(0,6) == document.form1.BIRTHDATE.value.substring(2,8) )
		{
			auth_success();
		}
		else
		{
			alert('인증 정보가 맞지 않습니다.');
			return;
		}
	}
	
	// 아이핀 인증
	function popup_ipin( svr )
	{
		var svr = svr || 'idsdev.uwayapply.com';
		document.form_ipin.action = 'https://'+svr+'/tools/ipin/ipin_request.php';
		document.form_ipin.target = 'IPINWindow';

		//IE11버그때문에 form submit을 사용하면 팝업이 아닌 탭이 뜬다. 그래서 window.open 사용
		// 한글값을 사용하지 말라.
		var url = document.form_ipin.action+'?retUrl='+encodeURIComponent(document.form_ipin.retChkUrl.value)
					+'&reqNum='+encodeURIComponent(document.form_ipin.reqChkNum.value);
		POP_IPIN = window.open(url,'IPINWindow', 'width=450, height=500, resizable=0, scrollbars=no, status=0, titlebar=0, toolbar=0 ' );
//		document.form_ipin.reqNum.value = form_ipin.reqNum.value; //더이상 reqNum을 리턴으로 받지 않는다.
	}

	// 아이핀 인증 완료
	function confirm_ipin(name,birthdate)
	{
		// 이름 생년월일이 일치할 경우
		if( name == document.form1.NAMEKOR.value && birthdate == document.form1.BIRTHDATE.value )
		{
			auth_success();
		}
		else
		{
			alert('인증 정보가 맞지 않습니다.');
			return;
		}
	}

	//epki 인증2 ( 주민등록번호 사용하지 않음 )
	function SignData(theForm)
	{	
		var strSignResult;
			
		strSignResult = Sign(1, "", "Test Data!");
		if( strSignResult == "" )
		{
			ECTErrorInfo();
		}
		else
		{
			if( strSignResult != '' )
			{
				theForm.SIGNEDDATA.value = strSignResult;
				theForm.submit();
			}
			return;
		}
	}

	//epki 인증1 ( 주민등록번호 사용 )
	function RequestVerifyVIDData(theForm)
	{
		var strRequestData;
		if( theForm.inputid.value.length<1 )
		{
			alert("식별번호는 필수입니다..");
			return;
		}
		
		if( theForm.inputid.value == "" )
		{
			alert("식별번호를 입력하십시오.");
			return;
		}

		strRequestData = RequestVerifyVID(EPKICertKey, "");
		if( strRequestData == "" )
		{
			ECTErrorInfo();
		}
		else
		{
			theForm.SIGNEDDATA.value = strRequestData;
			theForm.IDN.value = theForm.inputid.value;
			theForm.submit();
		}
	}

	// epki 인증 완료
	function confirm_epki(result)
	{
		var chk = result.split(document.form1.NAMEKOR.value);
		if( chk.length > 1 )
		{
			auth_success();
		}
		else
		{
			alert('인증서 정보가 맞지 않습니다.');
			return;
		}
	}

	// 인증 완료
	function auth_success()
	{
		document.form1.AUTHFLAG.value = 'Y';
		document.getElementById('tr_auth').style.display = 'none'; // 인증방법 선택 안 보여주기
		document.getElementById('div_authBtn').style.display = 'none'; // 인증안내 및 인증하기 버튼 안 보여주기
		document.getElementById('tr_pwdcomment').style.display = 'table-row'; // 비밀번호 설명 보여주기
		document.getElementById('tr_pwd').style.display = 'table-row'; // 비밀번호 보여주기
		document.getElementById('tr_pwdchk').style.display = 'table-row'; // 비밀번호 확인 보여주기
		document.getElementById('div_joinBtn').style.display = 'block'; // 비밀번호 등록 보여주기
		alert('인증이 완료되었습니다.\n\n비밀번호를 등록 후 사용하시기 바랍니다.');
	}

	function chk_pwd(obj)
	{
		var objname = obj.getAttribute('name');

		if( objname == 'PASSWORD' ) // 비밀번호
		{
			document.form1.PASSWORDCHK.value = '';

			var pwd = fn_trim(obj.value);
			var rpwd = obj.value;
			var alt = '';
			
			if( rpwd != '' )
			{
				if( pwd.length < 8 || pwd.length > 16 || pwd.length != rpwd.length ) // 비밀번호는 8 ~ 16 자리로 설정해 주십시오.
				{
					alt = '비밀번호는 8 ~ 16 자리로 설정해 주십시오.';
				}
				else if( pwd.length < 10 ) // 8 ~ 9 자리 : 영문 + 숫자 + 특수문자
				{
					if( !pwd.match(/[a-z,A-Z]+/) || !pwd.match(/[0-9]+/) || !pwd.match(/[\~,\!,\@,\#,\$,\%,\^,\&,\*,\(,\),\-,\=,\+,\_]+/) )
					{
						alt = '8 ~ 9 자리로 입력 시 영문, 숫자, 특수문자를 포함 설정해 주십시오.';
					}
				}
				else if( pwd.length >=10 ) // 10 ~ 16 자리 : 영문 + 숫자
				{
					if( !pwd.match(/[a-z,A-Z]+/) || !pwd.match(/[0-9]+/) )
					{
						alt = '10 ~ 16 자리로 입력 시 영문, 숫자를 포함 설정해 주십시오.';
					}
				}
			}

			if( alt != '' )
			{
				if( document.form1.AUTHTYPE.value == '04' )
				{
					alt = "비밀번호를 잘못 입력하셨습니다.\n\n비밀번호를 모르시는 경우는 다시 인증하시기 바랍니다.";
				}

				obj.value = '';
				alert(alt);
				return;
			}
		}
		else if( objname == 'PASSWORDCHK' ) // 비밀번호 확인
		{
			var pwd = document.form1.PASSWORD.value;
			var pwdchk = document.form1.PASSWORDCHK.value;
			if( pwd != '' && pwdchk != '' && pwd != pwdchk )
			{
				obj.value = '';
				alert('비밀번호 확인을 바르게 입력해 주십시오.');
				return;
			}
		}
	}

	// 비밀번호 공백 없애기
	function fn_trim(val)
	{
		return val.trim().replace(/(\s*)/g,"");
	}

	// 비밀번호 등록
	function fn_join()
	{
		if( document.form1.PASSWORD.value == '' )
		{
			alert('비밀번호를 입력해 주십시오.');
			return false;
		}
		if( document.form1.AUTHTYPE.value != '04' ) // 비밀번호 인증이 아닌경우
		{
			if( document.form1.PASSWORDCHK.value == '' )
			{
				alert('비밀번호 확인을 입력해 주십시오.');
				return false;
			}
		}

		var sendURL = '/common/main_inc/apply_chu.php';
		var param = 'userid='+document.form1.USERID.value
					+ '&namekor='+encodeURIComponent(document.form1.NAMEKOR.value)
					+ '&birthdate='+document.form1.BIRTHDATE.value
					+ '&email='+document.form1.EMAIL.value
					+ '&authtype='+document.form1.AUTHTYPE.value
					+ '&password='+document.form1.PASSWORD.value
					+ '&flag='+document.form1.FLAG.value
					+ '&univurl='+document.form1.UNIVURL.value
					+ '&ounivlogout='+document.form1.OUNIV_LOGOUT.value;
		ajaxextend('POST',sendURL,param,function(d)
		{
			if( d.match(/^(\+OK\+)/) ) // 등록 성공
			{
				var alt = "비밀번호 등록이 완료되었습니다.\n\n추천서 작성을 진행해 주시기 바랍니다.";
				if( document.form1.AUTHTYPE.value == '04' )
				{
					alt = "비밀번호 인증이 완료되었습니다.\n\n추천서 작성을 진행해 주시기 바랍니다.";
				}
				alert(alt);
				top.location.href = decodeURIComponent(document.form1.RETURL.value);
			}
			else // 등록 실패
			{
				var alt = "실패했습니다!\n\n잠시후 다시 시도해주세요!";
				if( document.form1.AUTHTYPE.value == '04' )
				{
					alt = "비밀번호를 잘못 입력하셨습니다.\n\n비밀번호를 모르시는 경우는 다시 인증하시기 바랍니다.";
				}
				alert(alt);
			}
		});
	}

	function ajaxextend(type, url, data, success)
	{
		try
		{
			$j.ajax({
				type : type,
				url : url,
				data : data,
				async : false,
				success : success,
				error : function(arg, arg1, arg2)
				{
					alert('서버 통신에 실패했습니다!\n\n잠시후 다시 시도해주세요!');
				}
			});
		}
		catch (err)
		{
			alert('ajaxextend : '+err.message);
		}
	}
