<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html lang="ko-kr">
<head>
<title>:: 16�� ���� ���ͳ� �������� 1�� ��� - �����̾��ö��̴��� ::</title>

<meta http-equiv="X-UA-Compatible" content="IE=7"/>

<meta http-equiv="Content-Type" content="text/html; charset=ks_c_5601-1987">
<link rel='stylesheet' href='http://ta.uwayapply.com/common/main_img/2012/template/1/_common.css' type=text/css>
<style type="text/css">
#contaier #center{width:1024px;}
#center #contents{padding-top:5px; width:825px;}
hr{ border-top-width: 1px; border-top-color: #d5d5d5; border-top-style: solid; border-bottom-width: 1px; border-bottom-color: #ffffff; border-bottom-style: solid; margin: 0px;display:block}
</style>

<script type='text/javascript' language=javascript src='http://ta.uwayapply.com/common/main_js/ta_prototype.js'></script>
<script type='text/javascript' language=javascript src='http://ta.uwayapply.com/common/main_js/prototype.js'></script>
<script type='text/javascript' language=javascript src='http://ta.uwayapply.com/common/main_js/common.js'></script>
<script type='text/javascript' language=javascript src='http://ta.uwayapply.com/common/main_js/main.js'></script>
<script type='text/javascript' language=javascript src='http://ta.uwayapply.com/common/main_js/AC_RunActiveContent.js'></script>
<script type='text/javascript' language=javascript src='http://ta.uwayapply.com/common/main_js/jquery.js'></script>








<script language='javascript' type='text/javascript' src='https://idsdev.uwayapply.com/js.idsURL.php?site=TA'></script>







<script type='text/javascript' language=javascript src='http://ta.uwayapply.com/chu/inha/1/univ_js/univ.js'></script>
</head>
<body>
<div id="div_help" style="position:absolute; z-index:9999; display:none;"></div>






<script>
	try {
		top.topFrame.fn_menu_active('6');
	}
	catch(err)
	{
//		var ifrm = document.createElement('iframe');
//		ifrm.setAttribute('src','http://'+document.domain+'/jsExec.php?jsFnum=1&jsAnum=6');
//		ifrm.setAttribute('width','0');
//		ifrm.setAttribute('height','0');
//		document.body.appendChild(ifrm);
	}
</script>




	<div id="contaier">

		<!-- CENTERAREA START -->
		<div id="center">
	<script type="text/javascript" language=javascript src='/epki/js/apply_chu.js'></script>


	<script language='javascript' type='text/javascript' src='http://sign.uway.com/js/sign.js'></script>
	<script type="text/javascript">
		sign_object_write("sign.uway.com");
	</script>



	<script language="javascript" type="text/javascript" src="http://kepki.uwayapply.com:8080/js/EPKICommon_uway.js"></script>
	<script language="javascript" type="text/javascript" src="http://kepki.uwayapply.com:8080/js/EPKICommon_uway_custom.js"></script>
	<script language="javascript" type="text/javascript" src="http://kepki.uwayapply.com:8080/js/EPKICertKey_uway.js.php"></script>
	<script type="text/javascript">
		var cfg = {};
		cfg['DomainValue'] = "GPKI";//NPKI,GPKI
		SetupObjECT_uway(true,cfg)
		InitObjECT();
	</script>


	<script language='javascript'>document.body.scroll='yes';</script>
	<form name="form1" action="http://ta.uwayapply.com/common/main_inc/apply_chu.php" method="post">
	<input type='hidden' name='AUTHTYPE' value='' readOnly>
	<input type='hidden' name='AUTHFLAG' readOnly>
	<input type='hidden' name='USERID' value='uway866007be0e57578920b6e23020b1d8c092592ac8' readOnly>
	<input type='hidden' name='NAMEKOR' value='������' readOnly>
	<input type='hidden' name='BIRTHDATE' value='19850228' readOnly>
	<input type='hidden' name='EMAIL' value='qkdrk88@naver.com' readOnly>
	<input type='hidden' name='RETURL' value='http://ta.uwayapply.com/chu/inha/?go_url=/chu/inha/main.htm?inc_file=/common/menu_inc/select_applygr.htm&CHA=1' readOnly>
	<input type='hidden' name='UNIVURL' value='chu/inha' readOnly>
	<input type='hidden' name='OUNIV_LOGOUT' value='N' readOnly>
	<input type='hidden' name='FLAG' value='ins' readOnly>
	<div>
		<div id="intro" class="contents_wrap">
		<h6><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/h2_sub05.png" alt="����� ���" /></h6>
		<h3 class="bg_title">����� ����</h3>
			<table class="viewTable" cellpadding="0" cellspacing="0">
				<colgroup>
				<col width="25%" />
				<col width="*" />
				</colgroup>
				<tbody>
				<tr>
					<th>����(�Ǹ�)</th>
					<td>������</td>
				</tr>
				<tr>
					<th>�������</th>
					<td>1985�� 02�� 28��</td>
				</tr>
				<tr>
					<th>�̸���</th>
					<td>qkdrk88@naver.com</td>
				</tr>
				<tr id='tr_auth'>
					<th>������� ����</th>
					<td>




						<input type="radio" id="auth10" name="auth" value="10" onclick="chk_type(this.value)" /> <label for="auth10">EPKI</label>



						<input type="radio" id="auth01" name="auth" value="01" onclick="chk_type(this.value)" /> <label for="auth01">����������</label>



						<input type="radio" id="auth02" name="auth" value="02" onclick="chk_type(this.value)" /> <label for="auth02">�޴���</label>



						<input type="radio" id="auth03" name="auth" value="03" onclick="chk_type(this.value)" /> <label for="auth03">������</label>


					</td>
				</tr>
				<tr id='tr_pwdcomment' style='display:none;'>
					<th>���ǻ���</th>
					<td>
						* ��й�ȣ�� ��� �� ��й�ȣ ������ Ȱ��˴ϴ�.<br/>
						* ��й�ȣ�� ����/�ҹ���, ����, Ư������ �� 3���� ���� �̻��� ȥ���Ͽ� �ּ� 8�� �̻� �Ǵ�<br/>
						&nbsp;&nbsp;2���� ���� �̻��� ȥ���Ͽ� �ּ� 10�� �̻����� ����Ͻñ� �ٶ��ϴ�.
					</td>
				</tr>
				<tr id='tr_pwd' style='display:none;'>
					<th>��й�ȣ</th>
					<td><input type="password" name="PASSWORD" class="txt t02" onblur="chk_pwd(this);" /></td>
				</tr>
				<tr id='tr_pwdchk' style='display:none;'>
					<th>��й�ȣ Ȯ��</th>
					<td><input type="password" name="PASSWORDCHK" class="txt t02" onblur="chk_pwd(this);" /></td>
				</tr>
				</tbody>
			</table>
			<div id='div_authBtn' style='display:block;'>
				<br/>
				<p class="btn_c"><a href='#' onclick="fn_auth('idsdev.uwayapply.com'); return false;" class='btn_red'><b><span id='TextAuthButton'>�����ϱ�</span></b></a></p>

			</div>
			<div id='div_joinBtn' style='display:none;'>
				<p class="btn_c"><a href='#' onclick="fn_join(); return false;" class='btn_red'><b><span id='TextJoinButton'>��й�ȣ ���</span></b></a></p>
			</div>
			<div id='div_joinBtn2' style='display:none;'>
				<p class="btn_c"><a href='#' onclick="fn_join(); return false;" class='btn_red'><b><span id='TextJoinButton2'>�����ϱ�</span></b></a></p>
			</div>
		</div>
	</div>
	</form>


	<form name="form_ipin" method="post">
		<input type='hidden' name='reqChkNum' value="157972" readOnly>
		<input type='hidden' name='retChkUrl' value="https://ta.uwayapply.com/common/assign_sms/return_ipin.php" readOnly>
	</form>



	<form name="form_epki" action="http://ta.uwayapply.com/common/assign_sms/page.kepki.php" target="epkiauthenticate" method="post">
		<input type='hidden' name='SIGNEDDATA' value='' readOnly>
		<input type="hidden" name="mode" value="certinfo">
	</form>
	<iframe name='epkiauthenticate' frameborder='0' width='0' height='0'></iframe>



			<!-- RIGHTAREA START -->
			<div id="right">
				


	<dl id="endtimeDday" style="display:none;">
		<dt><strong>��������</strong>���� <b>�����ð�</b></dt>
		<dd><span id="endtimeDday_day" class="day"></span>
			<img src="http://ta.uwayapply.com/common/main_img/2012/template/1/day.png" alt="DAY" /><span class="min"><span id="endtimeDday_hour"></span>:<span id="endtimeDday_min"></span></span>
		</dd>
	</dl>
	<dl id="beforeDday" style="display:none;">
		<dd class="end"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/end.png" alt="���� ���� �� �Դϴ�." /></dd>
	</dl>
	<dl id="endDday" style="display:none;">
		<dd class="end"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/end.png" alt="���� ���� �Ǿ����ϴ�." /></dd>
	</dl>
	<script>
//		var chuRight = true;
		function endtimeCount(d,h,i,s)
		{
			var endtimeDiv = document.getElementById('endtimeDday');
			if( d=='NOTSTART' ) // ���� ���� ��
			{
//				document.all.beforeDday.style.display = "block";
			}
			else if( d=='END' || ( d<=0 && h==0 && i==0 && s==0 ) ) // ���� ����
			{
				document.all.endDday.style.display = "block";
			}
			else // ���� ��
			{
				document.all.endtimeDday.style.display = "block";
				var dispD = d; if(String(d).length==1) dispD = '0'+String(d);
				var dispH = h; if(String(h).length==1) dispH = '0'+String(h);
				var dispI = i; if(String(i).length==1) dispI = '0'+String(i);
				var dispS = s; if(String(s).length==1) dispS = '0'+String(s);
				document.getElementById('endtimeDday_day').innerHTML = dispD;
				document.getElementById('endtimeDday_hour').innerHTML = dispH;
				document.getElementById('endtimeDday_min').innerHTML = dispI;
				s--;
				if( s<0 )
				{
					s = 59;
					i--;
				}
				if( i<0 )
				{
					i = 59;
					h--;
				}
				if( h<0 )
				{
					h = 23;
					d--;
				}
				window.setTimeout('endtimeCount('+d+','+h+','+i+','+s+')',1000);
			}
//			if( document.getElementById('asideinc') && chuRight )
//			{
//				var h = jQuery('#center').height()-jQuery('#asideinc').position().top-10;
//				if( h > jQuery('#asideinc').height() )
//				{
//					jQuery('#asideinc').height(h);
//				}
//				else
//				{
//					jQuery('#asideinc').height(jQuery('#asideinc').height()+40);
//					jQuery('#center').height(jQuery('#asideinc').height()+jQuery('#asideinc').position().top+10);
//				}
//				chuRight = false;
//			}
		}
		addEventHandler(window, 'load',function(){endtimeCount(0,0,49,56)});
	</script>


























				<div class="logout" id="logoutContainerout" style="margin:10px 0; padding:0;">
					<p class="name">
						<span class="user_name"><strong class="gray">������</strong> ������ �ݰ����ϴ�.</span>
					</p>
				</div>











				<div class="rightArea">
					<ul>

						<li><a href="http://wwwsub.uwayapply.com/board/faq.htm?CTG_CD=FAQAPPLY&BLTN_SEQ=30183" target='iepop'><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/IE8_m_rightMenu01.png" alt="IE 8.0���� �̻� �����ذ� ���"/></a></li>







						<li><a href="JsFt_NoteRightPop()" target="_blank"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/m_rightMenu07.png"></a></li>



					</ul>
















				</div>

					<p>
						<a href="http://wwwdev.uwayapply.com/gate.php?ret_url=/board/counsel.htm" target="uwaypop"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/r_call_1588.8988.png" alt="�������� 1588 8988"></a>
					</p>



			</div>
			<!-- RIGHTAREA end -->


		</div>
		</div>
		<br/><br/>
		<!-- CENTERAREA END -->

		<!-- FOOTERAREA START -->
		<div id="footer">
		<div class="footer_con">
			<h1><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/logo_footer_20120817.png" alt="uwayapply.com ��������" /></h1>
			<ul>
				<li><a onfocus="this.blur()" href="http://company.uwayapply.com" target="_blank"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/m_footer01.gif" alt="ȸ��Ұ�" /></a></li>
				<li><a onfocus="this.blur()" href="http://company.uwayapply.com/partner/index.htm" target="_blank"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/m_footer02.gif" alt="���»� �� ���޻�" /></a></li>
				<li><a onfocus="this.blur()" href="http://company.uwayapply.com/partner/index.htm" target="_blank"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/m_footer03.gif" alt="�������" /></a></li>
				<li><a onfocus="this.blur()" href="http://company.uwayapply.com/partner/index.htm" target="_blank"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/m_footer04.gif" alt="��������" /></a></li>
				<li><a onfocus="this.blur()" href="#" onclick="JsFt_OpenWin(_idsURL.privacy, 'privacy', '810', '495')"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/m_footer06.gif" alt="����������޹�ħ" /></a></li>
				<li><a onfocus="this.blur()" href="#" onclick="JsFt_OpenWin(_idsURL.agreement, 'agreement', '810', '495')"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/m_footer07.gif" alt="�̿��ھ��" /></a></li>
				<li class="noBg"><a onfocus="this.blur()" href="http://company.uwayapply.com/partner/index.htm?flag=4" target="_blank"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/m_footer08.gif" alt="ã�ƿ��ô±�" /></a></li>
			</ul>
			<address><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/address_footer_20131230.png" alt="(��)�����̾��ö���" /></address>
			<p class="aig"><img src="http://ta.uwayapply.com/common/main_img/2012/template/1/aceLogo.png" alt="�� ȸ��� ���̽����غ����� '����������ȣ���å�Ӻ���'�� ���ԵǾ� �ֽ��ϴ�." /></p>
		</div>
		</div>
		<!-- FOOTERAREA END -->







	</div>

	</div>
</body>
</html><p align=left><br><font color='FFFFFF' size='1'>IP : 211.172.249.193</font><br></p>
			<div id="divForReloadScript">
			<input type=button onclick="autocheckOutFlow();" name="autocheckOutFlow" value="outFlow AutoCheck(alt+Q)" accesskey="Q" style="BORDER:0; FONT:11px Verdana; LETTER-SPACING:-1px; HEIGHT:18px; COLOR:#999999; CURSOR:pointer;">
			<input type=button onclick="reloadScript(event);" value="univ.js RELOAD(alt+W)" accesskey="W" style="BORDER:0; FONT:11px Verdana; LETTER-SPACING:-1px; HEIGHT:18px; COLOR:#999999; CURSOR:pointer;">
			<input type=button onclick="document.getElementById('divForReloadScript').style.display = 'none';" value="Ŭ���Ͻø� ������ϴ�." style="BORDER:0; FONT:11px Verdana; LETTER-SPACING:-1px; HEIGHT:18px; COLOR:#999999; CURSOR:pointer;">
			</div>
			<div id="variableinfoboxfordeveloper">
	<div class="variableinfobox">
		<div class="desc">
			<label class="title">������ : </label>
			<label class="title">������ :</label>
			<label class="title">blur event :</label>
			<label class="title">change event :</label>
			<label class="title">click event :</label>
		</div>
		<div class="varvalue">
			<input type="text" class="contents" id="variableInfo_name" size="10" />
			<input type="text" class="contents" id="variableInfo_value" size="10" />
			<input type="text" class="contents" id="variableInfo_blur" size="10" />
			<input type="text" class="contents" id="variableInfo_change" size="10" />
			<input type="text" class="contents" id="variableInfo_click" size="10" />
		</div>
		<div class="windowcontrolbox">
			<span class="close">X</span>
		</div>
	</div>
</div>
<script language="javascript">
jQuery(function()
{
	if( document.form1 )
	{
		jQuery(window).scroll(function(){ show_variableinfotoolbox(); }).resize(function(){ show_variableinfotoolbox(); });

		var X = jQuery("form[name=form1]").find("INPUT, SELECT, TEXTAREA");
		for( var i=0; i<X.length; i++ )
		{
			jQuery(X[i]).mouseover(function()
			{
				show_variableinfotoolbox(true);

				jQuery("#variableInfo_blur").val('');
				jQuery("#variableInfo_change").val('');
				jQuery("#variableInfo_click").val('');
				jQuery("#variableInfo_name").val('');
				jQuery("#variableInfo_value").val('');

				jQuery("#variableInfo_name").val(jQuery(this).attr('name'));
				jQuery("#variableInfo_value").val(jQuery(this).attr('value'));

				var onblureventstring = jQuery(this).attr('onblur');
				var onchangeeventstring = jQuery(this).attr('onchange');
				var onclickeventstring = jQuery(this).attr('onclick');

				if( onblureventstring ) jQuery("#variableInfo_blur").val(onblureventstring.toString());
				if( onchangeeventstring ) jQuery("#variableInfo_change").val(onchangeeventstring.toString());
				if( onclickeventstring ) jQuery("#variableInfo_click").val(onclickeventstring.toString());

			});
			
		}

		jQuery("#variableinfoboxfordeveloper span.close").click(function()
		{
			jQuery("#variableinfoboxfordeveloper").hide();
		});
	}
});

function show_variableinfotoolbox(force)
{
	if( jQuery("#variableinfoboxfordeveloper").css('display') != 'none' || force === true )
	{
		var width = document.documentElement? document.documentElement.clientWidth:document.body.clientWidth;

		var left = width - jQuery("#variableinfoboxfordeveloper").width()-50;
		if( left < 0 ) left = 0;

		var position = get_bottom_position() - jQuery("#variableinfoboxfordeveloper").height()-50;

		jQuery("#variableinfoboxfordeveloper").css('top',position+'px').fadeIn(200);
		jQuery("#variableinfoboxfordeveloper").css('left',left+'px');
	}
}

function get_bottom_position()
{
	var docheight = document.documentElement? document.documentElement.clientHeight:document.body.clientHeight;
	var scrollHeight = (document.documentElement.scrollTop || document.body.scrollTop);
	return docheight + scrollHeight;
}
</script>