<?php
require('class.KcasUserInfo.inc');

$kui = new KcasUserInfo('uwayapply.com');

/// �׽�Ʈ�� ���� uway3041 ����
$user_info = array();
$user_info['USERID'] = 'uway3041';
$user_info['USERTYPE'] = '1';
$user_info['PASSWD'] = 'c7a09022396007fbc6e2629bef0ed412ca90179267dc53f3c31cc63bd7a7e6d4';
$user_info['USERNAME'] = '��3041';
$user_info['USERNAME_CHA'] = '�����';
$user_info['USERNAME_ENG1'] = 'you';
$user_info['USERNAME_ENG2'] = 'way_male3041';
$user_info['JUMIN_NO'] = '';
$user_info['ENC_JUMIN_NO'] = '';
$user_info['SEX'] = '1';
$user_info['BIRTH_DATE'] = '20111111';
$user_info['SUNLUN'] = '1';
$user_info['EMAIL'] = 'test1@uway.com';
$user_info['ZIP_HOME1'] = '137';
$user_info['ZIP_HOME2'] = '909';
$user_info['ADD_HOME1'] = '����Ư���� ���ʱ� ����� 72-3';
$user_info['ADD_HOME2'] = '�³����� 5�� ���񽺿��';
$user_info['ADD_HOME_STREET1'] = '����Ư���� ���ʱ� �����3�� 40';
$user_info['ADD_HOME_STREET2'] = '5�� ���񽺿��';
$user_info['ADD_HOME_STREET3'] = '����� �³�����';
$user_info['PHONE1'] = '02';
$user_info['PHONE2'] = '8888';
$user_info['PHONE3'] = '9999';
$user_info['HANDPHONE1'] = '010';
$user_info['HANDPHONE2'] = '0000';
$user_info['HANDPHONE3'] = '0000';
$user_info['HANDPHONE_TYPE'] = 'SKT';
$user_info['IS_EMAIL'] = 'n';
$user_info['IS_SMS'] = 'n';
$user_info['IS_DM'] = 'n';
$user_info['COMPANY'] = 'TEST';
$user_info['DELYN'] = ' ';
$user_info['REGIST_DATE'] = '20010413';
$user_info['LOGIN_DATE'] = '20150214180552';
$user_info['MODIFY_DATE'] = '20150214180627';
$user_info['PWD_MODIFY_DATE'] = '20121030134747';
$user_info['DELETE_DATE'] = '';
$user_info['DELETE_IP'] = '';
$user_info['DI'] = '';
$user_info['CI'] = '';
$user_info['IS_REAL'] = 'n';
$user_info['LAWAGENT'] = '';
$user_info['ADD_HOME_BUILDINGCODE'] = '1165010600100720003017604';


//			���� ��Ű ����
			$kui->setUSERID					( $user_info['USERID']						);
			$kui->setUSERTYPE				( $user_info['USERTYPE']					);
			$kui->setUSERNAME				( $user_info['USERNAME']					);
			$kui->setJUMIN_NO				( $user_info['JUMIN_NO']					);

			$kui->setENC_JUMIN_NO		( $enc_jumin_no								);
			//--- �ӽ� ���
			//$kui->setENC_JUMIN_NO		( $cipher->encrypt_tripledes( $user_info['JUMIN_NO'] ));

			$kui->setEMAIL						( $user_info['EMAIL']						);
			$kui->setZIP_HOME1				( $user_info['ZIP_HOME1']				);
			$kui->setZIP_HOME2				( $user_info['ZIP_HOME2']				);
			$kui->setADD_HOME1			( $user_info['ADD_HOME1']				);
			$kui->setADD_HOME2			( $user_info['ADD_HOME2']				);
			$kui->setADD_HOME_STREET1			( $user_info['ADD_HOME_STREET1']				);
			$kui->setADD_HOME_STREET2			( $user_info['ADD_HOME_STREET2']				);
			$kui->setADD_HOME_STREET3			( $user_info['ADD_HOME_STREET3']				);
			$kui->setADD_HOME_BUILDINGCODE			( $user_info['ADD_HOME_BUILDINGCODE'] );
			$kui->setPHONE1					( $user_info['PHONE1']					);
			$kui->setPHONE2					( $user_info['PHONE2']					);
			$kui->setPHONE3					( $user_info['PHONE3']					);
			$kui->setHANDPHONE1			( $user_info['HANDPHONE1']			);
			$kui->setHANDPHONE2			( $user_info['HANDPHONE2']			);
			$kui->setHANDPHONE3			( $user_info['HANDPHONE3']			);
			$kui->setSEX						( $user_info['SEX']							);
			$kui->setBIRTH_DATE			( $user_info['BIRTH_DATE']				);
			$kui->setHANDPHONE_TYPE	( $user_info['HANDPHONE_TYPE']		);
			$kui->setIS_EMAIL					( $user_info['IS_EMAIL']					);
			$kui->setIS_SMS					( $user_info['IS_SMS']						);
			$kui->setIS_DM						( $user_info['IS_DM']						);
			$kui->setCOMPANY				( $user_info['COMPANY']					);
			$kui->setIS_REAL					( $user_info['IS_REAL']					);
			$kui->setWHEREIS					( $whereis										);
			$kui->setADMINMODE			( $admin_mode								);
			$kui->setCommonCookie();

?>
<!doctype html>
<html lang="ko">
<head>
<title> 1234 </title>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
</head>
<body>
��Ű ���� �Ϸ�.
</body>
</html>
