<?php
require('class.KcasUserInfo.inc');

$kui = new KcasUserInfo('uwayapply.com');
?>

<!doctype html>
<html lang="ko">
<head>
<title> 123 </title>
	<meta http-equiv="Content-Type" content="text/html; charset=euc-kr" />
</head>
<body>
<xmp>
<?
print_r($kui);
?>
</xmp>
<hr>
#$_COOKIE
<xmp>
<?
var_dump($_COOKIE);
?>
</xmp>
</body>
</html>
